#!/bin/bash

# Exit on any error
set -e

# Environment variables
ANDROID_HOME="/opt/android-sdk"
ANDROID_AVD_HOME="$HOME/.android/avd"
SDK_MANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
AVD_MANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/avdmanager"
DEBIAN_FRONTEND=noninteractive

# Install necessary packages
echo "Installing required packages..."
sudo apt-get update && sudo apt-get install -y \
    openjdk-11-jdk \
    wget \
    unzip \
    curl \
    git \
    libgl1-mesa-glx \
    libgl1-mesa-dri \
    gnupg

# Install Android SDK
echo "Installing Android SDK..."
sudo mkdir -p $ANDROID_HOME/cmdline-tools
wget -q https://dl.google.com/android/repository/commandlinetools-linux-8092744_latest.zip -O /tmp/cmdline-tools.zip
sudo unzip /tmp/cmdline-tools.zip -d $ANDROID_HOME/cmdline-tools
rm /tmp/cmdline-tools.zip
sudo mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest

# Update environment variables
echo "Updating environment variables..."
echo "export ANDROID_HOME=$ANDROID_HOME" >> ~/.bashrc
echo "export PATH=\$PATH:\$ANDROID_HOME/emulator:\$ANDROID_HOME/tools:\$ANDROID_HOME/tools/bin:\$ANDROID_HOME/platform-tools" >> ~/.bashrc
echo "Please restart your terminal or run 'source ~/.bashrc' to apply changes."
echo "Please restart your terminal or run 'source ~/.bashrc' to apply changes."
#source ~/.bashrc

# Accept SDK licenses and install necessary SDK packages
echo "Accepting SDK licenses and installing SDK packages..."
yes | $SDK_MANAGER --sdk_root=${ANDROID_HOME} --licenses
$SDK_MANAGER --sdk_root=${ANDROID_HOME} "platform-tools" "platforms;android-34" "emulator" "system-images;android-34;google_apis;x86_64"

# Create and configure an Android emulator AVD
echo "Creating Android emulator AVD..."
echo "no" | $AVD_MANAGER create avd -n test_emulator -k "system-images;android-34;google_apis;x86_64" --device "pixel" --force
mkdir -p $ANDROID_AVD_HOME/test_emulator.avd
echo "hw.cpu.ncore=2" >> $ANDROID_AVD_HOME/test_emulator.avd/config.ini

# Install Node.js and Appium
echo "Installing Node.js and Appium..."
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource.gpg.key | sudo apt-key add -
echo "deb https://deb.nodesource.com/node_14.x focal main" | sudo tee /etc/apt/sources.list.d/nodesource.list
sudo apt-get update && sudo apt-get install -y nodejs
npm install -g appium

# Start the ADB server, emulator, and Appium server
echo "Starting ADB server, emulator, and Appium..."
adb start-server
$ANDROID_HOME/emulator/emulator -avd test_emulator -no-window -no-snapshot -noaudio -no-boot-anim -no-metrics -gpu swiftshader_indirect -accel off &

# Wait for the emulator to fully boot
echo "Waiting for the emulator to boot..."
sleep 60

# Start the Appium server
appium --log-level error

