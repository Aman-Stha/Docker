#!/bin/bash
. config.properties
command -v java >/dev/null 2>&1 -version

if ! [ $? -eq 0 ]
then
	echo "Java not found"
	exit 1
fi

command -v jmeter >/dev/null 2>&1

if ! [ $? -eq 0 ]
then
	echo "Jmeter not installed" 
	exit 1
fi

#echo "Want to check if the configurations are made according to defined setup or not for load testing"
#echo "Type 'Y' for checking and 'N' or other character for not checking"
#read -p "Enter the check configurations: " -n 2 configuration_check

#Note the user provided should have root access to perform the configuration_check 


read -p "Enter 0 for running Sales_invoice and 1 for running transactionLoad 2 for running queryLoad: " input_type_automation

#Start of program here 
outputdir=`date +%Y-%m-%d.%H_%M_%S`
#echo $outputdir

#Making Directories for running Opration
if [ -d "Output" ]
then
	mkdir Output/$outputdir
else
	mkdir Output
	mkdir Output/$outputdir
fi
#Running Jmeter command here:
if [[ ${input_type_automation} = "0" ]]
then
	CMD="jmeter -n -t TestCases/Purchase_Order/PGB.jmx -l Output/${outputdir}/Sales_invoice.jtl -j Output/${outputdir}/Sales_invoice.log -e -o Output/${outputdir}/SalesinvoiceReport"
	eval $CMD
	exit 0
elif [[ ${input_type_automation} = "1" ]]
then
	queryDelete
	CMD="jmeter -n -t TestCases/Transaction_Load/transaction_Load.jmx -l Output/${outputdir}/transaction_load.jtl -j Output/${outputdir}/transaction_load.log -e -o Output/${outputdir}/TransactionLoadReport"
	eval $CMD
	exit 0
	
elif [[ ${input_type_automation} = "2" ]]
then
	CMD="jmeter -n -t TestCases/Query_Load/Query_Load.jmx -l Output/${outputdir}/Query_Load.jtl -j Output/${outputdir}/Query_Load.log -e -o Output/${outputdir}/QueryLoadReport"
	eval $CMD
	exit 0
	
else
	echo "Invalid entry"
	rm -r Output/$outputdir
	exit 1
fi
