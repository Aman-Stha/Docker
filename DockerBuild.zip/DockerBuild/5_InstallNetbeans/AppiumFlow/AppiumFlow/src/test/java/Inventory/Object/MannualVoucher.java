/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.openqa.selenium.By;

/**
 *
 * @author aman
 */
public class MannualVoucher extends BasePage {
    
    public MannualVoucher(AndroidDriver driver) {
        
        super(driver);
        
    }
    
    By accountBtn = By.xpath("//android.view.View[@content-desc=\"ACCOUNT\"]");
    By voucherBtn = By.xpath("//android.view.View[@content-desc=\"Voucher\"]");
    By mannualVoucherBtn = By.xpath("//android.view.View[@content-desc=\"Manual Voucher\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.widget.Button");
    By addMVBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.widget.Button[3]");
    By journalBtn = By.xpath("//android.view.View[@content-desc=\"JOURNAL\"]");
    By narration = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText");
    
    By addDebitBtn = By.xpath("//android.widget.Button[@content-desc=\"Add Debit Amount\"]");
    By addCreditBtn = By.xpath("//android.widget.Button[@content-desc=\"Add Credit Amount\"]");

    By accountHead = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By name = By.xpath("//android.widget.EditText");
    By amount = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By notes = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[3]");
    
    By addBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Add\"]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");

    public void MVInput(String narr, String nam1, String amt1, String note1, String nam2, String amt2, String note2) throws InterruptedException {
    
        Aclick(accountBtn);
        Aclick(voucherBtn);
        Aclick(mannualVoucherBtn);
        Aclick(addBtn);
        Aclick(addMVBtn);
        Aclick(journalBtn);
        
        Write(narration, narr);
        
        Aclick(addDebitBtn);
        Aclick(accountHead); 
        Write(name, nam1);
        Wclick(nam1);
        Write(amount, amt1);
        Write(notes, note1);
        Aclick(addBtn2);
        
        Aclick(addCreditBtn);
        Aclick(accountHead);
        Write(name, nam2);
        Wclick(nam2);
        Write(amount, amt2);
        Write(notes, note2);
        Aclick(addBtn2);
        
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully Created Mannual Voucher ***");
        System.out.println();

        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Aclick(accountBtn);
        
    }
    
}
