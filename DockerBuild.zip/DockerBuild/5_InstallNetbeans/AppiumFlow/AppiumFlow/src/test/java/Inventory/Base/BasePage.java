/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Base;

import io.appium.java_client.android.AndroidDriver;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class BasePage {
    protected AndroidDriver driver;
    protected WebDriverWait wait;
    
    public BasePage(AndroidDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    //When using locator "By"
    protected void Write(By locator1, String value) throws InterruptedException {
        WebElement data = wait.until(ExpectedConditions.elementToBeClickable(locator1));
        data.click();
        data.clear();
        data.sendKeys(value);
        Thread.sleep(1000);
    }
    
    //when using locator "WebElement"
    protected void Swrite(WebElement locator, String value) throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(locator));
        locator.click();
        locator.clear();
        locator.sendKeys(value);
        Thread.sleep(500);
    }
    
    protected void Aclick(By locator) throws InterruptedException {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
        Thread.sleep(500);
    }
    
    protected void Wclick(String value) throws InterruptedException {
        WebElement selectSup = driver.findElement(By.xpath("//android.view.View[contains(@content-desc, '" + value + "')]"));
        wait.until(ExpectedConditions.elementToBeClickable(selectSup)).click();
        Thread.sleep(1000);
    }
}
