/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class GRNwithoutPO extends BasePage {
    
    public GRNwithoutPO(AndroidDriver driver) {
        
        super(driver);
    
    }
    
    By grn = By.xpath("//android.view.View[@content-desc=\"Good Received Note\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By dismiss = By.xpath("//android.view.View[@content-desc=\"Dismiss\"]");
    By addItem = By.xpath("(//android.widget.Button[@content-desc=\"Add Item\"])[2]");
    By product = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By quantity = By.xpath("//android.widget.EditText[@text=\"1\"]");
    By description = By.xpath("//android.widget.ScrollView/android.widget.EditText[4]");
    By addBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Add\"]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    By confirmP = By.xpath("//android.widget.Button[@content-desc=\"Confirm Purchase\"]");
//    By approve = By.xpath("//android.widget.Button[@content-desc=\"Approve\"]");
//    By exit = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button[1]");

    public void grnInput(String sup, String dn, String cpr, String db, String pro, String qua, String desc) throws InterruptedException {

        Aclick(grn);
        Thread.sleep(1000);
        
        try {
            WebElement SwitchElement = driver.findElement(AppiumBy.androidUIAutomator(
            "new UiScrollable(new UiSelector().scrollable(true)).setAsHorizontalList().scrollIntoView("
            + "new UiSelector().className(\"android.widget.Button\").instance(12))"
        ));
        SwitchElement.click();
        } catch (Exception e) {
        }

        Aclick(addBtn);
        Aclick(addBtn);

        try {
            Aclick(dismiss);
        } catch (Exception e) {
        }

        WebElement supplier = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText"));
        Swrite(supplier, sup);
        Wclick(sup);
        
        WebElement dNote = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]"));
        Swrite(dNote, dn);

        WebElement cPeriod = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[3]"));
        Swrite(cPeriod, cpr);

        WebElement dBy = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[4]"));
        Swrite(dBy, db);

        Aclick(addItem);
        
        Write(product, pro);
        Wclick(pro);
        
        Write(quantity, qua);
        Write(description, desc);
        Aclick(addBtn2);
        Aclick(save);

        System.out.println();
        System.out.println("*** Successfully created GRN Without Purchase Order ***");
        System.out.println();
        Thread.sleep(2000);
        
    }

    public void purchaseBill() throws InterruptedException {
//        try {
//            WebElement confirmP1 = driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Confirm Purchase\"]"));
//            if(confirmP1.isDisplayed()) {
//                wait.until(ExpectedConditions.elementToBeClickable(confirmP1)).click();
//            }
//        } catch (Exception e) {
//            List<WebElement> grnList = driver.findElements(By.xpath("//android.view.View"));
//            WebElement selectGRN = grnList.get(9);
//            wait.until(ExpectedConditions.elementToBeClickable(selectGRN)).click();
//            Aclick(approve);
//            Thread.sleep(1000);
//            driver.pressKey(new KeyEvent(AndroidKey.BACK));
//            Aclick(confirmP);
//        }
        Aclick(confirmP);
        Aclick(save);

        System.out.println();
        System.out.println("*** Successfully created purchase bill ***");
        System.out.println();

        driver.pressKey(new KeyEvent(AndroidKey.BACK));

    }
    
}
