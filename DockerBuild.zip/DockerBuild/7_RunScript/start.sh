#!/bin/bash

export NVM_DIR="$HOME/.nvm"
source $NVM_DIR/nvm.sh
nvm use 22.10.0

export PATH=$PATH:/root/.nvm/versions/node/v22.10.0/bin

# Start the emulator in the background
#adb kill-server &
#adb -P 5038 start-server &

#Start appiumm server
appium &

emulator -avd test_emulator -no-window -no-audio -gpu swiftshader_indirect -skin 1440x3200 &

# Wait for the emulator to boot up
#adb devices &
adb wait-for-device
adb devices

#Install app in eulator
#adb install /usr/local/bin/app/Sigma_v2.5.7@93fbe2f9_uat_2024-10-02_12_28_55.apk &

#Start inventory server
#docker run -d --name my_inventory_app -p 8080:80 192.168.3.91:5000/inventory_app:v2.5.5

# Wait for a moment to ensure the inventory server is up
sleep 5

# Navigate to the project directory
cd /root/Netbeans/AppiumFlow

# Run Maven tests
#mvn -nsu -Dtest=Inventory.Page.LoginFlow test
mvn test -nsu -Dsurefire.suiteXmlFiles=src/test/java/Inventory/Page/${file}.xml
if [ $? -ne 0 ]; then
    echo "Test execution failed."
    exit 1
fi

echo "All processes completed successfully."
