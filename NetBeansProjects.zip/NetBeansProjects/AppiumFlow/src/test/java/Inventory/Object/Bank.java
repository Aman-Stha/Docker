/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.openqa.selenium.By;

/**
 *
 * @author aman
 */
public class Bank extends BasePage {
    
    public Bank(AndroidDriver driver) {
        super(driver);
    }
    
    By accountBtn = By.xpath("//android.view.View[@content-desc=\"ACCOUNT\"]");
    By bankBtn = By.xpath("//android.view.View[@content-desc=\"Bank\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By bankname = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By accNo = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By branch = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[3]");
    By address = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[4]");
    By bankType = By.xpath("//android.widget.Button[@content-desc=\"BANK\"]");
    By bankTypeSelect = By.xpath("//android.widget.Button[@content-desc=\"BANK\"]");
    By showAI = By.xpath("//android.widget.Button[@content-desc=\"Show Additional Info\"]");
    By accountHead = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]/android.widget.EditText");
    By accHeadName = By.xpath("//android.widget.EditText");
    By opAmount = By.xpath("//android.widget.EditText[@text=\"0\"]");
    By top = By.xpath("//android.view.View[@content-desc=\"Add Bank\"]");
    By creditAccHead = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[7]/android.widget.EditText");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    
    public void bankInput(String bnam, String acNo, String brnc, String addr, String accHnam, String opamt) throws InterruptedException {
    
        Aclick(accountBtn);
        Aclick(bankBtn);
        Aclick(addBtn);
        Write(bankname, bnam);
        Write(accNo, acNo);
        Write(branch, brnc);
        Write(address, addr);
        Aclick(bankType);
        Aclick(bankTypeSelect);
        Aclick(showAI);
//        Aclick(accountHead);
//        Write(accHeadName, accHnam);
//        Wclick(accHnam);
        Write(opAmount, opamt);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Aclick(top);
        Aclick(creditAccHead);
        Write(accHeadName, accHnam);
        Wclick(accHnam);
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully Created Bank ***");
        System.out.println();

        
    }
    
}
