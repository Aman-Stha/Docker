/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class StockAdjustment extends BasePage {
    
    public StockAdjustment(AndroidDriver driver) {
        
        super(driver);
        
    }
    
    By accountBtn = By.xpath("//android.view.View[@content-desc=\"ACCOUNT\"]");
    By stockManagement = By.xpath("//android.view.View[@content-desc=\"Stock management\"]");
    By stockAdjustment = By.xpath("//android.view.View[@content-desc=\"Stock Adjustment\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By rate = By.xpath("//android.view.View[@content-desc=\"RATE\"]");
    By quantity = By.xpath("//android.view.View[@content-desc=\"QUANTITY\"]");
    By abnormal = By.xpath("//android.view.View[@content-desc=\"ABNORMAL\"]");
    By selectGRN = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By addItemBtn = By.xpath("//android.widget.Button[@content-desc=\"Add Item\"]");
    By remarks = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By adjustStockBtn = By.xpath("//android.widget.Button[@content-desc=\"Adjust Stock\"]");
    
    public void asInput(String rem) throws InterruptedException {
        
        Aclick(accountBtn);
        Aclick(stockManagement);
        Aclick(stockAdjustment);
        Aclick(addBtn);
        Aclick(rate);
        Aclick(selectGRN);
        
        List<WebElement> grnList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectG = grnList.get(10);
        wait.until(ExpectedConditions.elementToBeClickable(SelectG)).click();
        Thread.sleep(1000);
        
        Aclick(addItemBtn);
        List<WebElement> itemList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectI = itemList.get(7);
        wait.until(ExpectedConditions.elementToBeClickable(SelectI)).click();
        Thread.sleep(1000);
        
        Write(remarks, rem);
        Aclick(adjustStockBtn);
        
        System.out.println();
        System.out.println("*** Successfully added stock adjustment ***");
        System.out.println();
        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
    }
    
    
}
