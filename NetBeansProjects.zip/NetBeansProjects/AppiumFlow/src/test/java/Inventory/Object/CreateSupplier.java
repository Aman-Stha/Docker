/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.openqa.selenium.By;

/**
 *
 * @author aman
 */
public class CreateSupplier extends BasePage{
    
    public CreateSupplier(AndroidDriver driver) {
        
        super(driver);
       
    }
    
    By supplier = By.xpath("//android.view.View[@content-desc=\"Suppliers\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By name = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.widget.EditText");
    By address = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By phone = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By showAI = By.xpath("//android.widget.Button[@content-desc=\"Show Additional Info\"]");
    By email = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[3]");
    By code = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[4]");
    By leadTime = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[5]");
    By panNo = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[6]");
    By creditAmt = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[7]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    
    public void csInput(String nam, String addr, String phn, String ema, String cod, String let, String pan, String crAmt) throws InterruptedException {
        
        Aclick(supplier);
        Aclick(addBtn);
        Write(name, nam);
        Write(address, addr);
        Write(phone, phn);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Aclick(showAI);
        Write(email, ema);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Write(code, cod);        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Write(leadTime, let);
        Write(panNo, pan);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Write(creditAmt, crAmt);
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully Created Supplier ***");
        System.out.println();
        
    }
    
}
