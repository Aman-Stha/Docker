/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.openqa.selenium.By;

/**
 *
 * @author aman
 */
public class CashManagement extends BasePage {
    
    public CashManagement(AndroidDriver driver) {
        
        super(driver);
        
    }
    
    By accountBtn = By.xpath("//android.view.View[@content-desc=\"ACCOUNT\"]");
    By cashManagement = By.xpath("//android.view.View[@content-desc=\"Cash Management\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By deposit = By.xpath("//android.view.View[@content-desc=\"DEPOSIT\"]");
    By withdraw = By.xpath("//android.view.View[@content-desc=\"WITHDRAW\"]");
    By transfer = By.xpath("//android.view.View[@content-desc=\"TRANSFER\"]");
    By accountHead = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By amount = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    By approve = By.xpath("//android.widget.Button[@content-desc=\"APPROVE\"]");
    By cancel = By.xpath("//android.widget.Button[@content-desc=\"CANCEL\"]");
    
    public void CMInput(String accHead, String amt) throws InterruptedException {
        
        Aclick(accountBtn);
        Aclick(cashManagement);
        Aclick(addBtn);
        Aclick(deposit); 
        //If you want to withdraw click withdraw button
        //Aclick(withdraw);
        //If you want to transfer click transfer button
        //Aclick(transfer);
        Write(accountHead, accHead);
        Wclick(accHead); 
        
        Write(amount, amt);
        
        Aclick(save); 
        Aclick(approve);
        
        System.out.println();
        System.out.println("*** Successfully Approved Cash Management ***");
        System.out.println();
        
        //If you want to cancle click cancle button
        //Aclick(cancel);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Aclick(accountBtn);
        
    }
    
}
