/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class MainPage {
     public static void main(String[] args) throws InterruptedException {
        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver();

        // Perform login
        login(driver);

        // Perform add customer
        addCustomer(driver);

        // Close the WebDriver after completing the operations
        driver.quit();
    }

    private static void login(WebDriver driver) throws InterruptedException {
        // Perform the login operation using the provided WebDriver instance
        driver.get("http://localhost:7072/#/Login");

        // Call the main method of the Login class
        Login.main(new String[]{});

        // Optional: Add any additional login-related operations here
    }

    private static void addCustomer(WebDriver driver) throws InterruptedException {
        // Perform the add customer operation using the provided WebDriver instance
        driver.get("http://localhost:7072/#/AddCustomer");

        // Call the main method of the AddCustomer class
        AddCustomer.main(new String[]{});

        // Optional: Add any additional add customer-related operations here
    }
}


