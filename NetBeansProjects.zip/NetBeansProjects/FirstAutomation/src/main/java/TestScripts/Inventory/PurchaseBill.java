/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class PurchaseBill {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        
        driver.get("http://localhost:7072/#/Login");
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));          
        
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        By purchase = By.xpath("//a[@id='pnl_Purchase']");    
        By pbill = By.xpath("//a[@id='subpnl_Purchase_Bill']");
        By add = By.xpath("//span[normalize-space()='Add']");
        By supplier = By.xpath("//input[@placeholder='Select Supplier']");
        By slcsup = By.xpath("//li[@aria-label='Amrita Thapa [6985380268]']");
        By grn = By.xpath("//input[@placeholder='Select Good Received Note']");
        By sgrn = By.xpath("//li[@aria-label='Grn No: GRN382-001-80/81 Date:2081-02-04']");
        By confirm = By.xpath("//span[normalize-space()='Confirm Purchase']");
        By paid = By.xpath("//span[@aria-describedby='paidAmountHelp']//input[@role='spinbutton']");
        By save = By.xpath("//span[normalize-space()='Save']");
        By list1 = By.xpath("//tbody/tr[1]/td[2]"); //error
        By makepayment = By.xpath("//span[normalize-space()='Make Payment']");
        By paidamt = By.xpath("//input[@placeholder='Enter Paid Amount']");
        By remarks = By.xpath("//input[@placeholder='Remarks']");
        By makepayment1 = By.xpath("//button[@type='submit']//span[@class='p-button-label'][normalize-space()='Make Payment']");
        
        
        driver.findElement(username).sendKeys("asus");
        driver.findElement(password).sendKeys("nepal@123");
        driver.findElement(signin).click(); 
        driver.findElement(purchase).click();
        driver.findElement(pbill).click();
        driver.findElement(add).click();
        driver.findElement(supplier).click();
        driver.findElement(slcsup).click();
        driver.findElement(grn).click();
        driver.findElement(sgrn).click();
        Thread.sleep(5000);
        driver.findElement(confirm).click();
        driver.findElement(paid).clear();
        driver.findElement(paid).sendKeys("0");
        driver.findElement(save).click();
        
        //Make Payment
        driver.findElement(list1).click();
        driver.findElement(makepayment).click();
        driver.findElement(paidamt).sendKeys("500");
        driver.findElement(remarks).sendKeys("done");
        driver.findElement(makepayment1).click();
        
        
    }
}
