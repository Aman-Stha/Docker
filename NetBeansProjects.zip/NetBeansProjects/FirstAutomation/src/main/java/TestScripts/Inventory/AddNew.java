/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class AddNew {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        
        //open url in browser
        driver.get("https://testsigma.pivotech.com.np/#/Login");
        
        //to maximize the window 
        driver.manage().window().maximize();
        
        //using variable as a locator for elements
        By username = By.xpath("//input[@id='username']");
        By pname = By.xpath("//input[@id='name']");
        By pcode = By.xpath("//input[@id='code']");
        By grpcode = By.xpath("//input[@id='groupCode']");
        By pcategory = By.xpath("//div[@id='category']//button[@type='button']//*[name()='svg']");
        By punit = By.xpath("//div[@id='unitGroup']//button[@type='button']//*[name()='svg']");
        By next1 = By.xpath("//button[@id='btn_basic_next']"); 
        By vat = By.xpath("//input[@id='inp_vatPercent']");
        By pCP = By.xpath("//input[@id='inp_costPrice_0']");
        By pSP = By.xpath("//input[@id='inp_sellingPrice_0']");
        By exp = By.xpath("//button[@aria-label='Row Collapsed']");
        By Pdiscount = By.xpath("//input[@id='inp_purchaseDiscountPercent_0']");
        By Sdiscount = By.xpath("//input[@id='inp_saleDiscountPercent_0']");
        By Mdiscount = By.xpath("//input[@id='inp_maxDiscountPercent_0']");
        By openingQ = By.xpath("//span[@aria-describedby='quantityHelp']//input[@role='spinbutton']");
        By openingR = By.xpath("//span[@aria-describedby='openingStockUnitRateHelp']//input[@role='spinbutton']");
        By batch = By.xpath("//input[@class='p-inputtext p-component']");
        By expType = By.xpath("//div[@class='p-dropdown-trigger']");
        By slcexpType = By.xpath("//li[@aria-label='MONTH']");
        By expLimit = By.xpath("//input[@placeholder='Enter Expiry Limit']");

        By gbarcode = By.xpath("//div[@id='globalBarcode']//input[@type='text']");
        By lbarcode = By.xpath("//div[@id='localBarcode']//input[@type='text']");
        By next2 = By.xpath("//button[@id='btn_next_unit']");
        By manufacture = By.xpath("//input[@id='inp_manufacture']");
        By slcmnu = By.xpath("//li[@id='inp_manufacture_1']");
        By brand = By.xpath("//input[@id='inp_brand']");
        By slcbrand = By.xpath("//li[@id='inp_brand_1']");
        By producttype = By.xpath("//input[@id='inp_productType']");
        By slcPtype = By.xpath("//li[@id='inp_productType_3']"); 
        By tag = By.xpath("//div[@id='inp_productTags']//div[@class='p-multiselect-trigger']");
        By slctag = By.xpath("//li[@id='inp_productTags_2']");
        By closetag = By.xpath("//button[@class='p-multiselect-close p-link']");
        By attribute = By.xpath("//div[@class='p-multiselect-label p-placeholder'][normalize-space()='Select attribute']"); 
        By slcattri = By.xpath("//li[@id='inp_attribute_1']");
        By closeattri = By.xpath("//button[@class='p-multiselect-close p-link']");
        By attriOption = By.xpath("//span[@id='inp_attributeOptions']");
        By slcattriOption = By.xpath("//span[@class='p-dropdown-item-label']");
        By stockOM = By.xpath("//span[@id='inp_stockOutMethod']");
        By slcstockOM = By.xpath("//li[@id='inp_stockOutMethod_1']");
        By stockVM = By.xpath("//span[@id='inp_stockOutRateMethod']");
        By slcstockVM = By.xpath("//li[@id='inp_stockOutRateMethod_2']");
        By epdc = By.xpath("//input[@id='inp_priceDailyChange']");
        By safetystock = By.xpath("//input[@id='inp_safetyStock']");
        By reorderP = By.xpath("//input[@id='inp_reorderQuantity']");
        By shortDecs = By.xpath("//input[@id='inp_shortDescription']");      
        By fullDecs = By.xpath("//input[@id='inp_fullDescription']");      
        By next3 = By.xpath("//button[@id='btn_next_add_info']");
        By next4 = By.xpath("//span[normalize-space()='Next']");
        
        
        //find element using cssSelector
        driver.findElement(username).sendKeys("asus");
        driver.findElement(By.cssSelector("input#password1")).sendKeys("sigma@123");
        driver.findElement(By.cssSelector("button#signIn")).click(); 
                
        //comparing /assertion
        WebElement loginmsg = driver.findElement(By.xpath("//label[normalize-space()='Asus']"));
        String logmsg = loginmsg.getText(); 
        
        if(logmsg.equals("Asus"))
        {
          System.out.println("Login passed");
        }
        else
        {
           System.out.println("Login failed");
        }
        
        
        //Thread.sleep(20000);
        
        //check logo is displayed or not 
        //WebElement logo = driver.findElement(By.xpath("//img[@alt='logo']"));
        //System.out.println(logo.isDisplayed());
//        boolean logo = driver.findElement(By.xpath("//img[@alt='logo']")).isDisplayed();
//        System.out.println((logo));
//        driver.findElement(By.xpath("//button[@aria-label='Close']")).click();
        
        //check is enabled or not 
//        boolean enabled  = driver.findElement(By.xpath("//button[@title='Application All Settings Reload']//span[@class='p-button-icon pi pi-sync']")).isEnabled();
//        System.out.println(enabled);
        
        //adding product
        driver.findElement(By.cssSelector("a#pnl_Product")).click();
        driver.findElement(By.cssSelector("a#subpnl_Product_Details")).click();
        driver.findElement(By.xpath("//span[normalize-space()='Add']")).click();
        driver.findElement(pname).sendKeys("jpt");
        driver.findElement(pcode).sendKeys("jpt");
        driver.findElement(grpcode).sendKeys("gcjpt12345");
        driver.findElement(pcategory).click();   
            Thread.sleep(1000);
        driver.findElement(By.xpath("//li[@id='category_7']")).click();
        driver.findElement(punit).click();
        driver.findElement(By.xpath("//li[@id='unitGroup_2']")).click();
            Thread.sleep(1000);
        WebElement gbcode = driver.findElement(gbarcode);
            gbcode.sendKeys("5319239691237");
            gbcode.sendKeys(Keys.ENTER);
            Thread.sleep(1000);
        WebElement lbcode = driver.findElement(lbarcode);
            lbcode.sendKeys("5389899691237");
            lbcode.sendKeys(Keys.ENTER);        
               
        //check is selected or not 
//        boolean selected = driver.findElement(pcategory).isSelected();
//        System.out.println(selected);
        
        //click next
        driver.findElement(next1).click();
        driver.findElement(vat).clear();
        driver.findElement(vat).sendKeys("13");
        driver.findElement(pCP).clear();
        driver.findElement(pCP).sendKeys("100");
        driver.findElement(pSP).clear();
        driver.findElement(pSP).sendKeys("200");
        driver.findElement(By.xpath("//input[@id='inp_allowDecimalQty_0']")).click();
        driver.findElement(exp).click();
        driver.findElement(Pdiscount).clear();
        driver.findElement(Pdiscount).sendKeys("10");
        driver.findElement(Sdiscount).clear();
        driver.findElement(Sdiscount).sendKeys("5");
        driver.findElement(Mdiscount).clear();
        driver.findElement(Mdiscount).sendKeys("10");
        driver.findElement(openingQ).clear();
        driver.findElement(openingQ).sendKeys("10");        
        driver.findElement(openingR).clear();
        driver.findElement(openingR).sendKeys("150");
        driver.findElement(batch).sendKeys("2");
        driver.findElement(expType).click();
        driver.findElement(slcexpType).click();
        driver.findElement(expLimit).sendKeys("6");
                
        Thread.sleep(5000);
        
        driver.findElement(next2).click();
        driver.findElement(manufacture).click();
        Thread.sleep(5000);
        driver.findElement(slcmnu).click();
        driver.findElement(brand).click();
        driver.findElement(slcbrand).click();
        driver.findElement(producttype).click();
        driver.findElement(slcPtype).click();
        driver.findElement(tag).click();
        driver.findElement(slctag).click();
        driver.findElement(closetag).click();
        driver.findElement(attribute).click();
        driver.findElement(slcattri).click();
        driver.findElement(closeattri).click();
        driver.findElement(attriOption).click();       
        driver.findElement(slcattriOption).click();
        driver.findElement(stockOM).click();
        driver.findElement(slcstockOM).click();
        driver.findElement(stockVM).click();
        driver.findElement(slcstockVM).click();
        driver.findElement(epdc).click();
        driver.findElement(safetystock).sendKeys("10");
        driver.findElement(reorderP).sendKeys("5");
        driver.findElement(shortDecs).sendKeys("This is random");
        driver.findElement(fullDecs).sendKeys("This is random full desc");
        driver.findElement(next3).click();
        driver.findElement(next4).click();
        driver.findElement(By.xpath("//span[normalize-space()='Save Product']")).click();
        
        Thread.sleep(5000);
        driver.findElement(By.xpath("//td[normalize-space()='jpt']")).click();
        boolean item = driver.findElement(By.xpath("//td[normalize-space()='jpt123']")).isDisplayed();
        System.out.println(item); 
    }
}
