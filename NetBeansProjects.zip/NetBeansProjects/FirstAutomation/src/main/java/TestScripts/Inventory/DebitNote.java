/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class DebitNote {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();

        driver.get("http://localhost:7072/#/Login");

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));          
        
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        By purchase = By.xpath("//a[@id='pnl_Purchase']");  
        By debitnote = By.xpath("//span[normalize-space()='Debit Note | Purchase Return']");
        By add = By.xpath("//button[@aria-label='Add']");
        By supplier = By.xpath("//input[@placeholder='Select Supplier']");
        By slcsup = By.xpath("//li[@aria-label='Amrita Thapa [6985380268]']");
        By grn = By.xpath("//input[@placeholder='Select Good Received Note']");
        By sgrn = By.xpath("//li[@aria-label='Grn No: GRN383-001-80/81 Date:2081-02-04']");
        By confirm = By.xpath("//span[normalize-space()='Confirm Debit Note']");
        By remarks = By.xpath("//input[@placeholder='Enter Remarks']");
        By save = By.xpath("//span[normalize-space()='Save']");
        
        driver.findElement(username).sendKeys("asus");
        driver.findElement(password).sendKeys("nepal@123");
        driver.findElement(signin).click(); 
        driver.findElement(purchase).click();   
        driver.findElement(debitnote).click();
        driver.findElement(add).click();
        driver.findElement(supplier).click();
            Thread.sleep(5000);
        driver.findElement(slcsup).click();
        driver.findElement(grn).click();
            Thread.sleep(5000);
        driver.findElement(sgrn).click();
            Thread.sleep(5000);
        driver.findElement(confirm).click();
        driver.findElement(remarks).sendKeys("done");
        driver.findElement(save).click();
        
    }
}
