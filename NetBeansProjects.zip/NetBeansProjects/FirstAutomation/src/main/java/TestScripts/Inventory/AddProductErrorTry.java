/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class AddProductErrorTry {
    public static void main(String[] args) throws FileNotFoundException, IOException, CsvValidationException, InterruptedException {
        
        WebDriver driver = new ChromeDriver();
             
            
            CSVReader reader = new CSVReader(new FileReader("/home/aman/Users/Jmeter/login.csv"));
            reader.readNext();
            String[] str;
            
            while((str=reader.readNext())!=null){
                for(String s : str) {
                    System.out.print(s+" ");
                }
                System.out.println();

                String username = str[0];
                String password = str[1];

                driver.get("https://testsigma.pivotech.com.np/#/Login");
                driver.manage().window().maximize();

                driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
                driver.findElement(By.cssSelector("input#password1")).sendKeys(password);
                driver.findElement(By.cssSelector("button#signIn")).click(); 

                Thread.sleep(5000);
                //driver.findElement(By.xpath("//span[@class='p-button-icon pi pi-sign-out']")).click();
                //sign out only needed when multiple users are passed
                
                break; //it will only run the loop for once
            }
            
            driver.findElement(By.xpath("//a[@id='pnl_Product']")).click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//span[normalize-space()='Product Details']")).click();
            Thread.sleep(3000);
                       
            
            CSVReader product = new CSVReader(new FileReader("/home/aman/Users/Jmeter/CSV/addproduct.csv"));
            product.readNext();
            String[] pro;
            
            while((pro=product.readNext())!=null) {
                String name = pro[0];
                String code = pro[1];
                String groupCode = pro[2];
                //String productNature = pro[3];
                String category = pro[4];
                String unitGroup = pro[5];
                String gbc = pro[6];
                String lbc = pro[7];
                String vat = pro[8];
                String cp = pro[9];
                String sp = pro[10];
                String pd = pro[11];
                String sd = pro[12];
                String smd = pro[13];
                String osq = pro[14];
                String osr = pro[15];
                String bn = pro[16];
                String el = pro[17];
                String manu = pro[18];
                String brand = pro[19];
                String ptype = pro[20];
                String ss = pro[21];
                String rp = pro[22];
                String shortD = pro[23];
                String fullD = pro[24];
                
                driver.findElement(By.xpath("//span[normalize-space()='Add']")).click();
                    Thread.sleep(3000); 
                
                driver.findElement(By.xpath("//input[@id='name']")).sendKeys(name);
                driver.findElement(By.xpath("//input[@id='code']")).sendKeys(code);
                driver.findElement(By.xpath("//input[@id='groupCode']")).sendKeys(groupCode);
                //driver.findElement(By.xpath("")).sendKeys(productNature);
                driver.findElement(By.xpath("//input[@id='category']")).sendKeys(category);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//li[@id='category_0']")).click();
                driver.findElement(By.xpath("//input[@id='unitGroup']")).sendKeys(unitGroup); 
                Thread.sleep(1000);
                driver.findElement(By.xpath("//li[@id='unitGroup_0']")).click();
                WebElement gbcode = driver.findElement(By.xpath("//div[@id='globalBarcode']//input[@type='text']"));
                    gbcode.sendKeys(gbc);
                    gbcode.sendKeys(Keys.ENTER);
                    Thread.sleep(1000);
                WebElement lbcode = driver.findElement(By.xpath("//div[@id='localBarcode']//input[@type='text']"));
                    lbcode.sendKeys(lbc);
                    lbcode.sendKeys(Keys.ENTER);                
                driver.findElement(By.xpath("//button[@id='btn_basic_next']")).click();
                
                //next page
                WebElement invat = driver.findElement(By.xpath("//input[@id='inp_vatPercent']"));
                        invat.clear();
                        invat.sendKeys(vat);
                WebElement incp = driver.findElement(By.xpath("//input[@id='inp_costPrice_0']"));
                        incp.clear();
                        incp.sendKeys(cp);
                WebElement insp = driver.findElement(By.xpath("//input[@id='inp_sellingPrice_0']"));
                        insp.clear();
                        insp.sendKeys(sp);
                driver.findElement(By.xpath("//button[@aria-label='Row Collapsed']")).click();
                driver.findElement(By.xpath("//input[@id='inp_allowDecimalQty_0']")).click();
                Thread.sleep(3000);                
                WebElement inpd = driver.findElement(By.xpath("//input[@id='inp_purchaseDiscountPercent_0']"));
                        inpd.clear();
                        inpd.sendKeys(pd);
                WebElement insd = driver.findElement(By.xpath("//input[@id='inp_saleDiscountPercent_0']"));
                        insd.clear();
                        insd.sendKeys(sd);
                WebElement insmd = driver.findElement(By.xpath("//input[@id='inp_maxDiscountPercent_0']"));
                        insmd.clear();
                        insmd.sendKeys(smd);
                WebElement iosq = driver.findElement(By.xpath("//span[@aria-describedby='quantityHelp']//input[@role='spinbutton']"));
                        iosq.clear();
                        iosq.sendKeys(osq);
                WebElement iosr = driver.findElement(By.xpath("//span[@aria-describedby='openingStockUnitRateHelp']//input[@role='spinbutton']"));
                        iosr.clear();
                        iosr.sendKeys(osr);
                driver.findElement(By.xpath("//input[@class='p-inputtext p-component']")).sendKeys(bn);
                driver.findElement(By.xpath("//div[@class='p-dropdown-trigger']")).click();
                driver.findElement(By.xpath("//li[@aria-label='MONTH']")).click();
                driver.findElement(By.xpath("//input[@placeholder='Enter Expiry Limit']")).sendKeys(el);
                Thread.sleep(5000);
                driver.findElement(By.xpath("//button[@id='btn_next_unit']")).click();
                
                //next page                             
                driver.findElement(By.xpath("//input[@id='inp_manufacture']")).sendKeys(manu);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//li[@id='inp_manufacture_0']")).click();
                driver.findElement(By.xpath("//input[@id='inp_brand']")).sendKeys(brand);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//li[@id='inp_brand_0']")).click();                
                driver.findElement(By.xpath("//input[@id='inp_productType']")).sendKeys(ptype);
                Thread.sleep(1000);
                driver.findElement(By.xpath("//li[@id='inp_productType_0']")).click();              

                By tag = By.xpath("//div[@id='inp_productTags']//div[@class='p-multiselect-trigger']");
                By slctag = By.xpath("//li[@id='inp_productTags_2']");
                By closetag = By.xpath("//button[@class='p-multiselect-close p-link']");
                driver.findElement(tag).click();
                Thread.sleep(1000);
                driver.findElement(slctag).click();
                driver.findElement(closetag).click();
                
                By attribute = By.xpath("//div[@class='p-multiselect-label p-placeholder'][normalize-space()='Select attribute']"); 
                By slcattri = By.xpath("//li[@id='inp_attribute_1']");
                By closeattri = By.xpath("//button[@class='p-multiselect-close p-link']");
                By attriOption = By.xpath("//span[@id='inp_attributeOptions']");
                By slcattriOption = By.xpath("//span[@class='p-dropdown-item-label']");
                driver.findElement(attribute).click();
                Thread.sleep(1000);
                driver.findElement(slcattri).click();
                driver.findElement(closeattri).click();
                Thread.sleep(1000);
                driver.findElement(attriOption).click();      
                Thread.sleep(1000);
                driver.findElement(slcattriOption).click();
                               
                By stockOM = By.xpath("//span[@id='inp_stockOutMethod']");
                By slcstockOM = By.xpath("//li[@id='inp_stockOutMethod_1']");
                By stockVM = By.xpath("//span[@id='inp_stockOutRateMethod']");
                By slcstockVM = By.xpath("//li[@id='inp_stockOutRateMethod_2']");
                driver.findElement(stockOM).click();
                driver.findElement(slcstockOM).click();
                driver.findElement(stockVM).click();
                driver.findElement(slcstockVM).click();
                By epdc = By.xpath("//input[@id='inp_priceDailyChange']");   
                driver.findElement(epdc).click();
                
                driver.findElement(By.xpath("//input[@id='inp_safetyStock']")).sendKeys(ss);
                driver.findElement(By.xpath("//input[@id='inp_reorderQuantity']")).sendKeys(rp);
                driver.findElement(By.xpath("//input[@id='inp_shortDescription']")).sendKeys(shortD);
                driver.findElement(By.xpath("//input[@id='inp_fullDescription']")).sendKeys(fullD);
                driver.findElement(By.xpath("//button[@id='btn_next_add_info']")).click();  
                Thread.sleep(2000);
                
                //next page
                By next3 = By.xpath("//button[@id='btn_next_add_images']");
                driver.findElement(next3).click();
                Thread.sleep(1000);
                driver.findElement(By.xpath("//span[normalize-space()='Save Product']")).click(); 
                
                Thread.sleep(5000);
                driver.findElement(By.xpath("//td[normalize-space()='" + name + "']")).click();
                boolean item = driver.findElement(By.xpath("//td[normalize-space()='"+ name +"']")).isDisplayed();
                System.out.println(item); 
                Thread.sleep(3000);
                
            }
        
    }
}
