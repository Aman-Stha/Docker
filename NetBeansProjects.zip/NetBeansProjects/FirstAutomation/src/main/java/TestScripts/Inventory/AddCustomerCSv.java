/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class AddCustomerCSv {
    public static void main(String[] args) throws FileNotFoundException, IOException, CsvValidationException, InterruptedException {
        
        WebDriver driver = new ChromeDriver();
        
        driver.get("http://localhost:7072/#/Login");
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));   
        
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        
        driver.findElement(username).sendKeys("asus");
        driver.findElement(password).sendKeys("nepal@123");
        driver.findElement(signin).click(); 
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[normalize-space()='Sales']")).click();
        driver.findElement(By.xpath("//span[normalize-space()='Customer']")).click();

        CSVReader customer = new CSVReader(new FileReader("/home/aman/Users/Jmeter/CSV/customer.csv"));
        customer.readNext();
        String[] cus;
        
        while((cus=customer.readNext())!=null) {
            String name = cus[0];
            String email = cus[1];
            String address = cus[2];
            String joinDate = cus[3];
            String phone = cus[4];
            String pan = cus[5];
            String cra = cus[6];
            String crl = cus[7];
            
            driver.findElement(By.xpath("//span[normalize-space()='Add']")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@placeholder='Enter Name']")).sendKeys(name);
            driver.findElement(By.xpath("//input[@placeholder='Enter Email ']")).sendKeys(email);
            driver.findElement(By.xpath("//input[@placeholder='Enter Address']")).sendKeys(address);

            WebElement joined = driver.findElement(By.xpath("//input[@placeholder='YYYY-MM-DD']"));
                joined.clear();
                joined.sendKeys(joinDate);
                
            driver.findElement(By.xpath("//input[@placeholder='Enter Phone Number']")).sendKeys(phone);               
            driver.findElement(By.xpath("//input[@placeholder='Enter Pan Number']")).sendKeys(pan);
            
            WebElement cramount = driver.findElement(By.xpath("//span[@aria-describedby='creditAmountHelp']//input[@role='spinbutton']"));
                Thread.sleep(1000);
                cramount.clear();
                cramount.sendKeys(cra);
            
            WebElement crlimit = driver.findElement(By.xpath("//span[@aria-describedby='creditLimitHelp']//input[@role='spinbutton']"));
                Thread.sleep(1000);
                crlimit.clear();
                crlimit.sendKeys(crl);
            Thread.sleep(2000);
            
            driver.findElement(By.xpath("//span[normalize-space()='Save Customer']")).click();
            Thread.sleep(5000);
            
            driver.findElement(By.xpath("//td[normalize-space()='"+name+"']")).click();
            boolean item = driver.findElement(By.xpath("//td[normalize-space()='"+ name +"']")).isDisplayed();
                System.out.println(item); 
                Thread.sleep(3000);
           
            break;
        }
        
    }
}
