/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts.Inventory;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class GRN {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        
        //open url in browser
        driver.get("http://localhost:7072/#/Login");
        
        //to maximize the window 
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));  
            //this is applicable for all test scripts in this class
            //it is active till we close our driver 
            //we need to specify it on top 
            
        
        By username = By.xpath("//input[@id='username']");
        By password = By.xpath("//input[@id='password1']");
        By signin = By.xpath("//button[@id='signIn']");
        By purchase = By.xpath("//a[@id='pnl_Purchase']");        
        By grn = By.xpath("//a[@id='subpnl_Good_Received Note']");
        By add = By.xpath("//button[@aria-label='Add']");
        By deliveredby = By.xpath("//input[@id='deliveredBy']");
        By recievedby = By.xpath("//input[@placeholder='Select Received by']");
        By rby = By.xpath("//li[@aria-label='sauraj']");
        By supplier = By.xpath("//input[@placeholder='Select Supplier']");
        By slcsup = By.xpath("//li[@aria-label='Amrita Thapa [6985380268]']");
        By porder = By.xpath("//input[@id='selectedProduct']");
        //By ordernum = By.xpath("//li[@aria-label='Order No: PO216-001-80/81 Order Date:2081-02-03']");
        By confirm = By.xpath("//span[normalize-space()='Confirm Good Received Note']");
        By save = By.xpath("//span[normalize-space()='Save']");
        
        driver.findElement(username).sendKeys("asus");
        driver.findElement(password).sendKeys("nepal@123");
        driver.findElement(signin).click(); 
        driver.findElement(purchase).click();
        driver.findElement(grn).click();
        driver.findElement(add).click();
        driver.findElement(deliveredby).sendKeys("abc");
        driver.findElement(recievedby).click();
        driver.findElement(rby).click();
        driver.findElement(supplier).click();
        driver.findElement(slcsup).click();
        driver.findElement(porder).click();
        driver.findElement(porder).sendKeys("Order No: PO215-001-80/81 Order Date:2081-02-03");
                Thread.sleep(5000);
        driver.findElement(porder).sendKeys(Keys.ENTER);
                Thread.sleep(5000);
        //driver.findElement(ordernum).click();
        Thread.sleep(5000);
        driver.findElement(confirm).click();
        driver.findElement(save).click();
        
    }
}
