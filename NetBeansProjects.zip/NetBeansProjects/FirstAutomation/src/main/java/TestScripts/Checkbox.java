/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import java.util.List;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author aman
 */
public class Checkbox {
    public static void main(String[] args) throws InterruptedException {
                    
        WebDriver driver = new ChromeDriver();
        
//        ------ Checkboxes: ------

//        driver.get("https://testautomationpractice.blogspot.com/");
//        driver.manage().window().maximize();
//
//        //1) Select specific checkbox
//        //driver.findElement(By.xpath("//input[@id='sunday']")).click();
//        
//        //2) Select all checkboxes
//        List<WebElement> check = driver.findElements(By.xpath("//input[@class='form-check-input'and @type='checkbox']"));
        
//        for(int i=0; i<=check.size(); i++) {
//            check.get(i).click();
//        }
        
//        for(WebElement checkbox:check){
//            checkbox.click();
//        }
        
        //3) Selecting last 3 checkboxes
//        for(int i=4; i<=check.size(); i++) {
//            check.get(i).click();
//        }        
        
//      ------ Alerts: ------ 

        driver.get("https://the-internet.herokuapp.com/javascript_alerts");
        driver.manage().window().maximize();
        
        // 1) Normal alert with okay button
        driver.findElement(By.xpath("//button[@onclick='jsAlert()']")).click();
        Thread.sleep(3000);
        Alert myalert = driver.switchTo().alert();
        System.out.println(myalert.getText());
        myalert.accept(); //click on ok
        
        // 2) Conformation alert having OK and Cancel
        driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
        Thread.sleep(3000);
        Alert alert2 = driver.switchTo().alert();
        System.out.println(alert2.getText());
        alert2.dismiss(); //click on cancel
        
        // 3) Prompt alert
        driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();
        Thread.sleep(3000);
        Alert alert3 = driver.switchTo().alert();
        System.out.println(alert3.getText());
        alert3.sendKeys("Hello World");
        alert3.accept();
        
        // 4) Basic auth alert
//      driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth"); //username:admin & pass:admin
        
    }
}
