/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author aman
 */
public class HandleExcelFiles {
    
    //We use FileInputStream to read file from excel files
    //We use FileOutputStream to write in excel files 
        
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        // 1) Read data from excel file 
            FileInputStream file = new FileInputStream("/home/aman/NetBeansProjects/FirstAutomation/csv/prac.xlsx");
            //get workbook
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            //get worksheet/sheet
            XSSFSheet sheet = workbook.getSheet("Sheet1"); //to get sheet we use getSheet("...sheet-name...")
            //find number of rows
            int totalRows = sheet.getLastRowNum();
            //find total number of cells
            int totalCells = sheet.getRow(0).getLastCellNum(); //first select/get row in 0 index and find total cells of that row 

            System.out.println(totalRows);
            System.out.println(totalCells);
            
            //loop for rows and cells
            for (int r = 0; r <= totalRows; r++) 
            {
                XSSFRow currentRow = sheet.getRow(r);
                for (int c = 0; c < totalCells; c++) 
                {
                    XSSFCell cell = currentRow.getCell(c);
                    System.out.print(cell.toString()+"\t"); //"\t" will print data in next line but should be print not println
                }
                System.out.println(); //after using print only we should use println after loop
            }
            
    }
    
    //to write in excel files     
    public class Write {
        public void writes() throws FileNotFoundException, IOException {

            FileOutputStream file1 = new FileOutputStream("/home/aman/NetBeansProjects/FirstAutomation/csv/prac123.xlsx");

            //Create workbook
            XSSFWorkbook workbook = new XSSFWorkbook();
            //Create sheet
            XSSFSheet sheet1 = workbook.createSheet("Mysheet"); //to create sheet we use createSheet("...sheet-name...")
            //Create row
            XSSFRow row1 = sheet1.createRow(0);
                //Create cells in row1
                row1.createCell(0).setCellValue("Welcome");
                row1.createCell(1).setCellValue(1234);
                row1.createCell(2).setCellValue("Selenium");
            //Create another row
            XSSFRow row2 = sheet1.createRow(0);
                //Create cells in row2
                row2.createCell(0).setCellValue("Goodbye");
                row2.createCell(1).setCellValue(1234);
                row2.createCell(2).setCellValue("Appium");
            //Create another row
            XSSFRow row3 = sheet1.createRow(0);
                //Create cells in row2
                row3.createCell(0).setCellValue("Tata");
                row3.createCell(1).setCellValue(1234);
                row3.createCell(2).setCellValue("React");

            workbook.write(file1);
            
        }   
    }
}
