/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class WebTables {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://testautomationpractice.blogspot.com/");
        driver.manage().window().maximize();  
        
//      ------Static Table------

//      1) Find total number of rows in table 
        int rows = driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();        
        System.out.println("Number of rows: " + rows);

//      2) Find total number of columns in the table        
        int cols = driver.findElements(By.xpath("//table[@name='BookTable']//th")).size();
        System.out.println("Number of columns: " + cols);
    
//      3) Read data frm specific row and column (eg: 5th row 1st column)
        String bookname = driver.findElement(By.xpath("//table[@name='BookTable']//tr[5]//td[1]")).getText();
        System.out.println(bookname);
        
//      4) Read data from all rows and columns 
        for(int r=2; r<=rows; r++) 
        {
            for(int c=1; c<=cols; c++) 
            {
                String value = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td["+c+"]")).getText();
                System.out.print(value+"\t");
            }
            System.out.println();
        }
        
//      5) Print whose author is mukesh
        for(int r=2; r<=rows; r++) {
            String author = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[2]")).getText();
            if(author.equals("Mukesh")){
                String book = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[1]")).getText();
                System.out.println(book);
            }
        }
        
        
//      ------Dynamic and pagination table------
        
        
    }
}
