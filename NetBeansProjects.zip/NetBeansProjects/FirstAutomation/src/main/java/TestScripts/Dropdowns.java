/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/**
 *
 * @author aman
 */
public class Dropdowns {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));        
        
            
        
//      ------Select dropdown------
//      driver.get("https://testautomationpractice.blogspot.com/");
//      driver.manage().window().maximize();  
//      WebElement dropdown = driver.findElement(By.xpath("//select[@id='country']"));
//      Select drpcountry = new Select(dropdown);
//        
//      select options from dropdown
//        drpcountry.selectByIndex(3);
//        drpcountry.selectByVisibleText("China");
//        Capture the options from the dropdown
//        List<WebElement>options = drpcountry.getOptions();
//        System.out.println("Number of options are:" + options.size());
//        print all options
//        for(int i=0;i<options.size();i++) {
//          System.out.println(options.get(i).getText());
//        }
//        
//        for(WebElement op:options) {
//            System.out.println(op.getText());
//        }
        
        
//      ------Hidden Dropdowns------
//        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//        driver.manage().window().maximize();
//        driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Admin");
//        driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("admin123");   
//        driver.findElement(By.xpath("//button[@type='submit']")).click();
//        
//        driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'][normalize-space()='PIM']")).click();
//        driver.findElement(By.xpath("//div[6]//div[1]//div[2]//div[1]//div[1]//div[2]")).click();
        
        
//      ------Auto Suggest Dropdown-----
        driver.get("https://www.google.com");
        driver.manage().window().maximize();
        driver.findElement(By.name("q")).sendKeys("selenium");
        Thread.sleep(5000);
        List <WebElement> list = driver.findElements(By.xpath("//ul[@role='listbox']//li//div[@role='option']"));
        System.out.println(list.size());
        
        for(int i=0;i<list.size();i++){
            System.out.println(list.get(i).getText());
            if(list.get(i).getText().equals("selenium")){
                list.get(i).click();
                break;
            }
        }
        
    }
    
}
