/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestScripts;

import java.io.File;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author aman
 */
public class CapturingScreenshots {
    public static void main(String[] args) {
        
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.nopcommerce.com/");
        driver.manage().window().maximize();
        
        //Capture full page SS
        TakesScreenshot ts = (TakesScreenshot)driver; //We need to do typecasting for TakesScreenshot when we use WebDriver
        File sourcefile = ts.getScreenshotAs(OutputType.FILE); //captured the ss but we dont know the location
        File targetfile = new File(System.getProperty("user.dir")+"\\screenshots\\fullss.png"); 
            //System.getProperty("user.dir") --> location of our current directory
        sourcefile.renameTo(targetfile); //copy sourcefile to targetfile
                
        //Capture a group of elements ss
        WebElement ele = driver.findElement(By.xpath("give path"));
        File sourcefile1 = ele.getScreenshotAs(OutputType.FILE); 
        File targetfile1 = new File(System.getProperty("user.dir")+"\\screenshots\\elementss.png"); 
        sourcefile1.renameTo(targetfile1);
        
        //Capture single element 
        WebElement ele1 = driver.findElement(By.xpath("give path"));
        File sourcefile2 = ele.getScreenshotAs(OutputType.FILE); 
        File targetfile2 = new File(System.getProperty("user.dir")+"\\screenshots\\element2ss.png"); 
        sourcefile1.renameTo(targetfile1);
        
    }
}
