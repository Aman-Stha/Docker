/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class DataProviderDemo {
    
    WebDriver driver;
    
    @BeforeClass
    public void setup() {
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions options = new FirefoxOptions();
        options.setBinary("/snap/bin/firefox");
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
    
    @Test(dataProvider = "dp")
    public void login(String email, String pass) throws InterruptedException {

        driver.get("https://tutorialsninja.com/demo/index.php?route=account/login");
        driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email);
        driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys(pass);
        driver.findElement(By.xpath("//input[@value='Login']")).click();
        Thread.sleep(4000);
        boolean status = driver.findElement(By.xpath("//h2[normalize-space()='My Account']")).isDisplayed();
        if(status == true) {
            driver.findElement(By.xpath("//a[@class='list-group-item'][normalize-space()='Logout']")).click();
            Assert.assertTrue(true);
        }
        else {
            Assert.fail();
        }

    }
    
    @AfterClass
    public void teardown() {
        driver.close();
    }
    
    @DataProvider(name = "dp")
    public Object[][] loginData() {
        
        Object data[][] = { 
            {"abc@gmail.com","1234"},
            {"pavanol123@gmail.com","test@123"},
            {"abc@gmail.com","test@123"},
            {"abcdef@gmail.com","abcdef"},
        };
        
        return data;
        
    }
    
}
