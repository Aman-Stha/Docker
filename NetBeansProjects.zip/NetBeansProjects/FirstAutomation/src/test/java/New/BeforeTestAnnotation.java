package New;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class BeforeTestAnnotation {
    
    
    @BeforeTest
    public void login() {
        System.out.println("Login successful");
    }
    
    @Test(priority = 1)
    public void search() {
        System.out.println("Searching...");

    }
}
