/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import org.testng.ITestListener;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.testng.ITestContext;
import org.testng.ITestResult;

/**
 *
 * @author aman
 */
public class ExtentReport implements ITestListener {
    
    public ExtentSparkReporter sparkReporter; //UI of the report
    public ExtentReports extent; // populate common info on the report
    public ExtentTest test; // creating test caase entries in the report and update status of the test methods
    
    public void onStart(ITestContext context) {
        
        sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/src/test/java/New/myReport.html"); // specify location
        sparkReporter.config().setDocumentTitle("Automation Report"); // Title of the report
        sparkReporter.config().setReportName("Functional Testing"); // Name of the report
        sparkReporter.config().setTheme(Theme.DARK); // Theme 
        
        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);
        
        extent.setSystemInfo("Computer Name", "localhost");
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("Tester Name", "Aman");
        extent.setSystemInfo("os", "Linux");
        extent.setSystemInfo("Browser Name", "Chrome");
        
    }
    
    public void onTestSuccess(ITestResult result) {
        
        test = extent.createTest(result.getName()); // create new entry in the report
        test.log(Status.PASS, "Test case Passed : " + result.getName());      
        
    }
    
    public void onTestFailure(ITestResult result) {
        
        test = extent.createTest(result.getName());
        test.log(Status.FAIL, "Test case Failed : " + result.getName());
        test.log(Status.FAIL, "Test case Failed cause is : " + result.getThrowable());        
        
    }
    
    public void onTestSkipped(ITestResult result) {
        
        test = extent.createTest(result.getName());
        test.log(Status.SKIP, "Test case Skipped : " + result.getName());
        
    }
    
    public void onFinish(ITestContext context) {
        
        extent.flush();
        
    }
    
}
