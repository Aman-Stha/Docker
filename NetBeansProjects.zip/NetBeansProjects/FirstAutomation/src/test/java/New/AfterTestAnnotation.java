/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class AfterTestAnnotation {
    
    @Test(priority = 2)
    public void advanceSearch() {
        System.out.println("Advance Searching...");
    }
    
    @AfterClass
    public void logout() {
        System.out.println("Logging Out");
    }
    
}
