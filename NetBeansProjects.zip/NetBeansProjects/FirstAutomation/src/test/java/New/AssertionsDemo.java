/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/**
 *
 * @author aman
 */
public class AssertionsDemo {
    
    
    @Test
    public void testTitle() { 
    
        String exp_title = "Open Cart";
        String act_title = "Open Cart";
        
        Assert.assertEquals(exp_title, act_title);
        
    }
        
    //Soft Assertions Example
    @Test
    public void SoftAssertions() { 
        
        //To use soft assert we need to import SoftAssert from testNG and create an object for it 
        SoftAssert sa = new SoftAssert();
        sa.assertEquals(123, 345);
        
        //After using soft assertion we must declare assert all it is compulsory
        sa.assertAll();
    }
    
    //Hard Assertions Example
    @Test
    public void HardAssertions() {
        
        Assert.assertEquals("xyz", "xyz"); //pass
        Assert.assertEquals(123, 345); //fail
        
        Assert.assertTrue(true); //pass
        Assert.assertTrue(false); //fail
        
        Assert.assertTrue(1==1); //pass
        Assert.assertTrue(1==2); //fail
        
        Assert.assertFalse(1==1); //fail
        Assert.assertFalse(1==2); //pass
        
        // Assert.fail(); //This will directly fail our test method even if it passed
        
        //The main drawback of hard assertion is that after assertion is failed it will not execute remaining test scripts
        
    }
        
}
