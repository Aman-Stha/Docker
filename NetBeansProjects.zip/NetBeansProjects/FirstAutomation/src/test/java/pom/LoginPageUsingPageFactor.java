/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author aman
 */
public class LoginPageUsingPageFactor {
    
    WebDriver driver;
    
    //Constructor -- should be same as class name
    public LoginPageUsingPageFactor(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this); //this is compulsory when using page factory or else this will not work
    }
        
    //Locators
    @FindBy(xpath = "//input[@placeholder='Username']")
    WebElement username;
    @FindBy(xpath = "//input[@placeholder='Password']")
    WebElement password;
    @FindBy(xpath = "//button[@type='submit']")
    WebElement loginBtn;
    
    //Action Methods   
    public void LoginInput1(String user1, String pass1) {
        
       username.sendKeys(user1);
       password.sendKeys(pass1);
       loginBtn.click();
        
    }    
    
}
