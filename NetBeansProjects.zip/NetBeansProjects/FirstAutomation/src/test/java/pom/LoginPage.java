/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author aman
 */
public class LoginPage {
    
    WebDriver driver;
    
    //Constructor -- should be same as class name
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }
        
    //Locators
    By username = By.xpath("//input[@placeholder='Username']");
    By password = By.xpath("//input[@placeholder='Password']");
    By loginBtn = By.xpath("//button[@type='submit']");
    
    //Action Methods   
    public void LoginInput(String user, String pass) {
        
        driver.findElement(username).sendKeys(user);
        driver.findElement(password).sendKeys(pass);        
        driver.findElement(loginBtn).click();
        
    }
    
}
