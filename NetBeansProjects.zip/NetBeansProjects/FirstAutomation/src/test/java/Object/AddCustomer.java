/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddCustomer {
    WebDriver driver;
    WebDriverWait wait;
    
    public AddCustomer(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    By sales = By.xpath("//a[@id='pnl_Sales']");
    By customer = By.xpath("//a[@id='subpnl_Customer']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By name = By.xpath("//input[@placeholder='Enter Name']");
    By email = By.xpath("//input[@placeholder='Enter Email ']");
    By address = By.xpath("//input[@placeholder='Enter Address']");
    By phone = By.xpath("//input[@placeholder='Enter Phone Number']");
    By pan = By.xpath("//input[@placeholder='Enter Pan Number']");
    By category = By.xpath("//input[@placeholder='Select Customer Category']");
    By creamount = By.xpath("//span[@aria-describedby='creditAmountHelp']//input[@value='0.00']");
    By crelimit = By.xpath("//span[@aria-describedby='creditLimitHelp']//input[@value='0.00']");
    By tou = By.xpath("//div[@class='p-dialog-header']");
    By save = By.xpath("//button[@aria-label='Save Customer']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");
    
    public void inputAddCus(String nam, String adr, String ema, String ph, String pn, String cat, String crea, String crel) {
        
        Aclick(sales);
        Aclick(customer);
        Aclick(add);
        write(name, nam);
        write(email, ema);
        write(address, adr);
        write(phone, ph);
        write(pan, pn);
        write(category, cat);
        Aclick(tou);
        write(creamount, crea);
        write(crelimit, crel);
        Aclick(save);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();
        
        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();
        
    }
    
    private void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    private void write(By locator1, String value) {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
    
}
