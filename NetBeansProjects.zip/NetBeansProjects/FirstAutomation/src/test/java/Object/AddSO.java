/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddSO {
    WebDriver driver;
    WebDriverWait wait;
    
    public AddSO(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    By sales = By.xpath("//a[@id='pnl_Sales']");
    By salesorder = By.xpath("//span[normalize-space()='Sales Order']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By shipTo = By.xpath("//input[@id='shipTo']");
    By customer = By.xpath("//input[@placeholder='Select Customer']");
    By product = By.xpath("//input[@id='selectedProduct']");
    By confirm = By.xpath("//button[@aria-label='Confirm Sales Order']");
    By save = By.xpath("//span[normalize-space()='Save']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");
    
    //For sales invoice
    By view = By.xpath("//tbody/tr[1]/td[11]/button[1]");
    By salesInvoice = By.xpath("//button[@aria-label='Convert To Sales Invoice']");
    By confirmBtn = By.xpath("//span[normalize-space()='Confirm Sale']");
    By saveBtn = By.xpath("//span[normalize-space()='Save']");

    public void inputAddSO(String shp, String cus, String pro) throws InterruptedException {
        
        Aclick(sales);
        Aclick(salesorder);
        Aclick(add);
        write(shipTo, shp);
        selectFromDropdown(customer, cus);
        selectFromDropdown(product, pro);
        Thread.sleep(1000);
        Aclick(confirm);
        Aclick(save);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();
        
        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();
        
        Aclick(view);
        Aclick(salesInvoice);
        Aclick(confirmBtn);
        Aclick(saveBtn);
        
        WebElement msgs1 = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg1 = msgs1.getText();
        System.out.println();
        System.out.println("***** " + msg1 + " *****");
        System.out.println();
        
    }
    
    private void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        dropdown.sendKeys(value);
        Thread.sleep(2000);
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
    
    private void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    private void write(By locator1, String value) {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
    
}
