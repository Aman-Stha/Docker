/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddProduct {
    
    WebDriver driver;
    WebDriverWait wait;
    
    public AddProduct(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    //1st Page
    By clickProduct = By.xpath("//a[@id='pnl_Product']");
    By subProduct = By.xpath("//span[normalize-space()='Product Details']");
    By add = By.xpath("//span[normalize-space()='Add']");
    
    By pname = By.xpath("//input[@id='name']");
    By trigger = By.xpath("//div[@class='p-dropdown-trigger']");
    By pcode = By.xpath("//input[@id='code']");
    By hsCode = By.xpath("//input[@id='hsCode']");
    By grpcode = By.xpath("//input[@id='groupCode']");
    By pcategory = By.xpath("//input[@id='category']");
    By punit = By.xpath("//input[@id='unitGroup']");
    By next1 = By.xpath("//button[@id='btn_basic_next']"); 
    
    //2nd Page
    By vatP = By.xpath("//input[@id='inp_vatPercent']");
    By costPrice = By.xpath("//input[@id='inp_costPrice_0']");
    By sellPrice = By.xpath("//input[@id='inp_sellingPrice_0']");
    By allow = By.xpath("//div[@id='inp_allowDecimalQty_0']");
    By down = By.xpath("//button[@aria-label='Row Collapsed']");
    By purD = By.xpath("//input[@id='inp_purchaseDiscountPercent_0']");
    By sellD = By.xpath("//input[@id='inp_saleDiscountPercent_0']");
    By maxD = By.xpath("//input[@id='inp_maxDiscountPercent_0']");
    By osq = By.xpath("//span[@aria-describedby='quantityHelp']//input[@value='0.00']");
    By osr = By.xpath("//span[@aria-describedby='openingStockUnitRateHelp']//input[@value='0.00']");
    By batch = By.xpath("//input[@class='p-inputtext p-component']");
    By expLimit = By.xpath("//input[@placeholder='Enter Expiry Limit']");
    By next2 = By.xpath("//span[normalize-space()='Next']");
    
    //3rd Page
    By manufacture = By.xpath("//input[@id='inp_manufacture']");
    By brand = By.xpath("//input[@id='inp_brand']");
    By proType = By.xpath("//input[@id='inp_productType']");
    By tag = By.xpath("//div[@class='p-multiselect-label p-placeholder'][normalize-space()='Select product tags']");
    By searchBox = By.xpath("//input[@role='searchbox']");
    By cross = By.xpath("//button[@class='p-multiselect-close p-link']");
    By attribute = By.xpath("//div[@class='p-multiselect-label p-placeholder'][normalize-space()='Select attribute']");
    By attrioptns = By.xpath("//span[@id='inp_attributeOptions']");
    By trig1 = By.xpath("//span[@id='inp_stockOutRateMethod']");
    By safetyStock = By.xpath("//input[@id='inp_safetyStock']");
    By rePoint = By.xpath("//input[@id='inp_reorderQuantity']");
    By epdc = By.xpath("//div[@id='inp_priceDailyChange']");
    By shortDecs = By.xpath("//input[@id='inp_shortDescription']");
    By fullDecs =By.xpath("//input[@id='inp_fullDescription']");
    By save = By.xpath("//button[@id='btn_save_product']");
    
    By toast = By.xpath("//div[@class='p-toast-message-content']");

    
    public void Pinput(String pn, String pnature, String pc, String hsc, String gc, String pcat, String pUnit, String glo, String loc, String vat, String cp, String sp, String pd, String sd, String md, String os, String or, String bn, String expL, String mf, String bra, String ptyp, String tg, String attri, String attriop, String som, String svm, String ss, String rp, String sds, String fds) throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(clickProduct)).click();
        wait.until(ExpectedConditions.elementToBeClickable(subProduct)).click();
        wait.until(ExpectedConditions.elementToBeClickable(add)).click();
        
        //1st Page
        write(pname, pn);
        topt(trigger, pnature);
        write(pcode, pc);
        write(hsCode, hsc);
        write(grpcode, gc);

        selectFromDropdown(pcategory, pcat);
        selectFromDropdown(punit, pUnit);
        
        WebElement global = driver.findElement(By.xpath("//div[@id='globalBarcode']//input[@type='text']"));
        global.sendKeys(glo);
        global.sendKeys(Keys.ENTER);
        
        WebElement local = driver.findElement(By.xpath("//div[@id='localBarcode']//input[@type='text']"));
        local.sendKeys(loc);
        local.sendKeys(Keys.ENTER);
        
        Aclick(next1);

        //2nd Page
        write(vatP, vat);
        write(costPrice, cp);
        write(sellPrice, sp);
        Aclick(allow);
        Aclick(down);
        write(purD, pd);
        write(sellD, sd);
        write(maxD, md);
        write(osq, os);
        write(osr, or);
        write(batch, bn);
        write(expLimit, expL);
        Aclick(next2);
        
        //3rd Page
        selectFromDropdown(manufacture, mf);
        selectFromDropdown(brand, bra);
        selectFromDropdown(proType, ptyp);

        Aclick(attribute);
        selectFromSearchDropdown(searchBox, attri);
        Aclick(cross);
        Aclick(attrioptns);
        selectFromSearchDropdown(searchBox, attriop);
        
        Aclick(tag);
        selectFromSearchDropdown(searchBox, tg);
        Aclick(cross); 
        
        topt(trigger, som);
        topt(trig1, svm);
        write(safetyStock, ss);
        write(rePoint, rp);
        write(shortDecs, sds);
        write(fullDecs, fds);
        Aclick(epdc);
        Aclick(next2);
        Aclick(next2);
        Aclick(save);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();

        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();
        
        Aclick(clickProduct);
        
    }
    
    private void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownLocator));
        dropdown.sendKeys(value);
        Thread.sleep(2000);

        List<WebElement> options = driver.findElements(By.xpath("//li[@role='option' and @class='p-autocomplete-item']"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
    
    private void selectFromSearchDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownLocator));
        dropdown.sendKeys(value);
        Thread.sleep(1000);

        List<WebElement> options = driver.findElements(By.xpath("//li[@role='option' or @class='p-autocomplete-item']"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
    
    private void topt(By locae, String value) {
        WebElement loca = wait.until(ExpectedConditions.elementToBeClickable(locae));
        loca.click();
        WebElement opt = driver.findElement(By.xpath("//li[@aria-label='"+value+"']"));
        opt.click();
    }    
    private void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    private void write(By locator1, String value) {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
}
