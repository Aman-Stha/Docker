/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddGRN {
    WebDriver driver;
    WebDriverWait wait;
    
    public AddGRN(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
//    By pnlPurchase = By.xpath("//a[@id='pnl_Purchase']");  
    By grn = By.xpath("//span[normalize-space()='Good Received Note']");
    By add = By.xpath("//button[@aria-label='Add']");
    By delivered = By.xpath("//input[@id='deliveredBy']");
    By received = By.xpath("//input[@placeholder='Select Received by']");
    By remarks = By.xpath("//input[@id='remarks']");
    By credit = By.xpath("//input[@value='0']");
    By supplier = By.xpath("//input[@placeholder='Select Supplier']");
    By purchase = By.xpath("//input[@id='selectedProduct']");
    By confirm = By.xpath("//button[@aria-label='Confirm Good Received Note']");
    By save = By.xpath("//span[normalize-space()='Save']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");

    
    public void inputGRN(String deli, String reci, String rem, String cre, String supp, String pur) throws InterruptedException {
        
//        Aclick(pnlPurchase);
        Aclick(grn);
        Thread.sleep(1000);
        Aclick(add);
        write(delivered, deli);
        selectFromDropdown(received, reci);
        write(remarks, rem);
        write(credit, cre);
        selectFromDropdown(supplier, supp);
        selectFromDropdown(purchase, pur);
        Aclick(confirm);
        Aclick(save);
        Thread.sleep(1000);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();
        
        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();
    }
    
    private void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        dropdown.sendKeys(value);
        Thread.sleep(2000);
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
     
    private void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    private void write(By locator1, String value) {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
}
