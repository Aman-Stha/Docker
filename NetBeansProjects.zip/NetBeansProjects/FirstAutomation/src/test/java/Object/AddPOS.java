/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class AddPOS extends BasePage {
    
    public AddPOS(WebDriver driver) {
        super(driver);        
    }
    
    By sales = By.xpath("//a[@id='pnl_Sales']");
    By pos = By.xpath("//span[normalize-space()='Point of Sale']");
    By customer = By.xpath("//input[@id='customer']");
    By product = By.xpath("//input[@id='product']");
    By rate = By.xpath("//input[@value='160.00']");
    By quantity = By.xpath("//input[@value='1.00']");
    By flatDis = By.xpath("//input[@id='flatDiscountAmount']");
    By remarks = By.xpath("//input[@id='remarks']");
    By confirm = By.xpath("//span[normalize-space()='Confirm Sale']");
    By save = By.xpath("//span[normalize-space()='Save']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");
    
    public void inputPOS(String cus, String pro, String qua, String flatD, String rem) throws InterruptedException {
        
        Aclick(sales);
        Aclick(pos);
        selectFromDropdown(customer, cus);
        selectFromDropdown(product, pro);
        write(flatDis, flatD);
        write(remarks, rem);
        Aclick(confirm);
        Aclick(save);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();
        
        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();
    }
    
}

