/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddPOError {
    WebDriver driver;
    WebDriverWait wait;
    
    public AddPOError(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    By PO = By.xpath("//span[normalize-space()='Purchase Order']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By supplier = By.xpath("//input[@placeholder='Select Supplier']");
    By product = By.xpath("//input[@id='selectedProduct1']");
    By confirm = By.xpath("//button[@aria-label='Confirm Purchase Order']");
    By advance = By.xpath("//span[@aria-describedby='paidAmountHelp']//input[@role='spinbutton']");
    By save = By.xpath("//span[normalize-space()='Save']");
    By supError = By.xpath("//span[@role='alert']");
    By proError = By.xpath("//span[@class='p-toast-summary']");
    
    public void POinput(String supp, String pro, String adv) throws InterruptedException { 
        
        wait.until(ExpectedConditions.elementToBeClickable(PO)).click();
        wait.until(ExpectedConditions.elementToBeClickable(add)).click();
        
        /*        
        driver.findElement(supplier).click();
        driver.findElement(supplier).sendKeys(supp);
        Thread.sleep(1500);


        List<WebElement> suppList = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        WebElement SelectSupp = suppList.get(0);
        if (SelectSupp.isDisplayed()) {
            SelectSupp.click();
        } else {
            driver.findElement(confirm).click();
        }
        */
        selectFromDropdown(supplier, supp);
        Thread.sleep(1000);

        try {
            WebElement error = driver.findElement(By.xpath("//span[@role='alert']"));
            if (error.isDisplayed()) {
                String errorMsg = error.getText();
                System.out.println();
                System.out.println("!!! Error !!! --> " + '"' + errorMsg + '"');
                System.out.println();
                return;
            }
        } catch (Exception e) {
        }

        /* 
        driver.findElement(product).click();
        driver.findElement(product).sendKeys(pro);
        Thread.sleep(1500);
        
        List<WebElement> proList = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        WebElement SelectPro = proList.get(0);
        if (SelectPro.isDisplayed()) {
            SelectPro.click();                   
        }
        */
        selectFromDropdown(product, pro);
        Thread.sleep(1000);
        driver.findElement(confirm).click();
        Thread.sleep(1000);
        
        try {
            WebElement error1 = driver.findElement(By.xpath("//span[@class='p-toast-summary']"));
            if (error1.isDisplayed()) {
                String errorMsg = error1.getText();
                System.out.println();
                System.out.println("!!! Error !!! --> " + '"' + errorMsg + '"');
                System.out.println();
                return;
            }
        } catch (Exception e) {
        }
        
        driver.findElement(advance).clear();
        driver.findElement(advance).sendKeys(adv);
        driver.findElement(save).click();
        System.out.println("**** Purchase Order Craeted Successfully ****");
                        
    }
    
    private void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        dropdown.sendKeys(value);
        Thread.sleep(2000);
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
//        
//    private void errorMsg(By locator) {
//        WebElement error = driver.findElement(locator);
//        if(error.isDisplayed()) {
//            String errorMsg = error.getText();
//            System.out.println();
//            System.out.println("!!! Error !!! --> " + '"' + errorMsg + '"');
//            System.out.println();
//            Assert.fail();
//        }
//    }
}
