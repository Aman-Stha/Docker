/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddPBill {
    
    WebDriver driver;
    WebDriverWait wait;
    
    public AddPBill(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By pnlPurchase = By.xpath("//a[@id='pnl_Purchase']");  
    By pbill = By.xpath("//span[normalize-space()='Purchase Bill']");
    By add = By.xpath("//button[@aria-label='Add']");
    By reference = By.xpath("//input[@id='refBillNo']");
    By supplier = By.xpath("//input[@placeholder='Select Supplier']");
    By grn = By.xpath("//input[@placeholder='Select Good Received Note']");
    By confirm = By.xpath("//button[@aria-label='Confirm Purchase']");
    By save = By.xpath("//span[normalize-space()='Save']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");

    public void inputBill(String ref, String supp, String gr) throws InterruptedException {
        
        Aclick(pnlPurchase);
        Aclick(pbill);
        Aclick(add);
        write(reference, ref);
        selectFromDropdown(supplier, supp);
        selectFromDropdown(grn, gr);
        Thread.sleep(1000);
        Aclick(confirm);
        Aclick(save);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();
        
        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();
        
    }
    
    private void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        dropdown.sendKeys(value);
        Thread.sleep(2000);
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
     
    private void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    private void write(By locator1, String value) {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
}
