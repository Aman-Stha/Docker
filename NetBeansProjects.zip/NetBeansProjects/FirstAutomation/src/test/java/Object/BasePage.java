package Object;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
    protected WebDriver driver;
    protected WebDriverWait wait;
    
    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
    
    protected void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        dropdown.clear();
        dropdown.sendKeys(value);
        Thread.sleep(2000); // Consider replacing with a more robust wait if possible
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        } else {
            System.out.println("No options found in the dropdown.");
        }
    }
    
    protected void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    protected void write(By locator1, String value) throws InterruptedException {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
}
