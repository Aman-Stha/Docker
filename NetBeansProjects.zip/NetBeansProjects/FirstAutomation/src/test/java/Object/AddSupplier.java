/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class AddSupplier {
    WebDriver driver;
    WebDriverWait wait;

    public AddSupplier(WebDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    By purchase = By.xpath("//a[@id='pnl_Purchase']");    
    By supplier = By.xpath("//span[@class='ml-3 text-color'][normalize-space()='Supplier']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By name = By.xpath("//input[@name='name']");
    By email = By.xpath("//input[@name='email']");
    By address = By.xpath("//input[@name='address']");
    By phone = By.xpath("//input[@name='phoneNo']");
    By pan = By.xpath("//input[@name='panNo']");
    By leadTime = By.xpath("//input[@value='0']");
    By credit = By.xpath("//input[@value='0.00']");
    By save = By.xpath("//span[normalize-space()='Save Supplier']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");

    
    public void Sinput(String nam, String ema, String addr, String ph, String pn, String lt, String ca) throws InterruptedException{
             
        wait.until(ExpectedConditions.elementToBeClickable(purchase)).click();   
        wait.until(ExpectedConditions.elementToBeClickable(supplier)).click();
        wait.until(ExpectedConditions.elementToBeClickable(add)).click();
        
        write(name, nam);
        write(email, ema);
        write(address, addr);
        write(phone, ph);
        write(pan, pn);
        write(leadTime, lt);
        write(credit, ca);
        Aclick(save);
        Thread.sleep(1000);
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();

        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();

    }
    
    private void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
    
    private void write(By locator1, String value) {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
    }
}
