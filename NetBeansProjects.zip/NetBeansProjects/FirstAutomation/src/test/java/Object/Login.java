/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Object;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class Login {
    
    WebDriver driver;
    WebDriverWait wait;
    
    public Login(WebDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    By username = By.xpath("//input[@id='username']");
    By password = By.xpath("//input[@id='password1']");
    By signin = By.xpath("//button[@id='signIn']");
    By toast = By.xpath("//div[@class='p-toast-message-content']");
    By not = By.xpath("//button[@aria-label='Close']");
       
    
    public void input(String uname, String pw) throws InterruptedException {
        driver.findElement(username).sendKeys(uname);
        driver.findElement(password).sendKeys(pw);
        driver.findElement(signin).click();
        
        WebElement msgs = wait.until(ExpectedConditions.visibilityOfElementLocated(toast));
        String msg = msgs.getText();
        
        System.out.println();
        System.out.println("***** " + msg + " *****");
        System.out.println();

        try {
            driver.findElement(not).click();
        } catch (Exception e) {
        }
        
    }
}
