/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Page;

import Object.AddCustomer;
import Object.AddGRN;
import Object.AddPBill;
import Object.AddPO;
import Object.AddPOError;
import Object.AddPOS;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Object.Login;
import Object.AddProduct;
import Object.AddSO;
import Object.AddSupplier;
import Object.POmenu;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author aman
 */
public class LoginTest {
    
    WebDriver driver;  
    
    @BeforeTest
    public void beforeTest() {
        
        ChromeOptions options = new ChromeOptions(); 
        options.setAcceptInsecureCerts(true);
        options.addArguments("--headless"); // Run Chrome in headless mode
        options.addArguments("--no-sandbox"); // Bypass OS security restrictions
        options.addArguments("--disable-dev-shm-usage"); // Overcome resource constraints
        options.addArguments("--remote-allow-origins=*"); // Allow all origins for dev tools
        
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(options);
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        
        driver.get("https://invtest.mfinplus.com/#/Login");
    }
    
    @Test
    public void loginOperation() {
        
        try {
                Login page = new Login(driver);
                page.input("asus", "sigma@123");            
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
        
    }
    
/*
    @Test(dependsOnMethods = "loginOperation")
    public void addProductOperation() {
       try {
            AddProduct pg = new AddProduct(driver);
            pg.Pinput("pom","SERVICE","pom11","pom12","pom22", "qweqwe", "litres", "njanjdnfjna", "nasjdfnjsd", "13", "100", "200", "10", "5", "15", "10", "100", "101", "1", "digicom", "nikes", "laptop", "mitho", "color", "whi", "Last In First Out", "Weighted Average", "10", "10", "short desc", "full desc");
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());            
        }
    }
    
    
    @Test(dependsOnMethods = "loginOperation")
    public void addSupplierOperation() throws FileNotFoundException, IOException, CsvValidationException {
        
        CSVReader supp = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/supplier.csv"));
        supp.readNext();
        String[] dt;
        
        while ((dt=supp.readNext())!=null) {            
            String nm = dt[0];
            String em = dt[1];
            String ad = dt[2];
            String pho = dt[3];
            String pan = dt[4];
            String let = dt[5];
            String cra = dt[6];
           
            try {
                AddSupplier pg = new AddSupplier(driver);
                pg.Sinput(nm, em, ad, pho, pan, let, cra);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());
            }
        }
    }

*/    
    //Add Purchase Order
/*
    @Test(dependsOnMethods = "loginOperation") 
    public void menuOperation() throws InterruptedException { 
    
        POmenu pg = new POmenu(driver);
        pg.POclick();
        
    }
*/        
    
/*
    @Test(dependsOnMethods = "addSupplierOperation")
    public void addPOOperation() throws FileNotFoundException, IOException, CsvValidationException { 
        
        CSVReader reader = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/pOrder.csv"));
        reader.readNext();
        String[] dt;
        
        while((dt=reader.readNext())!=null) {
            
            String sp = dt[0];
            String pd = dt[1];
            String ad = dt[2];
            
            try {
                AddPO pg = new AddPO(driver);
                pg.POinput(sp, pd, ad);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());             
            }
        }
    }
*/

/*
    @Test(dependsOnMethods = "loginOperation")
    public void addGRNOperation() throws FileNotFoundException, IOException, CsvValidationException {
        CSVReader reader = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/grn.csv"));
        reader.readNext();
        String[] dt;
        
        while((dt=reader.readNext())!=null) {
            
            String del = dt[0];
            String rec = dt[1];
            String rem = dt[2];
            String cre = dt[3];
            String sup = dt[4];
            String pur = dt[5];

            
            try {
                AddGRN pg = new AddGRN(driver);
                pg.inputGRN(del, rec, rem, cre, sup, pur);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());             
            }
        }
    }
*/
    
/*
    @Test(dependsOnMethods = "loginOperation")
    public void addPurcBill() throws FileNotFoundException, IOException, CsvValidationException {
        CSVReader reader = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/pbill.csv"));
        reader.readNext();
        String[] dt;
        
        while((dt=reader.readNext())!=null) {
            
            String re = dt[0];
            String su = dt[1];
            String grn = dt[2];

            
            try {
                AddPBill pg = new AddPBill(driver);
                pg.inputBill(re, su, grn);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());             
            }
        }
    }
*/
    
/*
    @Test(dependsOnMethods = "loginOperation")
    public void addCustomerOperation() throws FileNotFoundException, IOException, CsvValidationException {
        CSVReader reader = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/customer.csv"));
        reader.readNext();
        String[] dt;
        
        while((dt=reader.readNext())!=null) {
            
            String na = dt[0];
            String em = dt[1];
            String adre = dt[2];
            String pho = dt[3];
            String pan = dt[4];
            String cate = dt[5];
            String cam = dt[6];
            String cal = dt[7];
            
            try {
                AddCustomer pg = new AddCustomer(driver);
                pg.inputAddCus(na, em, adre, pho, pan, cate, cam, cal);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());             
            }
        }
    }
*/
    
/*
    @Test(dependsOnMethods = "loginOperation")
    public void addSOrderOperation() throws FileNotFoundException, IOException, CsvValidationException {
        CSVReader reader = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/sOrder.csv"));
        reader.readNext();
        String[] dt;
        
        while((dt=reader.readNext())!=null) {
            
            String spt = dt[0];
            String cus = dt[1];
            String pro = dt[2];
            
            try {
                AddSO pg = new AddSO(driver);
                pg.inputAddSO(spt, cus, pro);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());             
            }
        }
    }
*/
      
    /*
    @Test(dependsOnMethods = "loginOperation")
    public void addPOSOperation() throws FileNotFoundException, IOException, CsvValidationException {
        CSVReader reader = new CSVReader(new FileReader("/home/aman/NetBeansProjects/FirstAutomation/src/test/java/CSV/pos.csv"));
        reader.readNext();
        String[] dt;
        
        while((dt=reader.readNext())!=null) {
            
            String cu = dt[0];
            String po = dt[1];
            String qa = dt[2];            
            String fd = dt[3];
            String re = dt[4];
            
            try {
                AddPOS pg = new AddPOS(driver);
                pg.inputPOS(cu, po, qa, fd, re);
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());             
            }
        }
    }
    */
    
    
/*    
    @AfterTest
    public void afterTest() {
        //driver.quit();
    }
*/
}
