/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class GRN extends BasePage {

    public GRN(AndroidDriver driver) {
        super(driver);
    }

    By grn = By.xpath("//android.view.View[@content-desc=\"Good Received Note\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
//  By okBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By dismiss = By.xpath("//android.view.View[@content-desc=\"Dismiss\"]");
//    By top = By.xpath("//android.view.View[@content-desc=\"Good Received Note\"]");
    By addItem = By.xpath("(//android.widget.Button[@content-desc=\"Add Item\"])[1]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    By confirmP = By.xpath("//android.widget.Button[@content-desc=\"Confirm Purchase\"]");
    By exit = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button[1]");

    public void grnInput(String dn, String cpr, String db) throws InterruptedException {

        Aclick(grn);
        Thread.sleep(2000);

//      String MobElementToScroll = "Multiple Payments";
        WebElement SwitchElement = driver.findElement(AppiumBy.androidUIAutomator(
                "new UiScrollable(new UiSelector().scrollable(true)).setAsHorizontalList().scrollIntoView("
                + "new UiSelector().className(\"android.widget.Button\").instance(12))"
        ));
        SwitchElement.click();
        
        Aclick(addBtn);
        Aclick(addBtn);

        try {
            Aclick(dismiss);
        } catch (Exception e) {
        }

        WebElement supplier = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText"));
        supplier.click();
        List<WebElement> suppList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectS = suppList.get(15);
        wait.until(ExpectedConditions.elementToBeClickable(SelectS)).click();
        Thread.sleep(1000);
//        Aclick(top);

        WebElement dNote = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]"));
        dNote.click();
        dNote.sendKeys(dn);
//        Aclick(top);

        WebElement cPeriod = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[3]"));
        cPeriod.click();
        cPeriod.sendKeys(cpr);
//        Aclick(top);

        WebElement dBy = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[4]"));
        dBy.click();
        dBy.sendKeys(db);

//        Aclick(top);
        Aclick(addItem);

        List<WebElement> itemList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectI = itemList.get(7);
        wait.until(ExpectedConditions.elementToBeClickable(SelectI)).click();
        Thread.sleep(2000);

        Aclick(save);

        System.out.println();
        System.out.println("*** Successfully created GRN ***");
        System.out.println();

        Aclick(confirmP);
        Aclick(save);

        System.out.println();
        System.out.println("*** Successfully created purchase bill ***");
        System.out.println();

        Aclick(exit);

    }

}
