package com.syntech.page;

import com.syntech.helper.Config;
import com.syntech.helper.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddProduct extends PageObject {
    private final String AddProductUrl = Config.getBaseUrl() + "/#/product/createEdit/LTE=";
    
By name = By.xpath("//*[@id='name']");
By code = By.xpath("//*[@id=\"code\"]");
By groupcode = By.xpath("//*[@id=\"groupCode\"]");
    //By code = By.xpath("//label[text()='Code']/following-sibling::input"); this also works
   // By groupcode = By.xpath("//label[text()='Group Code']/following-sibling::input");
   // By productNatureDropdown = By.className("p-dropdown-trigger");
By productNatureDropdown = By.xpath("//*[@id=\"nature\"]");
By categoryDropdown = By.xpath("//*[@id=\"category\"]");
By unitDropdown = By.xpath("//*[@id=\"unitGroup\"]");


By globalb = By.xpath("//*[@id=\"localBarcode\"]");
By nextb =By.xpath("//*[@id=\"btn_basic_next\"]/span[1]");
 

 
 By detailbutton =By.xpath("//*[@id=\"dt_product_unit\"]/div[1]/table/tbody/tr[1]/td[1]/button");
 By openstock =By.xpath("//*[@id=\"inp_openingStockQuantity\"]");
 By openrate = By.xpath("//*[@id=\"inp_openingStockUnitRate\"]");
 By vatper = By.xpath("//*[@id=\"inp_vatPercent\"]");
 By costprice = By.xpath("//*[@id=\"inp_costPrice\"]");
 By sellingprice = By.xpath("//*[@id=\"inp_unitSellingPrice\"]");
 By purchasedis = By.xpath("//*[@id=\"inp_purchaseDiscountPercent\"]");
 By saledis =By.xpath("//*[@id=\"inp_saleDiscountPercent\"]");
 By maxdis = By.xpath("//*[@id=\"inp_maxDiscountPercent\"]");
 By tnext =By.xpath("//*[@id=\"btn_next_unit\"]/span[1]");
 
 
 
 By manufacturer =By.xpath("//*[@id=\"inp_manufacture\"]");
 
 By brand=By.xpath("//*[@id=\"inp_brand\"]");
 By attributetype = By.xpath("//*[@id=\"inp_attribute\"]/div[2]/div");
 By attributeclose =By.xpath("//*[@id=\"inp_attribute\"]/div[3]/svg");
 By attributeoption = By.xpath("//*[@id=\"inp_attributeOptions\"]");
 
 
 
 By productType=By.xpath("//*[@id=\"inp_productType\"]");
 By productTag=By.xpath("//*[@id=\"inp_productTags\"]/div[2]/div");

 By stockout = By.xpath("//*[@id=\"inp_stockOutMethod\"]");
 By stockvalue = By.xpath("//*[@id=\"inp_stockOutRateMethod\"]");
 By safetystock = By.xpath("//*[@id=\"inp_safetyStock\"]");
 By reorder = By.xpath("//*[@id=\"inp_reorderQuantity\"]");
 By shortdes = By.xpath("//*[@id=\"inp_shortDescription\"]");
 //By dailyprice =By.xpath("//*[@id=\"pv_id_12_content\"]/div/form/div/form/div[1]/div[8]/div/div/input");
 By fulldes = By.xpath("//*[@id=\"inp_fullDescription\"]");
 By thnext = By.xpath("//*[@id=\"btn_next_add_info\"]/span[1]");
 
// By save = By.xpath("//*[@id="btn_save_product"]");
    public AddProduct(WebDriver driver) {
        super(driver);
    }

    public AddProduct submit(String pname, String c, String gcode, String pnature, String cat,String unit,String global,String next,String dbutton,
            String ostock,String orate,String vat,String cp,String sp,String pd,String sd,String msd
    ,String tnextb ,String manu,String bran,String prot,String protag,String atype,String aclose,String aoption,String stout,
    String stval,String safetyst,String reord,String shrtd,String fulld,String dpric,String thnxt,String sav) throws InterruptedException {
        // set the input fields
        writeText(name, "Wai Wai Noodles");
        writeText(code, "WWN3");
        writeText(groupcode, "GWN2");
      //  click(productNatureDropdown);
       selectDropdownOptionByAriaLabel(productNatureDropdown, "PRODUCT");
     //  click(categoryDropdown);
       selectDropdownOptionByAriaLabel(categoryDropdown, "Fried Items [c12]");
       selectDropdownOptionByAriaLabel(unitDropdown, "Pieces");
        writeText(globalb ,"1236545269875");
       click(nextb);
  
        click(detailbutton);
        click(costprice);
        clearInputFields();
        writeText(openrate,"200");
        writeText(openstock,"10");
        writeText(vatper,"13");
        writeText(costprice,"200");
        click(sellingprice);
        writeText(sellingprice,"400");
        writeText(purchasedis,"5");
        writeText(saledis,"10");
        writeText(maxdis,"15");
        click(tnext);
   
   selectDropdownOptionByAriaLabel(manufacturer, "Tokla Manufacturer");
   selectDropdownOptionByAriaLabel(brand, "Tokla");
   selectDropdownOptionByAriaLabel(productType, "Tea");
   
   click(productTag);
   click(productTag);
   selectDropdownOptionByAriaLabel(productTag, "Circle");
   click(productTag);
   
   selectDropdownOptionByAriaLabel(attributetype, "color");
   click(attributeclose);
   selectDropdownOptionByAriaLabel(attributeoption, "whitr");
   
   
   
   selectDropdownOptionByAriaLabel(stockout, "First In First Out");
   selectDropdownOptionByAriaLabel(stockvalue, "First In First Out");
   writeText(safetystock,"10");
   writeText(reorder,"20");
 
    writeText(shortdes,"thi is tea");
    
  
   writeText(fulldes,"this is this tea and i love it");
   
  // click(dailyprice);
   click(thnext);
   //click(save);
        return this;
    }

  private void selectDropdownOptionByAriaLabel(By dropdownLocator, String optionLabel) {
    click(dropdownLocator);

    WebDriverWait wait = new WebDriverWait(driver, 10);
    for (int attempt = 0; attempt < 3; attempt++) {
        try {
            WebElement option = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@aria-label='" + optionLabel + "']")));
            option.click();
            break; 
        } catch (StaleElementReferenceException e) {
           
            System.out.println("StaleElementReferenceException occurred, retrying...");
        }
    }
}

    public void navigateToProductPage() {
        driver.get(AddProductUrl);
    }
     public AddProduct clearInputFields() {
        clearText(openstock);
        clearText(openrate);
        clearText(openrate);
        clearText(vatper); 
        clearText(costprice);
        clearText(sellingprice);
        clearText(purchasedis);
        clearText(saledis);
        clearText(maxdis);
        return this;
    }
    
     
     public void clearText(By element) {
        driver.findElement(element).clear();
    }
}
