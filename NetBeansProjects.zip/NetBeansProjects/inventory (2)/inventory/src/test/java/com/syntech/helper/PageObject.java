package com.syntech.helper;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
public class PageObject {
    public WebDriver driver;
    public WebDriverWait wait;
    public FluentWait fluentWait;
    //Constructor
    public PageObject(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10).getSeconds());
        fluentWait = new FluentWait(driver).withTimeout(10, TimeUnit.SECONDS)
                .pollingEvery(Duration.ofSeconds(1l)).ignoring(NoSuchElementException.class);
    }
    //Click Method
    public void click(By by) {
        waitVisibility(by).click();
    }
    //Write Text
    public void writeText(By by, String text) {
        waitVisibility(by).sendKeys(text == null || text.isEmpty() ? new StringBuilder("") : text);
    }
    //Read Text
    public String readText(By by) {
        return waitVisibility(by).getText();
    }
    //Wait
    public WebElement waitVisibility(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }
    public void clearField(By by) {
        waitVisibility(by).clear();
    }
    public void refreshPage() {
        driver.navigate().refresh();
    }
    
    public WebElement waitPresence(By by) {
        //  return wait.until(ExpectedConditions.presenceOfElementLocated(by));
        WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver driver) {
                return driver.findElement(by);
            }
        });
        return foo;
    }
    public WebElement waitElementToBeClickable(By by) {
        return wait.until(ExpectedConditions.elementToBeClickable(by));
    }
    
    public void waitForElementPresence(By by, int timeoutInSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
    }
}