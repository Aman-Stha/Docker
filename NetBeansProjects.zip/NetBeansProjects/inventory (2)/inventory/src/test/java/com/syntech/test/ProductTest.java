package com.syntech.test;
import org.testng.annotations.Test;

public class ProductTest extends LoginTest{
   
    
    @Test
    public void ProductTest() throws InterruptedException {
        addProduct.navigateToProductPage();
        
         addProduct.submit("pname","c","gcode","pnature","cat","unit","global","next","dbutton","ostock","orate","vat","cp","sp","ps","sd","md","tnextb","manu","bran",
                 "prot","protag","atype","aclose","aoption",
                 "stout","stval","safetyst","reord","shrtd","dpric","fulld","thnxt","sav");
          
        Thread.sleep(3000);
       
    }
 
}
