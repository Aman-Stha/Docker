package com.syntech.page;

import com.opencsv.CSVReader;
import com.syntech.helper.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.io.FileReader;
import com.syntech.helper.Config;
import java.io.BufferedReader;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

 

public class LoginPage extends PageObject {
    private CSVReader csvReader;
       String loginpageUrl = Config.getBaseUrl() + "/#/Login";
       
   // private final String loginpageUrl = "http://10.120.2.109:7071/#/Login";
    By username = By.xpath("//*[@id='username']");
    By password = By.xpath("//*[@id='password1']");
    By loginButton = By.xpath("//*[@id='signIn']");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void navigateToLoginPage() {
        driver.get(loginpageUrl);
    }

    public LoginPage submitFromCSV(String csvFilePath) throws InterruptedException, IOException {
        // Read CSV file
        String [] csvCell;
   csvReader = new CSVReader(new FileReader(csvFilePath));
   while ((csvCell= csvReader.readNext())!=null){
   String UserName= csvCell[0]; 
   String Password= csvCell[1]; 
   refreshPage();
   writeText(username, UserName);
   writeText(password, Password);
   
   click(loginButton);
   }
        return this;
    }
}