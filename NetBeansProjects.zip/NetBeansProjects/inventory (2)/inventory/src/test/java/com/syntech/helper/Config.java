/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.syntech.helper;

import java.util.ResourceBundle;

public class Config {
    private static final ResourceBundle BUNDLE = ResourceBundle.getBundle("bundle");

    public static String getBaseUrl() {
        String protocol = BUNDLE.getString("protocol");
        String target = BUNDLE.getString("target");
        String port = BUNDLE.getString("port");

        return protocol + "://" + target + ":" ;
    }
}