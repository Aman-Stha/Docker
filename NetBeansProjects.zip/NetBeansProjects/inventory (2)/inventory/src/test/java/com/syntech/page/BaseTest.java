/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.syntech.page;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
public class BaseTest {
    protected static WebDriver driver;
    public LoginPage loginPage;
    public AddProduct addProduct;
   
    public WebDriver getDriver() {
        return driver;
    }
    
    @BeforeClass
    public static void setUp() { 
    ChromeOptions options= new ChromeOptions();
        WebDriverManager.chromedriver().driverVersion("123.0.6312.58").setup(); 
    driver = new ChromeDriver(options);
    driver.manage().window().maximize();
       
}
   
    @After
    public void cleanUp() {
        driver.manage().deleteAllCookies();
    }
   
    @BeforeMethod
    public void methodLevelSetup() {
        loginPage = new LoginPage(driver);
        addProduct = new AddProduct(driver);
    }  
   public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
