package com.syntech.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.syntech.page.LoginPage;
import com.syntech.page.BaseTest;
import org.testng.Assert;

import java.io.IOException;

public class LoginTest extends BaseTest {

    @Test
    public void LoginTest() throws InterruptedException, IOException {
        loginPage.navigateToLoginPage();

        loginPage.submitFromCSV("/home/amrita/login.csv");

        Thread.sleep(3000);

        // Add assertions or further validation if needed
    }
    
}
