/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inventory;

/**
 *
 * @author puja
 */
public class Inventory {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
