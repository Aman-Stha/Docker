/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Page;

import Inventory.Object.Login;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import io.appium.java_client.android.AndroidDriver;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class LoginTest {
    AndroidDriver driver;
    
    @BeforeTest
    public void beforeTest() throws MalformedURLException {
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("deviceName", "sdk_gphone16k_x86_64");        
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("automationName", "UiAutomator2");
        capabilities.setCapability("platformVersion", "15");        
        capabilities.setCapability("appPackage", "com.syntech.smart_sme.uat");
        capabilities.setCapability("appActivity", "com.syntech.smart_sme.MainActivity");
        capabilities.setCapability("noReset", true);
        
        URL url = URI.create("http://127.0.0.1:4723/").toURL();    
        driver = new AndroidDriver(url, capabilities);
    }
    
    
    @Test
    public void loginOperation() throws FileNotFoundException, IOException, CsvValidationException {
        
        CSVReader data = new CSVReader(new FileReader("/home/aman/NetBeansProjects/AppiumDemo/src/test/java/CSV/login.csv"));
        data.readNext();
        String[] dt;
        
        while((dt=data.readNext())!=null) {
           
            String usr = dt[0];
            String pss = dt[1];
            
            try {
                Login page = new Login(driver);
                page.input(usr, pss);            
            } catch (Exception e) {
                System.out.println("Error" + e.getMessage());
            }            
        }
    }
}
