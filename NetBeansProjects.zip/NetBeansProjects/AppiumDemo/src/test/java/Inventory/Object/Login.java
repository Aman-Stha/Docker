/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

/**
 *
 * @author aman
 */
public class Login {
    
    AndroidDriver driver;
    
    public Login(AndroidDriver driver){
        this.driver = driver;
    }  
    
    public void input(String uname, String pass) throws InterruptedException {
              
        try {
            WebElement allow = driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_button"));
            if(allow.isDisplayed()) {
                allow.click();
            }
        } catch (Exception e) {
            
        }
        
        Thread.sleep(1000);
        WebElement username = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText[1]"));
        WebElement password = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText[2]"));
        WebElement loginBtn = driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Login\"]"));
        
        username.click();
        username.clear();
        username.sendKeys(uname);
        password.click();
        password.clear();
        password.sendKeys(pass);
        
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Login\"]")).click();
        Thread.sleep(1000);
        loginBtn.click();
        
        Thread.sleep(1000);
        
        int state = getAppState(); // Method to determine the current app state

        switch (state) {
            case 1: // Login Successful
                handleLoginSuccessful();
                break;
            case 2: // Login Failed
                handleError();
                break;
            case 3: //Username required
                System.out.println();
                System.out.println("Login Failed");
                WebElement userError = driver.findElement(By.xpath("//android.view.View[@content-desc='Username is required']"));
                String ue = userError.getAttribute("content-desc");
                System.out.println("Error message: " + ue);
                break;
            case 4: // Password required
                System.out.println();
                System.out.println("Login Failed");
                WebElement passError = driver.findElement(By.xpath("//android.view.View[@content-desc='Password is required']"));
                String pe = passError.getAttribute("content-desc");
                System.out.println("Error message: " + pe);
                System.out.println();
                break;
            case 5: // Invalid
                System.out.println("Invalid");
                break;
            default:
                System.out.println("Unknown State");
                break;
        }
    }

    private int getAppState() {
        try {
            WebElement menuBtn = driver.findElement(By.xpath("//android.widget.Button[@content-desc='Open navigation menu']"));
            if (menuBtn.isDisplayed()) {
                return 1; // Login Successful
            }
        } catch (NoSuchElementException e) {
            // Proceed to check for login failure or invalid state
        }

        try {
            WebElement error = driver.findElement(By.xpath("//android.view.View[@content-desc=\"Invalid UserName or Password !!!\"]"));
            if (error.isDisplayed()) {
                return 2; // Login Failed
            }
        } catch (NoSuchElementException e) {
            // Proceed to check for invalid state
        }
        
        try {
            WebElement userError = driver.findElement(By.xpath("//android.view.View[@content-desc='Username is required']"));
            if(userError.isDisplayed()){
                return 3;                
            }
        } catch (NoSuchElementException e) {           
        }
        
        try {
            WebElement passError = driver.findElement(By.xpath("//android.view.View[@content-desc='Password is required']"));
            if(passError.isDisplayed()){
                return 4;                
            }
        } catch (NoSuchElementException e) {       
        }

        return 5; // Invalid
    }

    private void handleLoginSuccessful() throws InterruptedException {
        System.out.println();
        System.out.println("Login Successful");
        Thread.sleep(5000);

        try {
            WebElement link = driver.findElement(By.xpath("//android.widget.Button[@content-desc='Never']"));
            if (link.isDisplayed()) {
                link.click();
            }
        } catch (NoSuchElementException e) {
            System.out.println("Never button not found.");
        }

        try {
            WebElement demo = driver.findElement(By.xpath("//android.widget.Button[@content-desc='Cancel']"));
            if (demo.isDisplayed()) {
                demo.click();
            }
        } catch (NoSuchElementException e) {
            System.out.println("Cancel button not found.");
        }

        driver.findElement(By.xpath("//android.widget.Button[@content-desc='Open navigation menu']")).click();
        driver.findElement(By.xpath("//android.widget.Button")).click();
        driver.findElement(By.xpath("//android.widget.Button[@content-desc='Yes']")).click();
    }
    
    private void handleError() {
        
        System.out.println();
        System.out.println("Login Failed");
        WebElement error = driver.findElement(By.xpath("//android.view.View[@content-desc=\"Invalid UserName or Password !!!\"]"));
        String errorMsg = error.getAttribute("content-desc");
        System.out.println("Error message: " + errorMsg);
        System.out.println();
        
        try {
            driver.findElement(By.xpath("//android.widget.Button[@content-desc='OK']")).click();
        } catch (Exception e) {
            
        }
    }
    
}
