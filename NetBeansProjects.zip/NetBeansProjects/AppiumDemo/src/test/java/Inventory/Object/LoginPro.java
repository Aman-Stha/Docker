/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import io.appium.java_client.android.AndroidDriver;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class LoginPro {
    
    AndroidDriver driver;
    WebDriverWait wait;
    
    public LoginPro(AndroidDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }  
    
    public void input(String uname, String pass) throws InterruptedException {
              
        try {
            WebElement allow = driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_button"));
            if(allow.isDisplayed()) {
                allow.click();
            }
        } catch (Exception e) {
            
        }
        
        Thread.sleep(1000);
        WebElement username = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText[1]"));
        WebElement password = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText[2]"));
        WebElement loginBtn = driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Login\"]"));
        
        username.click();
        username.sendKeys(uname);
        password.click();
        password.sendKeys(pass);
        
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Login\"]")).click();
        Thread.sleep(1000);
        loginBtn.click();
        
        Thread.sleep(1000);
        
        System.out.println();
        System.out.println("*** Login Successful ***");
        System.out.println();

        try {
            WebElement link = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.Button[@content-desc='Never']")));
            if (link.isDisplayed()) {
                link.click();
            }
        } catch (NoSuchElementException e) {
            System.out.println("Never button not found.");
        }

        try {
            WebElement demo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.Button[@content-desc='Cancel']")));
            if (demo.isDisplayed()) {
                demo.click();
            }
        } catch (NoSuchElementException e) {
            System.out.println("Cancel button not found.");
        }
    }
    
}
