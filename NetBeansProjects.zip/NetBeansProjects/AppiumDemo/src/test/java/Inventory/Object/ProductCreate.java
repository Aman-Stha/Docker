/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class ProductCreate {
    
    AndroidDriver driver;
    WebDriverWait wait;
    
    public ProductCreate(AndroidDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    //Basic Info
    
        By bottomBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.widget.Button");
        By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.widget.Button[2]");
        By lbCode = By.xpath("//android.widget.ScrollView/android.widget.EditText[2]");
        By pNature = By.xpath("");
        By category = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.view.View[9]/android.widget.EditText");
        By searchBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button[2]");
        By sInput = By.xpath("//android.widget.EditText");
        By afterSelectC = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
        By nextBtn1 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        
        //Unit & Pricing
        By unitGrp = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
        By unitGrpInput = By.xpath("//android.widget.ScrollView/android.widget.EditText[1]");
        By apu = By.xpath("//android.view.View[@content-desc=\"Allow Decimal Quantity?\"]");
        By allowDQ = By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.CheckBox[1]");
        By showAI = By.xpath("//android.widget.Button[@content-desc=\"Show Additional Info\"]");
        By hideAI = By.xpath("//android.widget.Button[@content-desc=\"Hide Additional Info\"]");
        By showBI = By.xpath("//android.widget.Button[@content-desc=\"Show Batch Info\"]");
        By expType = By.xpath("//android.widget.Button[@content-desc=\"DAYS\"]");
        By selectExp = By.xpath("//android.view.View[@content-desc=\"MONTH\"]");
        By saveBtn1 = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");        
        By nextBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        
        //Additional Info
        By manufacturer = By.xpath("//android.widget.ScrollView/android.widget.EditText[1]");
        By brand = By.xpath("//android.widget.ScrollView/android.widget.EditText[2]");
        By proType = By.xpath("//android.widget.ScrollView/android.widget.EditText[3]");
        By attribute = By.xpath("//android.widget.ScrollView/android.widget.EditText[4]");
        By som = By.xpath("//android.widget.Button[@content-desc='Stock Out Method*\nLIFO']");
        By selectSOM = By.xpath("//android.view.View[@content-desc=\"FIFO\"]");
        By weightAvg = By.xpath("//android.widget.Button[@content-desc=\"Stock Valuation Method WEIGHTED_AVERAGE\"]");
        By selectWA = By.xpath("//android.view.View[@content-desc=\"LIFO\"]");
        By nextBtn3 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");

        //Confirmation Page
        By saveBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    
    public void Pinput(String gc, String lc, String na, String co, String hs, String cat, String vt, String ug, String cost, String sell, String pd, String sd, String md, String or, String oq, String bno, String eli, String manu, String brn, String prot, String attri, String tg, String rp, String ss, String sdec, String fdec) throws InterruptedException 
    {
        
        Thread.sleep(1000);

        wait.until(ExpectedConditions.elementToBeClickable(bottomBtn)).click();
        wait.until(ExpectedConditions.elementToBeClickable(addBtn)).click();
        
        WebElement gbCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]"));
        gbCode.click();
        gbCode.sendKeys(gc);
        Thread.sleep(500);
        
        /*
        //for global code error
        try {
            List<WebElement> msgList = driver.findElements(By.xpath("//android.view.View"));
            if(msgList.size() >= 6) {
                WebElement content = msgList.get(6);
                if (content.isDisplayed()) {
                    String msg = content.getAttribute("content-desc");
                    System.out.println("!!! Error !!! --> " + '"' + msg + '"');
                    System.out.println();
                    driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"OK\"]")).click();
                    driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Back\"]")).click();
                }
            }
        } catch (Exception e) {}
        */
        
        wait.until(ExpectedConditions.elementToBeClickable(lbCode)).click();
        driver.findElement(lbCode).sendKeys(lc);
        Thread.sleep(500);
        
        /*
        //for local code error
        try {
            List<WebElement> msgList = driver.findElements(By.xpath("//android.view.View"));
            if(msgList.size() >= 6) {
                WebElement content = msgList.get(6);
                if (content.isDisplayed()) {
                    String msg = content.getAttribute("content-desc");
                    System.out.println("!!! Error !!! --> " + '"' + msg + '"');
                    System.out.println();
                    driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"OK\"]")).click();
                    driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Back\"]")).click();
                }
            }
        } catch (Exception e) {}
        */
        
        WebElement view1 = driver.findElement(By.xpath("//android.view.View[@content-desc=\"Product\"]"));
        view1.click();
        
        WebElement pName = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[3]"));
        wait.until(ExpectedConditions.elementToBeClickable(pName)).click();
        pName.sendKeys(na);        
        view1.click();
        Thread.sleep(500);

        WebElement pCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[4]"));
        wait.until(ExpectedConditions.elementToBeClickable(pCode)).click();
        pCode.sendKeys(co);
        view1.click();
        Thread.sleep(500);
        
        WebElement hsCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[5]"));
        hsCode.click();
        hsCode.sendKeys(hs);
        view1.click();
        Thread.sleep(500);
        
        wait.until(ExpectedConditions.elementToBeClickable(category)).click();
        wait.until(ExpectedConditions.elementToBeClickable(searchBtn)).click();
        driver.findElement(sInput).sendKeys(cat);
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));
        Thread.sleep(1000);
        
        List<WebElement> catList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectC = catList.get(8);
        wait.until(ExpectedConditions.elementToBeClickable(SelectC)).click();
        driver.findElement(afterSelectC).click();
        wait.until(ExpectedConditions.elementToBeClickable(nextBtn1)).click();
        Thread.sleep(1000);
        
        //For error message capturing
        List<WebElement> msgList1 = driver.findElements(By.xpath("//android.view.View"));
        if (msgList1.size() >= 25) {
            WebElement content1 = msgList1.get(25);

            // Proceed only if the element is displayed
            if (content1.isDisplayed()) {
                String msg1 = content1.getAttribute("content-desc");
                System.out.println("!!! Error !!! --> " + '"' + msg1 + '"');
                System.out.println();
                driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Back\"]")).click();
            }
        }
        
        WebElement vat = driver.findElement(By.xpath("//android.widget.EditText[@text=\"0\"]"));
        wait.until(ExpectedConditions.elementToBeClickable(vat)).click();
        vat.clear();
        vat.sendKeys(vt);
        
//        wait.until(ExpectedConditions.elementToBeClickable(nextBtn2)).click();
        
        driver.findElement(unitGrp).click();
        Thread.sleep(1000);
        driver.findElement(unitGrpInput).sendKeys(ug);
        List<WebElement> ugList = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectUG = ugList.get(14);
        wait.until(ExpectedConditions.elementToBeClickable(selectUG)).click();
        
        try {

            WebElement cp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[4]")));
            wait.until(ExpectedConditions.elementToBeClickable(cp)).click();
            cp.clear();
            cp.sendKeys(cost);
            driver.findElement(apu).click();

            WebElement sp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[5]")));
            wait.until(ExpectedConditions.elementToBeClickable(sp)).click();
            sp.clear();
            sp.sendKeys(sell);
            driver.findElement(apu).click();

            wait.until(ExpectedConditions.elementToBeClickable(allowDQ)).click();
            driver.findElement(showAI).click();

            WebElement purchaseDis = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
            purchaseDis.click();
            purchaseDis.clear();
            purchaseDis.sendKeys(pd); 
            driver.findElement(apu).click();

            WebElement salesDis = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
            salesDis.click();
            salesDis.clear();
            salesDis.sendKeys(sd);
            driver.findElement(apu).click();

            WebElement maxDis = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
            wait.until(ExpectedConditions.elementToBeClickable(maxDis)).click();
            maxDis.clear();
            maxDis.sendKeys(md);
            WebElement scv = driver.findElement(By.xpath("//android.widget.ScrollView"));
            wait.until(ExpectedConditions.elementToBeClickable(scv)).click();

            WebElement openingRate = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
            openingRate.click();        
            openingRate.clear();
            openingRate.sendKeys(or);
            wait.until(ExpectedConditions.elementToBeClickable(scv)).click();

            WebElement openingQuantity = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));        
            openingQuantity.click();        
            openingQuantity.clear();
            openingQuantity.sendKeys(oq);
            wait.until(ExpectedConditions.elementToBeClickable(scv)).click();

            wait.until(ExpectedConditions.elementToBeClickable(hideAI)).click();
            driver.findElement(showBI).click();

            WebElement batchNo = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.EditText[6]"));
            batchNo.click();
            batchNo.sendKeys(bno);
            wait.until(ExpectedConditions.elementToBeClickable(scv)).click();

            WebElement expLimit = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.ScrollView/android.widget.EditText[6]")));
            expLimit.click();
            expLimit.sendKeys(eli); 
            driver.findElement(apu).click();

            wait.until(ExpectedConditions.elementToBeClickable(expType)).click();
            wait.until(ExpectedConditions.elementToBeClickable(selectExp)).click();

            wait.until(ExpectedConditions.elementToBeClickable(saveBtn1)).click();
            view1.click();
            
        } catch (Exception e) {}
        
        wait.until(ExpectedConditions.elementToBeClickable(nextBtn2)).click();
        Thread.sleep(1000);
        
        //For error msg
        try {
            List<WebElement> msgList2 = driver.findElements(By.xpath("//android.view.View"));
            if (msgList1.size() >= 16) {
            WebElement content2 = msgList2.get(16);
            
            if (content2.isDisplayed()) {
                String msg2 = content2.getAttribute("content-desc");
                System.out.println("!!! Error !!! --> " + '"' + msg2 + '"');
                System.out.println();
                driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Back\"]")).click();
            }
        }
        } catch (Exception e) {}

        wait.until(ExpectedConditions.elementToBeClickable(manufacturer)).click();
        driver.findElement(manufacturer).sendKeys(manu);
        Thread.sleep(1000);
        List<WebElement> options = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectMan = options.get(15);
        wait.until(ExpectedConditions.elementToBeClickable(selectMan)).click();
        
        wait.until(ExpectedConditions.elementToBeClickable(brand)).click();
        driver.findElement(brand).sendKeys(brn);
        Thread.sleep(1000);
        List<WebElement> options1 = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectB = options1.get(15);
        wait.until(ExpectedConditions.elementToBeClickable(selectB)).click();
        
        wait.until(ExpectedConditions.elementToBeClickable(proType)).click();
        driver.findElement(proType).sendKeys(prot);
        Thread.sleep(1000);
        List<WebElement> options2 = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectPType = options2.get(16);
        wait.until(ExpectedConditions.elementToBeClickable(selectPType)).click();
        view1.click();
        
        wait.until(ExpectedConditions.elementToBeClickable(attribute)).click();
        driver.findElement(attribute).sendKeys(attri);
        Thread.sleep(1000);
        List<WebElement> options3 = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectAttri = options3.get(15);
        wait.until(ExpectedConditions.elementToBeClickable(selectAttri)).click();
        view1.click();
        List<WebElement> attriList = driver.findElements(By.xpath("//android.view.View"));
        WebElement attriOpt = attriList.get(16);
        attriOpt.click();
        
        WebElement tag = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.EditText[5]"));
        tag.click();
        tag.sendKeys(tg);
        Thread.sleep(500);
        List<WebElement> options4 = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectTags = options4.get(20);
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(selectTags)).click();
        view1.click();
        
        List<WebElement> edit = driver.findElements(By.className("android.widget.EditText"));
        WebElement reorderP = edit.get(4);
        wait.until(ExpectedConditions.elementToBeClickable(reorderP)).click();
        reorderP.clear();
        reorderP.sendKeys(rp);
        view1.click();

        WebElement safetyStock = edit.get(5);
        wait.until(ExpectedConditions.elementToBeClickable(safetyStock)).click();
        safetyStock.clear();
        safetyStock.sendKeys(ss);
        view1.click();
        
        WebElement shortDesc = edit.get(6);
        shortDesc.click();
        shortDesc.sendKeys(sdec);
        view1.click();

        WebElement fullDesc = edit.get(7);
        wait.until(ExpectedConditions.elementToBeClickable(fullDesc)).click();
        fullDesc.sendKeys(fdec);
        view1.click();

        wait.until(ExpectedConditions.elementToBeClickable(nextBtn3)).click();
        wait.until(ExpectedConditions.elementToBeClickable(saveBtn2)).click();
        Thread.sleep(1000);
        
        try {
            List<WebElement> errList = driver.findElements(By.xpath("//android.view.View"));
            if (errList.size() >= 6) {
                WebElement err = errList.get(6);

                if (err.isDisplayed()) {
                    String errMsg = err.getAttribute("content-desc");
                    System.out.println("!!! Error !!! --> " + '"' + errMsg + '"');
                    System.out.println();
                    System.out.println("*** Processing To Next Data ***");
                    System.out.println();                
                    driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"OK\"]")).click();
                    driver.findElement(By.xpath("//android.widget.Button[@content-desc='Back']")).click();
                }
            }
        } catch (Exception e) {
            System.out.println("*** Congratulations *** -->.\"Product Created Successfully\"");
            System.out.println();
        }
    }
}
