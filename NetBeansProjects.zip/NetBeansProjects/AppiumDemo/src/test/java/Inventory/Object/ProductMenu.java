/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;

/**
 *
 * @author aman
 */
public class ProductMenu {
    
    AndroidDriver driver;
    
    public ProductMenu(AndroidDriver driver) {
        
        this.driver = driver;
        
    }
    
    By menu = By.xpath("//android.widget.Button[@content-desc='Open navigation menu']");
    By productBtn = By.xpath("//android.view.View[@content-desc=\"PRODUCT\"]");
    By itemBtn = By.xpath("//android.view.View[@content-desc=\"Items\"]");
    
    public void MenuClick() throws InterruptedException {
        
        Thread.sleep(1000);
        driver.findElement(menu).click();
        driver.findElement(productBtn).click();
        driver.findElement(itemBtn).click();
        
    }
}
