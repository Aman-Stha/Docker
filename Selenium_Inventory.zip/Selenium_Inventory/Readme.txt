
# Selenium Inventory Project

## Overview
This project automates inventory management tasks using Selenium and TestNG. The project structure is based on Maven for dependency management and includes support for ExtentReports for reporting and TestNG for test execution.

---

## Prerequisites

1. **Java Development Kit (JDK):**
   - Version 8 must be installed and set up in your system.
   - Ensure `JAVA_HOME` is configured correctly.

2. **Maven:**
   - Install Maven and ensure it is added to your system's PATH.
   - Verify Maven installation:
     ```bash
     mvn -v
     ```

3. **Browser Drivers:**
   - WebDriver binaries are managed automatically by the WebDriverManager library.

4. **TestNG XML Files:**
   - TestNG XML configuration files are located in `src/test/TestNgFiles`.

5. **Database Connectivity:**
   - Ensure access to the MySQL database if database-related tests are executed.

---

## Directory Structure

```
.
├── src
│   ├── main
│   │   └── java (application code)
│   └── test
│       ├── java (test scripts)
│       └── TestNgFiles (TestNG XML files)
├── pom.xml (Maven project file)
```

---

## Build and Run

### Step 1: Build the Project
To build the project and download dependencies, execute:
```bash
mvn clean install
```

### Step 2: Execute Tests

#### Default TestNG File
To run tests with the default TestNG XML file (`TestNG.xml`):
```bash
mvn test
```

#### Custom TestNG File
To run tests with a specific TestNG XML file (e.g., `CreateProductTest.xml`):
```bash
mvn test -DxmlFile=CreateProductTest.xml
```

#### Notes:
- TestNG XML files are located in `src/test/TestNgFiles`.
- Ensure the file exists before executing the command.

### Step 3: View Reports
1. **Extent Reports:**
   - Generated ExtentReports are available in the `target` directory after test execution.
   - Open the `.html` report file in any browser to view detailed test results.

---

## Troubleshooting

### Issue: "class file has wrong version 55.0, should be 52.0"
- Ensure JDK 8 is installed and set up.
- Check the Maven compiler plugin configuration in `pom.xml`:
  ```xml
  <source>1.8</source>
  <target>1.8</target>
  ```

### Issue: "Cannot find XML file"
- Verify that the custom TestNG XML file exists in `src/test/TestNgFiles`.

### Enable Debug Logs
For more detailed logs, add the `-X` flag when running Maven:
```bash
mvn test -DxmlFile=CreateProductTest.xml -X
```

---

