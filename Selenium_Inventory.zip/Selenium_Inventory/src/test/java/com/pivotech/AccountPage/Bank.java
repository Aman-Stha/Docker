/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.AccountPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class Bank extends PageObject{
    
    
       public Bank(WebDriver driver) {
        super(driver);
    }
      
    
    By account= By.xpath("//a[@id='pnl_Account']");
    By bank = By.xpath("//a[@id='subpnl_Bank']");
    By add = By.xpath("//button[@aria-label='Add']");
    By name= By.xpath("//input[@placeholder='Enter Name']");
    By accountno = By.xpath("//input[@placeholder='Enter Account Number']");
    By address= By.xpath("//input[@placeholder='Enter Address']");
    By branch = By.xpath("//input[@placeholder='Enter Bank Branch']");
    By banktype= By.xpath("//span[@aria-label='BANK']");
  //  By addinfo= By.xpath("//*[@id=\"pv_id_650_accordionheader_0\"]");

    //By acchead = By.xpath("//span[@aria-label='Select account head']");
//    By openamt = By.xpath("//input[@placeholder='Enter Opening Amount']");
//    By creditacc = By.xpath("//span[@aria-label='Select credit account head']");
//    By search = By.xpath("//input[@role='searchbox']");
    By save = By.xpath("//button[@aria-label='Save']");
    
    
    public Bank addbank(Map<String, String> userData) throws InterruptedException {
    click(account);
    click(bank);
    click(add);
    writeText(name, userData.get("name"));
    writeText(accountno, userData.get("accountno"));
    writeText(address, userData.get("address"));
    writeText(branch, userData.get("branch")); 
    selectDropdownOptionByAriaLabel(banktype, userData.get("banktype"));
   // click(addinfo);
   // selectFromDropdown(acchead, userData.get("acchead"));       
//    writeText(openamt, userData.get("openamt"));
//    click(creditacc);
//    selectFromDropdown(search, userData.get("search"));       
    click(save);
    Thread.sleep(1000);

    return this;
    }


        
    
}
