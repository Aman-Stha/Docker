/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.AccountPage;
import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class CashManagement extends PageObject{
    
    
       public CashManagement(WebDriver driver) {
        super(driver);
    }
      
    
    By account = By.xpath("//a[@id='pnl_Account']");
    By cashmanagement = By.xpath("//span[normalize-space()='Cash Management']");
    By add = By.xpath("//button[@aria-label='Add']");
    By withdraw = By.xpath("//span[contains(text(),'WITHDRAW')]");
    By transfer = By.xpath("//span[contains(text(),'TRANSFER')]");
    By accounthead = By.xpath("//span[@aria-label='Select account head']");
    By search = By.xpath("//input[@role='searchbox']");
    By close = By.xpath("//span[@class='p-select-option-label']");
    By clramt = By.xpath("//input[@value='0.00']");
    By amount = By.xpath("//input[@role='spinbutton']");
    By save = By.xpath("//button[@aria-label='Save']");
    
   public CashManagement pgmanagement(Map<String, String> userData) throws InterruptedException {
    click(account);
    click(cashmanagement);
    click(add);
    return this;
     }
    
   public CashManagement deposit(Map<String, String> userData) throws InterruptedException {
    click(accounthead);
    selectFromDropdown(search, userData.get("search")); 
    click(close);
    clearInputFields();
    Thread.sleep(1000); 
    writeText(amount, userData.get("amount"));   
     Thread.sleep(2000);   
    click(save);
    Thread.sleep(1000);
    return this;
    }

    public CashManagement withdraw(Map<String, String> userData) throws InterruptedException {
    click(withdraw);
    click(accounthead);
    selectFromDropdown(search, userData.get("search")); 
    click(close);
    clearInputFields();
    Thread.sleep(1000);
    writeText(amount, userData.get("amount"));       
    click(save);
     Thread.sleep(1000);
    return this;
    }
    
    public CashManagement transfer(Map<String, String> userData) throws InterruptedException {
    click(transfer);
    click(accounthead);
    selectFromDropdown(search, userData.get("search")); 
    click(close);
    clearInputFields();
    Thread.sleep(1000);
    writeText(amount, userData.get("amount"));       
    click(save);
    Thread.sleep(1000);
    return this;
    }
     
     
    public CashManagement clearInputFields() {
        clearText(clramt);
        return this;
    }
}
