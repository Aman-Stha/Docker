/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.AccountPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class OtherBill extends PageObject{
    
    
       public OtherBill(WebDriver driver) {
        super(driver);
    }
      
    
    By account= By.xpath("//a[@id='pnl_Account']");
    By otherbill = By.xpath("//a[@id='subpnl_Other_Bill']");
    By add = By.xpath("//button[@aria-label='Add']");
    By billno= By.xpath("//input[@inputmode='numeric']");
    By supplier = By.xpath("//input[@placeholder='Select Supplier']");
    By customer= By.xpath("//input[@placeholder='Select Customer']");
    By payable = By.xpath("//span[@aria-describedby='payableAmountHelp']//input[@value='0.00']");
    By payablea = By.xpath("//span[@aria-describedby='payableAmountHelp']//input[@role='spinbutton']");
    By receivable= By.xpath("//span[@aria-describedby='receivableAmountHelp']//input[@value='0.00']");
    By receivablea = By.xpath("//span[@aria-describedby='receivableAmountHelp']//input[@role='spinbutton']");
    By paymode= By.xpath("//span[@aria-label='CASH']");

    By received = By.xpath("//span[@aria-describedby='receivedAmountHelp']//input[@value='0.00']");
    By receiveda = By.xpath("//span[@aria-describedby='receivedAmountHelp']//input[@role='spinbutton']");

    By remarks = By.xpath("//input[@class='p-inputtext p-component w-full']");
    By save = By.xpath("//button[@aria-label='Save']");
    
    
    public OtherBill addbill(Map<String, String> userData) throws InterruptedException {
    click(account);
    click(otherbill);
    click(add);
    writeText(billno, userData.get("billno"));
    selectFromDropdown(supplier, userData.get("supplier"));       
    selectFromDropdown(customer, userData.get("customer")); 
    click(billno);
    clearInputFields();
    Thread.sleep(1000);
    writeText(payablea, userData.get("payablea"));
    writeText(receivablea, userData.get("receivablea"));
    selectDropdownOptionByAriaLabel(paymode, userData.get("paymode"));
    writeText(receiveda, userData.get("receiveda")); 
    writeText(remarks, userData.get("remarks"));
    click(save);
    Thread.sleep(1000);

    return this;
    }

  public OtherBill clearInputFields() {
        clearText(payable);
        clearText(receivable);
        clearText(received);
        return this;
    }
        
    
}

    

