/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.PurchasePage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class PurchaseOrder extends PageObject {
    By menu = By.xpath("//span[@class='p-button-icon pi pi-bars']");
    By Purchase = By.xpath("//*[@id=\"pnl_Purchase\"]");
    By PO = By.xpath("//a[@id='subpnl_Purchase_Order']");
    By add = By.xpath("//button[@aria-label='Add']");
    By supplier = By.xpath("//input[@id='supplier']");   
    By product = By.xpath("//input[@id='dt_product']");
  
    By confirm = By.xpath("//button[@title='Confirm Purchase']");
   // By advance = By.xpath("//span[@aria-describedby='paidAmountHelp']//input[@role='spinbutton']");
    By save = By.xpath("//button[@aria-label='Save']");
   // By toast = By.xpath("//div[@class='p-toast-message-content']");
    
    public PurchaseOrder(WebDriver driver) {
        super(driver);
    }
    
    public PurchaseOrder addPurchase (Map<String, String> userData) throws InterruptedException {
        Thread.sleep(1000);
        click(Purchase);
        click (PO);
        Thread.sleep(1000);
        click (add);
        Thread.sleep(100);
        driver.navigate().refresh();
        Thread.sleep(1000);
        selectFromDropdown(supplier,  userData.get("supplier"));
        selectFromDropdown(product, userData.get("product"));
        Thread.sleep(1000);
        click(confirm);
       //  writeText(advance, userData.get("advance"));
        click(save);
        click(menu);
        Thread.sleep(1000);
        return this;           
}
    
    
}
