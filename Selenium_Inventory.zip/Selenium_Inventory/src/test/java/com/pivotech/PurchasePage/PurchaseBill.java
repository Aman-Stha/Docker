/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.PurchasePage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class PurchaseBill extends PageObject{
   By menu = By.xpath("//span[@class='p-button-icon pi pi-bars']");
   By pnlPurchase = By.xpath("//a[@id='pnl_Purchase']");  
   By pbill = By.xpath("//a[@id='subpnl_Purchase_Bill']");   
   By add = By.xpath("//button[@aria-label='Add']");
   By reference = By.xpath("//input[@id='refBillNo']");
   By supplier = By.xpath("//input[@id='supplier']");
   By product = By.xpath("//input[@id='dt_product']");
    
   By grn = By.xpath("//input[@placeholder='Select Good Received Note']");
   By confirm = By.xpath("//button[@title='Confirm Purchase Bill']");
   By delivered = By.xpath("//input[@id='deliveredBy']");
   By save = By.xpath("//button[@aria-label='Save']");
  
public PurchaseBill(WebDriver driver) {
        super(driver);
    }
    
public PurchaseBill addbill(Map<String, String> userData) throws InterruptedException {    
    Thread.sleep(1000);
    click(pnlPurchase);
    click(pbill);
    click(add);
    Thread.sleep(1000);
    driver.navigate().refresh();
    Thread.sleep(1000);
    writeText(reference, userData.get("reference"));
    selectFromDropdown(supplier, userData.get("supplier"));
    selectFromDropdownn(grn);
    Thread.sleep(1000);
    click(confirm);
    click(save);
    click(menu);
    return this;
    }
    
public PurchaseBill directbill(Map<String, String> userData) throws InterruptedException {    
    Thread.sleep(1000);
    click(pnlPurchase);
    click(pbill);
    click(add);
    Thread.sleep(1000);
    driver.navigate().refresh();
    Thread.sleep(1000);
    writeText(reference, userData.get("reference"));
    selectFromDropdown(supplier, userData.get("supplier"));
    selectFromDropdown(product,userData.get("product"));
    Thread.sleep(1000);
    click(confirm);
    writeText(delivered, userData.get("delivered"));
    click(save);
    click(menu);
    return this;
    }
}
