/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.PurchasePage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class Supplier extends PageObject{
    
    
    
    public Supplier(WebDriver driver) {
        super(driver);
    }
  //  By clickProduct = By.xpath("//a[@id='pnl_Product']");
    By purchase = By.xpath("//a[@id='pnl_Purchase']");    
    By supplier = By.xpath("//a[@id='subpnl_Supplier']");
   
    
    By add = By.xpath("//button[@id='btn_add_supplier']");
    By name = By.xpath("//input[@id='inp_supplier_name']");
    By code = By.xpath("//input[@id='inp_supplier_code']");
    By email = By.xpath("//input[@id='inp_supplier_email']");
    By address = By.xpath("//input[@id='inp_supplier_address']");
    By phone = By.xpath("//input[@id='inp_supplier_phone_num']");
    By pan = By.xpath("//input[@id='inp_supplier_pan_num']");
    By leadTime = By.xpath("//input[@value='0']");
    By credit = By.xpath("//input[@value='0.00']");
    By save = By.xpath("//button[@id='btn_submit_add_supplier']");
   
    
    By search = By.xpath("//input[@id='inp_name_search']");
    By selectsup = By.xpath("(//td[@role='cell'])[7]");
    By payment = By.xpath("//button[@id='btn_makepayment_supplier']");
    
    By payamt = By.xpath("//input[@placeholder='Enter Paid Amount']");
    By paymode = By.xpath("//div[@id='inp_payment_mode']//div[@class='p-select-dropdown']");
    By remarks = By.xpath("//input[@id='inp_remarks']");    
    By paidbtn = By.xpath("//button[@id='btn_paid_receive_payment']");
    
    By receive = By.xpath("//span[@class='p-togglebutton-label'][normalize-space()='Received Amount']");
    By receiveamt = By.xpath("//input[@placeholder='Enter Received Amount']");
    By receivebtn = By.xpath("//button[@id='btn_paid_receive_payment']");
    
    

    public Supplier pgSupplier(Map<String, String> userData) throws InterruptedException {
        Thread.sleep(5000);
        // click(clickProduct);
        Thread.sleep(1000);
        click(purchase);
        click(supplier);
        return this;
}


    public Supplier addSupplier(Map<String, String> userData) throws InterruptedException {
        Thread.sleep(1000);
        click(add);
        writeText(name, userData.get("name"));
        writeText(code, userData.get("code"));
        writeText(email,userData.get("email"));
        writeText(address,userData.get("address"));
        writeText(phone,userData.get("phone"));
        writeText(pan,userData.get("pan"));        
        writeText(leadTime,userData.get("leadTime"));
        writeText(credit,userData.get("credit"));
        click(save);
        return this;
}
    
    public Supplier paySupplier(Map<String, String> userData) throws InterruptedException {
        writeText(search, userData.get("search"));
        driver.findElement(search).sendKeys(Keys.ENTER);  // Correct
        Thread.sleep(1000);
        click(selectsup);
        click(payment);
        writeText(payamt, userData.get("payamt"));
        selectDropdownOptionByAriaLabel(paymode, userData.get("paymode"));
        writeText(remarks, userData.get("remarks"));
        Thread.sleep(1000);
        click(paidbtn);
        Thread.sleep(10000);
        return this;
    }
    
    public Supplier receiveSupplier(Map<String, String> userData) throws InterruptedException {
       // writeText(search, userData.get("search"));
      //  driver.findElement(search).sendKeys(Keys.ENTER);  // Correct
       // Thread.sleep(1000);
        click(selectsup);
        click(payment);
        click(receive);
        writeText(receiveamt, userData.get("receiveamt"));
        selectDropdownOptionByAriaLabel(paymode, userData.get("paymode"));
        writeText(remarks, userData.get("remarks"));
        Thread.sleep(1000);
        click(receivebtn);
        Thread.sleep(10000);
        return this;
    }
    
    
}
