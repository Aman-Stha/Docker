/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.PurchasePage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class DebitNote extends PageObject {
    
    public DebitNote(WebDriver driver) {
        super(driver);
    }
    
     By pnlPurchase = By.xpath("//a[@id='pnl_Purchase']"); 
     By debit= By.xpath("//a[@id='subpnl_Debit_Note | Purchase Return']");
     By add =By.xpath("//button[@aria-label='Add']");
     
     By supplier = By.xpath("//input[@placeholder='Select Supplier']");
     By grn = By.xpath("//input[@placeholder='Select Good Received Note']");
     By withrefno = By.xpath("//span[contains(text(),'With GRN Reference Number')]");
     By product = By.xpath("//input[@id='product']");
     By grnref = By.xpath("//input[@id='grnReferenceNo']");
     By confirm = By.xpath("//button[@title='Confirm Debit Note']");
     By remarks = By.xpath("//input[@placeholder='Enter Remarks']");
     By save = By.xpath("//button[@aria-label='Save']");
     
     
      public DebitNote addDebit(Map<String, String> userData) throws InterruptedException {    
      click(pnlPurchase);
      click (debit);
      click (add);
      selectFromDropdown(supplier, userData.get("supplier"));
      selectFromDropdownn(grn);
      Thread.sleep(3000);
      click (confirm);
      writeText(remarks, userData.get("remarks"));
      click (save);
       return this;
    }
      
      public DebitNote directDebit(Map<String, String> userData) throws InterruptedException {    
      click(pnlPurchase);
      click (debit);
      click (add);
      click(withrefno);
      selectFromDropdown(supplier, userData.get("supplier"));
      writeText(grnref, userData.get("grnref"));
      selectFromDropdown(product,userData.get("product"));
      Thread.sleep(3000);
      click (confirm);
      writeText(remarks, userData.get("remarks"));
      click (save);
       return this;
    }
    
    
}
