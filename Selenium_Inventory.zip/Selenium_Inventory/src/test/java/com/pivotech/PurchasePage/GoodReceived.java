package com.pivotech.PurchasePage;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author amrita
 */
public class GoodReceived extends PageObject{
    By menu = By.xpath("//span[@class='p-button-icon pi pi-bars']");
    By Purchase = By.xpath("//*[@id=\"pnl_Purchase\"]");
    By grn = By.xpath("//span[normalize-space()='Good Received Note']");
    By add = By.xpath("//button[@aria-label='Add']");
    By delivered = By.xpath("//input[@id='deliveredBy']");
    By received = By.xpath("//input[@placeholder='Select Received by']");
    By remarks = By.xpath("//input[@id='remarks']");
    By credit = By.xpath("//input[@value='0']");
    By supplier = By.xpath("//input[@id='supplier']");
    By product = By.xpath("//input[@id='dt_product']");
    By purchaseo = By.xpath("//input[@placeholder='Select Purchase Order']");
    By confirm = By.xpath("//button[@aria-label='Confirm ']");
    By save = By.xpath("//button[@aria-label='Save']");
   

    public GoodReceived(WebDriver driver) {
        super(driver);
    }
    
    
   public String addGrn (Map<String, String> userData) throws InterruptedException {
    Thread.sleep(3000);
    click(Purchase);
    Thread.sleep(3000);
    click(grn);
    click(add);
    Thread.sleep(100);
    driver.navigate().refresh();
    selectFromDropdown(supplier, userData.get("supplier"));
    writeText(delivered, userData.get("delivered"));
    selectFromDropdown(received, userData.get("received"));
    writeText(remarks, userData.get("remarks"));
    writeText(credit, userData.get("credit"));    
    selectFromDropdownn(purchaseo); 
    Thread.sleep(1000);
    WebElement cell = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='1.00']")));
    String quantity = cell.getAttribute("value");
    click(confirm);
    click(save);
    click(menu);
    return quantity ;
   }

     
   public String directGrn (Map<String, String> userData) throws InterruptedException {
    Thread.sleep(3000);
    click(Purchase);
    Thread.sleep(3000);
    click(grn);
    click(add);
    Thread.sleep(100);
    driver.navigate().refresh();
    selectFromDropdown(supplier, userData.get("supplier"));
    writeText(delivered, userData.get("delivered"));
    selectFromDropdown(received, userData.get("received"));
    writeText(remarks, userData.get("remarks"));
    writeText(credit, userData.get("credit"));    
    selectFromDropdown(product,userData.get("product"));
    Thread.sleep(1000);
    WebElement cell = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='1.00']")));
    String quantity = cell.getAttribute("value");
    click(confirm);
    click(save);
    click(menu);
    return quantity ;
   }
     

  
}