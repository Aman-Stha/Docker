package com.pivotech.page;

import com.pivotech.helper.PageObject;
import static com.pivotech.pageTest.BaseTest.openUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

public class UserPage extends PageObject {
    public UserPage(WebDriver driver) {
        super(driver);
    }
     public void openPage() {
        openUrl("");

    }

    By regButton = By.xpath("//span[normalize-space()='Register Now']");
    By fname = By.xpath("//input[@placeholder='Enter First Name']");
    By lname = By.xpath("//input[@placeholder='Enter Last Name']");
    By uname = By.xpath("//input[@placeholder='Enter User Name']");
    By DOB = By.xpath("//input[@id='dob']");
    By genderButton = By.xpath("//div[@class='p-select-dropdown']//*[name()='svg']");
    By phone = By.xpath("//input[@placeholder='Enter Phone Number']");
    By email = By.xpath("//input[@placeholder='Enter Email']");
    By pass = By.xpath("//input[@placeholder='Password']");
    By conpass = By.xpath("//input[@placeholder='Enter Confirm Password']");
   
    By registerBtn = By.xpath("//span[normalize-space()='Register']");

    public UserPage submit(Map<String, String> userData) {
        click(regButton);
        writeText(fname, userData.get("fname"));
        writeText(lname, userData.get("lname"));
        writeText(uname, userData.get("uname"));
        click(DOB);
        clearInputFields();
        writeText(DOB, userData.get("DOB"));
        click(genderButton);
        selectDropdownOptionByAriaLabel(userData.get("gender"));
        
        writeText(phone, userData.get("phone"));
        writeText(email, userData.get("email"));
        writeText(pass, userData.get("pass"));
        writeText(conpass, userData.get("conpass"));
        click(registerBtn);
        return this;
    }

    public boolean compareFieldErrorMessage(By errorLocator, String expectedErrorMessage) {
        String actualErrorMessage = getErrorMessage(errorLocator);
        return actualErrorMessage.equals(expectedErrorMessage);
    }

    public String getExpectedFieldErrorMessage(Map<String, String> userData) {
        return userData.get("expectedErrorMessage");
    }

    public void clearFieldError(By errorLocator) {
        clearText(errorLocator);
    }

 /*   private void selectDropdownOptionByAriaLabel(String optionLabel) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@aria-label='" + optionLabel + "']")));
        WebElement option = driver.findElement(By.xpath("//li[@aria-label='" + optionLabel + "']"));
        option.click();
    }*/
 
    
    
    
    private void selectDropdownOptionByAriaLabel(String optionLabel) {
    if (optionLabel != null) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        By optionLocator = By.xpath("//li[@aria-label='" + optionLabel + "']");
        wait.until(ExpectedConditions.presenceOfElementLocated(optionLocator));
        WebElement option = driver.findElement(optionLocator);
        option.click();
    } else {
        System.out.println("Option label is null. Skipping selection.");
    }
}

    
    
  

    public UserPage clearInputFields() {
        clearText(DOB);
        return this;
    }


    public void clearText(By element) {
        driver.findElement(element).clear();
    }

    public UserPage refreshPage() {
        driver.navigate().refresh();
        return this;
    }

    public By getBy(String field) {
        switch (field) {
            case "fnError":
                return By.xpath("//span[normalize-space()='First name is required!!']");
            case "lnError":
                return By.xpath("//span[normalize-space()='Last name is required!!']");
            case "unameError":
                return By.xpath("//span[normalize-space()='User name is required!!']");
            case "phoneError":
                return By.xpath("//span[@id='phoneNoHelp']");
            case "passError":
                return By.xpath("//span[normalize-space()='Password is required!!']") ;
            case "conpassError":
                return By.xpath("//span[normalize-space()='Confirm Password is a required field']");
            case "dobError":
                return By.xpath("//span[normalize-space()='Incorrect Date Pattern!!!']");
           
            default:
                throw new UnsupportedOperationException("Locator for field " + field + " is not defined");
        }
    }

    private String getErrorMessage(By errorLocator) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement errorElement = wait.until(ExpectedConditions.visibilityOfElementLocated(errorLocator));
        return errorElement.getText();
    }
}
