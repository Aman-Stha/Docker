package com.pivotech.page;

import com.pivotech.helper.PageObject;
import static com.pivotech.pageTest.BaseTest.openUrl;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateProductpage extends PageObject {

    public By message;

    public CreateProductpage(WebDriver driver) {
        super(driver);
    }
    
    public void ProductPage() {
        openUrl("product/list");
    }

    By add = By.xpath("//span[normalize-space()='Add']");
    By pname = By.xpath("//input[@id='name']");
    By pcode = By.xpath("//input[@id='code']");
    By grpcode = By.xpath("//input[@id='groupCode']");
    By pnature = By.xpath("//*[@id=\"nature\"]");
    By pcategory = By.xpath("//*[@id=\"category\"]");
    By pcatclose = By.xpath("//div[@id='category']//button[@type='button']");
    By punit = By.xpath("//*[@id=\"unitGroup\"]");
    By gbarcode = By.xpath("//div[@id='globalBarcode']//input[@type='text']");
    By lbarcode = By.xpath("//div[@id='localBarcode']//input[@type='text']");
    By next1 = By.xpath("//span[normalize-space()='Next']");

    By nError = By.xpath("//*[@id=\"nameHelp\"]");
    By catError = By.xpath("//*[@id=\"categoryHelp\"]");
    By unitError = By.xpath("//*[@id=\"unitGroupHelp\"]");
    
    By detailbutton = By.xpath("//*[@id=\"dt_product_unit\"]/div[1]/table/tbody/tr[1]/td[1]/button");
    By vat = By.xpath("//input[@id='inp_vatPercent']");
    By pCP = By.xpath("//input[@id='inp_costPrice_0']");
    By pSP = By.xpath("//input[@id='inp_sellingPrice_0']");
    By Pdiscount = By.xpath("//input[@id='inp_purchaseDiscountPercent_0']");
    By Sdiscount = By.xpath("//input[@id='inp_saleDiscountPercent_0']");
    By Mdiscount = By.xpath("//input[@id='inp_maxDiscountPercent_0']");
    By openingQ = By.xpath("//span[@aria-describedby='quantityHelp']//input[@role='spinbutton']");
    By openingR = By.xpath("//span[@aria-describedby='openingStockUnitRateHelp']//input[@role='spinbutton']");
    By batch = By.xpath("//input[@class='p-inputtext p-component']");
    By expType = By.xpath("//div[@class='p-dropdown-trigger']");
    By expLimit = By.xpath("//input[@placeholder='Enter Expiry Limit']");
    By next2 = By.xpath("//button[@id='btn_next_unit']");
    
    By manufacture = By.xpath("//input[@id='inp_manufacture']");
    By brand = By.xpath("//input[@id='inp_brand']");
    By producttype = By.xpath("//input[@id='inp_productType']");
    By tag = By.xpath("//div[@id='inp_productTags']//div[@class='p-multiselect-trigger']");
    By attribute = By.xpath("//div[@class='p-multiselect-label p-placeholder'][normalize-space()='Select attribute']"); 
    By closeattri = By.xpath("//button[@class='p-multiselect-close p-link']");
    By attriOption = By.xpath("//span[@id='inp_attributeOptions']");
    By stockOM = By.xpath("//span[@id='inp_stockOutMethod']");
    By stockVM = By.xpath("//span[@id='inp_stockOutRateMethod']");

    By safetystock = By.xpath("//input[@id='inp_safetyStock']");
    By reorderP = By.xpath("//input[@id='inp_reorderQuantity']");

    By shortDecs = By.xpath("//input[@id='inp_shortDescription']");      
    By fullDecs = By.xpath("//input[@id='inp_fullDescription']");      
    By next3 = By.xpath("//button[@id='btn_next_add_info']");
    By next4 = By.xpath("//span[normalize-space()='Next']");
    By save = By.xpath("//*[@id=\"btn_save_product\"]/span[1]");




    public CreateProductpage namedetails(Map<String, String> userData) throws InterruptedException {
        click(add);
        writeText(pname, userData.get("pname"));
        writeText(pcode, userData.get("pcode"));
        writeText(grpcode, userData.get("grpcode"));
      try {  selectDropdownOptionByAriaLabel(pnature, userData.get("pnature"));}
      catch(Exception e){}
     try { selectDropdownOptionByAriaLabel(pcategory, userData.get("pcategory"));}
        catch (Exception e) { 
            click(pcatclose);
}
     try { selectDropdownOptionByAriaLabel(punit, userData.get("punit"));}
        catch (Exception e) { }
      //  selectDropdownOptionByAriaLabel(punit, userData.get("punit"));
        writeText(gbarcode, userData.get("gbarcode"));
        driver.findElement(gbarcode).sendKeys(Keys.RETURN);
        writeText(lbarcode, userData.get("lbarcode"));
        driver.findElement(lbarcode).sendKeys(Keys.RETURN);
        click(next1);
     

       if (checkAndCompareErrors(userData)) {
            return this;
        }          
        // Proceed with pricedetails if no errors found
        pricedetails(userData);
        return this;
    }

    public CreateProductpage pricedetails(Map<String, String> userData) throws InterruptedException {
        click(detailbutton);
        click(pCP);
        clearInputFields();
        writeText(vat, userData.get("vat"));
        writeText(pCP, userData.get("pCP"));
        writeText(pSP, userData.get("pSP"));
        writeText(Pdiscount, userData.get("Pdiscount"));
        writeText(Sdiscount, userData.get("Sdiscount"));
        writeText(Mdiscount, userData.get("Mdiscount"));
        writeText(openingQ, userData.get("openingQ"));
        writeText(openingR, userData.get("openingR"));
        writeText(batch, userData.get("batch"));
        selectDropdownOptionByAriaLabel(expType, userData.get("expType"));
        writeText(expLimit, userData.get("expLimit"));
        click(next2);
        
        adddetails(userData);
        return this;
        
    }
    
   
 public CreateProductpage adddetails(Map<String, String> userData) throws InterruptedException {
        selectDropdownOptionByAriaLabell(manufacture, userData.get("manufacture"));
        selectDropdownOptionByAriaLabell(brand, userData.get("brand"));
        selectDropdownOptionByAriaLabell(producttype, userData.get("producttype"));
        selectDropdownOptionByAriaLabell(tag, userData.get("tag"));
        click(tag);
        selectDropdownOptionByAriaLabell(attribute, userData.get("attribute"));
        click(closeattri);
        selectDropdownOptionByAriaLabell(attriOption, userData.get("attriOption"));
        selectDropdownOptionByAriaLabell(stockOM, userData.get("stockOM"));
        selectDropdownOptionByAriaLabell(stockVM, userData.get("stockVM"));
        writeText(safetystock, userData.get("safetystock"));
        writeText(reorderP, userData.get("reorderP"));
        Thread.sleep(3000);
        writeText(shortDecs, userData.get("shortDecs"));
        Thread.sleep(3000);
        writeText(fullDecs, userData.get("fullDecs"));
        click(next3);
        click(next4);
        click(save);
        return this;
        
 }
   private void selectDropdownOptionByAriaLabell(By dropdownLocator, String optionLabel) {
        click(dropdownLocator);
        WebDriverWait wait = new WebDriverWait(driver, 2);
        if (optionLabel == null || optionLabel.isEmpty()) {
            try {
                Thread.sleep(100); // Wait for 2 seconds if optionLabel is empty
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            return; // Exit the method as there is no option to select
        }
     for (int attempt = 0; attempt < 3; attempt++) {
       try {
                WebElement option = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@aria-label='" + optionLabel + "']")));
                option.click();
              break;
            } catch (StaleElementReferenceException e) {
                System.out.println("StaleElementReferenceException occurred, retrying...");
            } catch (Exception e) {
                System.out.println("Option not found for: " + optionLabel);
               break;
            }
     
    }}
public CreateProductpage clearInputFields() {
        clearText(pCP);
        clearText(pSP);
        clearText(vat);
        clearText(Pdiscount);
        clearText(Sdiscount);
        clearText(Mdiscount);
        clearText(openingQ);
        clearText(openingR);
        clearText(expLimit);
        return this;
    }

    public void clearText(By element) {
        driver.findElement(element).clear();
    }
    
public boolean checkAndCompareErrors(Map<String, String> userData) {
        boolean errorFound = false;
        WebDriverWait wait = new WebDriverWait(driver, 1); // Set wait time to 2 seconds

        if (isElementDisplayed(nError)) {
            String actualError = wait.until(ExpectedConditions.visibilityOfElementLocated(nError)).getText();
            String expectedError = userData.get("nError");
            System.out.println("Name Error: " + actualError + " | Expected: " + expectedError);
            if (actualError.equals(expectedError)) {
                errorFound = true;
            }
        }
        else if (isElementDisplayed(catError)) {
            String actualError = wait.until(ExpectedConditions.visibilityOfElementLocated(catError)).getText();
            String expectedError = userData.get("catError");
            System.out.println("Category Error: " + actualError + " | Expected: " + expectedError);
            if (actualError.equals(expectedError)) {
                errorFound = true;
            }
        } else if (isElementDisplayed(unitError)) {
            String actualError = wait.until(ExpectedConditions.visibilityOfElementLocated(unitError)).getText();
            String expectedError = userData.get("unitError");
            System.out.println("Unit Group Error: " + actualError + " | Expected: " + expectedError);
            if (actualError.equals(expectedError)) {
                errorFound = true;
            }
        }

        return errorFound;
    
    }

    public boolean isElementDisplayed(By element) {
        return !driver.findElements(element).isEmpty();
    }
}
