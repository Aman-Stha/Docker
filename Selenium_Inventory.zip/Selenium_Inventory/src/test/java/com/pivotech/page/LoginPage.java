package com.pivotech.page;

import com.pivotech.helper.PageObject;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class LoginPage extends PageObject{
    
    public LoginPage(WebDriver driver) {
        super(driver);
    }
    
    // For User Login Start
    By UserName = By.id("username");
    By Password=By.xpath("//input[@id='password1']");    
    By Loginbutton=By.xpath("//span[normalize-space()='Sign In']");
    By Message=By.xpath("//span[@class='p-toast-summary'][@data-pc-section='summary']");
    By Logoutbutton=By.xpath("//*[@id=\"app\"]/div/div[1]/div/div/button[5]");
    //For User Login End
    
    // For Forgot Password Start
    By Forgotpassword=By.xpath("//*[@id=\"app\"]/form/div/div/div/div/div[2]/div[3]/button/span[1]");
    By FUserName=By.xpath("/html/body/div[2]/div/div[2]/form/div[1]/div[1]/div/input");
    By FDob=By.xpath("/html/body/div[2]/div/div[2]/form/div[1]/div[2]/div/div/input");
    By FNewpass=By.xpath("/html/body/div[2]/div/div[2]/form/div[1]/div[3]/div/div/input");
    By FConfirmPass=By.xpath("/html/body/div[2]/div/div[2]/form/div[1]/div[4]/div/div/input");
    
    By Resetbutton=By.xpath("/html/body/div[2]/div/div[2]/form/div[2]/div/button/span[1]");
    By UserMessage= By.xpath("//*[@id=\"usernameHelp\"]");
    By DOBMessage= By.xpath("//*[@id=\"dateOfBirthHelp\"]");
    By NewpassMessage= By.xpath("//*[@id=\"newPasswordHelp\"]");
    By ConfirmMessage= By.xpath("//*[@id=\"confirmPasswordHelp\"]");
    // For Forgot Password End
       
    
    
    public LoginPage OnlyLogin(String user, String pass){
        writeText(UserName, user);
        writeText(Password, pass);
        click(Loginbutton);
        //click(Logoutbutton);
              return this;
    }
    
    public LoginPage Loginwithmsg(String user, String pass){
        
        writeText(UserName, user);
        writeText(Password, pass);
        click(Loginbutton);
        waitVisibility(Message);
        
        String LoginMsg=readText(Message);
        System.out.println("Login msg= " + LoginMsg);
       return this;        
    }
    
    public LoginPage Loginmsgcheck(String expected_result){
        String actual_result=readText(Message);
        assertEquals(expected_result, actual_result);
        return this;
    }   
    
    public LoginPage Clearinputs(){
        // Added page refresh as clear not working
        driver.navigate().refresh();
        // For Clearing fields
        //driver.findElement(UserName).clear();
        //driver.findElement(Password).clear();
        return this;
    }
    
    public LoginPage ResetPassword(String Fuser, String Npass, String Cpass, String dob ){
        click(Forgotpassword);
        writeText(FUserName, Fuser);
        click(FDob);
        driver.findElement(FDob).clear();
        click(FDob);
        writeText(FDob, dob);
        click(FNewpass);
        writeText(FNewpass, Npass);
        writeText(FConfirmPass, Cpass);
        click(FNewpass);
        click(Resetbutton);
        click(Resetbutton);
        
        String UserMessage1= readText(UserMessage);
        String DOBMessage1= readText(DOBMessage);
        String NewpassMessage1= readText(NewpassMessage);
        String ConfirmMessage1= readText(ConfirmMessage);
        String Message1= readText(Message);
        
        System.out.println("Username message=" + UserMessage1);
        System.out.println("DOB message=" + DOBMessage1);
        System.out.println("New pass message=" + NewpassMessage1);
        System.out.println("Confirm message=" + ConfirmMessage1);
        System.out.println("Box message=" + Message1);
        
        
        return this;
        
    }
    
    public LoginPage Resetmsgcheck(String expected_result1, String expected_result2, String expected_result3){
        waitVisibility(ConfirmMessage);
        String actual_result1=readText(ConfirmMessage);
        String actual_result2=readText(UserMessage);
        String actual_result3=readText(NewpassMessage);
        
         if ((actual_result1.equals(expected_result1) &&
          actual_result2.equals(expected_result2) &&
          actual_result3.equals(expected_result3))) {
        throw new AssertionError("One or more assertions failed.");
    }
        return this;
 
    } 
}
