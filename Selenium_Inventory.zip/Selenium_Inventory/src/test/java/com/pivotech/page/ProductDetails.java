/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.page;

import com.pivotech.helper.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author amrita
 */
public class ProductDetails extends PageObject {
    
    public ProductDetails(WebDriver driver) {
        super(driver);
    }
    
        By clickProduct = By.xpath("//a[@id='pnl_Product']");
        By subProduct = By.xpath("//span[normalize-space()='Product Details']");
        By product = By.xpath("(//input[@placeholder='Search'])[1]");
         


 public String stock(String prod) throws InterruptedException{
     Thread.sleep(1000);
     
     click(clickProduct);
        click(subProduct);
        Thread.sleep(1000);
         click(product);
        clearInputFields();
        Thread.sleep(1000);
        writeText(product, prod);
        driver.findElement(product).sendKeys(Keys.RETURN);
        
        
         Thread.sleep(10000);
//         WebElement cell = driver.findElement(By.cssSelector("tbody tr:nth-child(1) td:nth-child(8)"));
//         String value = cell.getText();
//         System.out.println("Stock value is : " + value);
//            
//       return value;        
//    }


         String stockValue = getStockValue();
        // Check if the stock value indicates availability
        if (stockValue == null || stockValue.isEmpty() || stockValue.equals("0")) {
            System.out.println("Product not available.");
            stockValue = "0";
          //  System.out.println("Initial Stock value is: " + stockValue); 

            
        } else {
           // System.out.println("Initial Stock value is: " + stockValue); 
           
        }
        return stockValue;
    }

    private String getStockValue() {
        // Retrieve the stock value from the table
        try {
            WebElement cell = driver.findElement(By.cssSelector("tbody tr:nth-child(1) td:nth-child(9)"));    
             
                  String value =  cell.getText();
            return value;
        } catch (Exception e) {
          System.out.println("Error retrieving stock value: " + e.getMessage());
            return null;
        }
    }

 public ProductDetails clearInputFields() {
        clearText(product);
       
        return this;
    }

    public void clearText(By element) {
        driver.findElement(element).clear();
    }


}


