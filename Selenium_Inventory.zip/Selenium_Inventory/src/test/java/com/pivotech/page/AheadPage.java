/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.page;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author amrita
 */
    public class AheadPage extends PageObject {

        public AheadPage(WebDriver driver) {
            super(driver);
        }
         private String openingEquity ;  
         private String categoryAssetHead;  

        By report =By.xpath("//span[normalize-space()='Reports']");
        By financial = By.xpath("//a[@id='pnl_Financial_Report']");
        By ledger = By.xpath("//span[normalize-space()='Sub Ledger Report']");
        By fromdate = By.xpath("//div[@name='fromDateInput']//input[@placeholder='YYYY-MM-DD']");
        By todate=By.xpath("//div[@name='toDateInput']//input[@placeholder='YYYY-MM-DD']");
        By selaccount = By.xpath("//span[@aria-label='Select Account Head']");
        By  searchbox = By.xpath("//input[@role='searchbox']");
        By generate = By.xpath("//button[@aria-label='Generate']");
        By cross =  By.xpath("//div[@id='78']//*[name()='svg']");
        By svg = By.xpath("//div[@class='p-select-dropdown']//*[name()='svg']");



        public AheadPage checkblnc(Map<String, String> userData) throws InterruptedException{
            click(report);
            click(financial);
            click (ledger);
            click (fromdate);
            clearInputFields();
            writeText(fromdate, userData.get("fromdate"));
            writeText(todate,userData.get("todate"));
            click(selaccount);
            Thread.sleep(1000);
            // writeText(searchbox, userData.get("accounthead"));
            selectDropdownOptionByAriaLabel(searchbox, userData.get("equity"));
                    Thread.sleep(1000);
            click(generate);

            Thread.sleep(1000);
            WebElement equity = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[8]"));
            openingEquity = equity.getText();  // Store value in instance variable
    //        System.out.println(" Balance in OPENING_EQUITY : " + openingEquity);
             Thread.sleep(1000);
             click(cross);
            click(svg);


            Thread.sleep(1000);


             selectDropdownOptionByAriaLabel(searchbox, userData.get("asset"));
             click(generate);


            WebElement asset = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[8]"));
            categoryAssetHead = asset.getText();  // Store value in instance variable
    //        System.out.println(" Balance in Category_Asset_Head : " + categoryAssetHead);


            click (report);
            Thread.sleep(1000);

            return this;
        }

          public String getOpeningEquity() {
            return openingEquity;  // Return stored value
        }

        public String getCategoryAssetHead() {
            return categoryAssetHead;  // Return stored value
        }
        public AheadPage clearInputFields() {
            clearText(fromdate);
            clearText(todate);
            return this;
        }
    }
