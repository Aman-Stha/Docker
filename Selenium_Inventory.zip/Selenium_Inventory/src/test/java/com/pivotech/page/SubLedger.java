package com.pivotech.page;

import com.pivotech.helper.PageObject;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SubLedger extends PageObject {

    public SubLedger(WebDriver driver) {
        super(driver);
    }

    // Store balances in a Map
    private final Map<String, String> accountBalances = new HashMap<>();

    // Locators
    By report = By.xpath("//span[normalize-space()='Reports']");
    By financial = By.xpath("//a[@id='pnl_Financial_Report']");
    By ledger = By.xpath("//span[normalize-space()='Sub Ledger Report']");
    By fromdate = By.xpath("//div[@name='fromDateInput']//input[@placeholder='YYYY-MM-DD']");
    By todate = By.xpath("//div[@name='toDateInput']//input[@placeholder='YYYY-MM-DD']");
    By searchbox = By.xpath("//input[@role='searchbox']");
    By generate = By.xpath("//button[@aria-label='Generate']");
    By svg = By.xpath("//div[@class='p-select-dropdown']//*[name()='svg']");

    // Method to check balances
    public SubLedger checkblnc(Map<String, String> userData) throws InterruptedException {
        // Click report and ledger to open the page
        click(report);
        Thread.sleep(1000);
        click(financial);
        
        click(ledger);
        Thread.sleep(1000);

        // Enter from and to dates
        clearInputFields();
        writeText(fromdate, userData.get("fromdate"));
        writeText(todate, userData.get("todate"));

        // Loop through each key in userData that starts with 'acchead'
        for (int i = 1; ; i++) {
            String accheadKey = "acchead" + i;
            if (!userData.containsKey(accheadKey)) {
                break; // Exit loop if no further acchead keys are present
            }
            click(svg);

            selectDropdownOptionByAriaLabel(searchbox, userData.get(accheadKey));
          
            click(generate);
           
            Thread.sleep(1000);
            WebElement balanceElement = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[8]")); // Simplified XPath
            String balance = balanceElement.getText().trim(); // Trim to remove whitespace
            
            // Check if balance is null or empty before proceeding
//            if (balance == null || balance.isEmpty()) {
//                balance = "0.00"; // Assign a default value if balance is not found
//            }
            System.out.println("Balance in " + accheadKey + " : " + balance);

            // Store the balance in the map with the acchead key
            accountBalances.put(accheadKey, balance);
        
        }
        Thread.sleep(1000);
        return this;
    }

    // Unified getter method for account balances
    public String getBalanceByAccountHead(String accheadKey) {
        return accountBalances.get(accheadKey); // Retrieve balance by account head key
    }

    // Method to clear date input fields
    public SubLedger clearInputFields() {
        clearText(fromdate);
        clearText(todate);
        return this;
    }
}
