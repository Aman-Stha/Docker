/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.page;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author amrita
 */
public class VoucherPage extends PageObject{

    public VoucherPage(WebDriver driver) {
        super(driver);
    }
    
    
     By account = By.xpath("//a[@id='pnl_Account']//span[@class='pi pi-angle-down text-primary ml-auto']");
     By voucher = By.xpath("//span[normalize-space()='Voucher']");
     By selectvoucher = By.xpath("(//td[@role='cell'])[7]");
     By view = By.xpath("//span[@class='p-button-icon p-button-icon-left pi pi-eye']");
     
    
    private String openingEquity;  // Store Opening Equity
    private String categoryAssetHead;  // Store Category Asset Head

     
     public VoucherPage stockvoucher() throws InterruptedException{
         click(account);
         click(voucher);
         Thread.sleep(1000);
        
         
         return this;
             
}
     
         public String getStockValue() throws InterruptedException {
             Thread.sleep(1000);

             WebElement cell = driver.findElement(By.xpath("//tbody/tr[1]/td[7]"));
        String stockvalue = cell.getText();
         System.out.println("Stock value is : " + stockvalue);
         return stockvalue;
        
    }
  
        public VoucherPage ratecheck() throws InterruptedException {
        click(selectvoucher);
        Thread.sleep(1000);
        click(view);

        WebElement asset = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[2]/div[1]/div[7]/div[2]/table[1]/tbody[1]/tr[1]/td[2]"));
        categoryAssetHead = asset.getText();  // Store value in instance variable
        System.out.println("Debit amount in Category_Asset_Head : " + categoryAssetHead);

        WebElement equity = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[2]/div[1]/div[7]/div[2]/table[1]/tbody[1]/tr[2]/td[3]"));
        openingEquity = equity.getText();  // Store value in instance variable
        System.out.println("Credit amount in Opening_equity : " + openingEquity);

        return this;
    }

    // Getter methods for Opening Equity and Category Asset Head
    public String getOpeningEquity() {
        return openingEquity;  // Return stored value
    }

    public String getCategoryAssetHead() {
        return categoryAssetHead;  // Return stored value
    }
     
    
}
