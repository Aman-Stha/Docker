/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.pageTest;

import static com.pivotech.pageTest.BaseTest.driver;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class CreateProductTest extends AfterLoginTest{
    

   @Test
    public void CreateProductTest() throws InterruptedException, IOException {
       
        String csvFilePath = "TestDataSet/Add_product/addproduct.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                
               createproduct.ProductPage();
                createproduct.namedetails(userData);

                if (createproduct.checkAndCompareErrors(userData)) {
                    System.out.println("Error found in current dataset, moving to the next dataset.");
                } else {
                    
                    createproduct.pricedetails(userData);
                    System.out.println("Proceeding to pricedetails method...");
                    createproduct.adddetails(userData);
                  
                }
            }
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
}
