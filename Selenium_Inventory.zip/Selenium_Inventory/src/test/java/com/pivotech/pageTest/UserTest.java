 package com.pivotech.pageTest;

import com.pivotech.page.UserPage;
import static com.pivotech.pageTest.BaseTest.openUrl;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserTest extends BaseTest {
   
    
   
    @Test
    public void UserTest() throws InterruptedException, IOException {
       
        String csvFilePath = "TestDataSet/UserRegistration/userreg.csv";
        String line = "";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                userpage.openPage();
userpage.submit(userData);
               

                for (String field : headers) {
                    if (field.endsWith("Error")) {
                        String expectedError = userpage.getExpectedFieldErrorMessage(userData);
                        boolean isErrorMatching = userpage.compareFieldErrorMessage(userpage.getBy(field), expectedError);
                        if (isErrorMatching) {
                            System.out.println("Error message for " + field.replace("Error", "") +
                                    " is as expected: " + expectedError);
                        } else {
                            System.out.println("Error message for " + field.replace("Error", "") +
                                    " does not match the expected one.");
                        }
                        userpage.clearFieldError(userpage.getBy(field));
                    }
                }

                Thread.sleep(300);
            }
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
}
