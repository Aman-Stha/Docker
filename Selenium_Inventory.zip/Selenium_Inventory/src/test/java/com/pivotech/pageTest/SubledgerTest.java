package com.pivotech.pageTest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SubledgerTest extends BaseTest {

    private final Map<String, String> initialBalances = new HashMap<>(); // Store initial balances

    @Test
    public void Login() throws InterruptedException {
        openUrl("/Login");
        loginpage.OnlyLogin("asus", "sigma@123");
    }

    @Test(dependsOnMethods = "Login")
    public void initialblncTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/SubLedger/accounthead.csv";
        String line;
        List<Integer> accheadIndices = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }

            // Identify headers and find indices of 'acchead' columns
            String[] headers = lines.get(0);
            for (int j = 0; j < headers.length; j++) {
                if (headers[j].startsWith("acchead")) {
                    accheadIndices.add(j);
                }
            }

            // Process each data row in the CSV
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();

                // Load necessary data into userData
                userData.put("fromdate", getValueAtIndex(data, 0));
                userData.put("todate", getValueAtIndex(data, 1));

                for (int index : accheadIndices) {
                    userData.put(headers[index], getValueAtIndex(data, index));
                }

                // Call checkblnc with the populated userData map
                subledger.checkblnc(userData);

                // Print and store initial balances for each 'acchead'
                for (int index : accheadIndices) {
                    String accheadKey = headers[index];
                    String balance = subledger.getBalanceByAccountHead(accheadKey);
                    System.out.println("Initial Balance in " + accheadKey + " : " + balance);
                    initialBalances.put(accheadKey, balance); // Store initial balance
                }
            }
        }
    }

    @Test(dependsOnMethods = "initialblncTest")
    public void ProductTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Add_product/addproduct.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }

                addproduct.namedetails(userData)
                          .pricedetails(userData)
                          .adddetails(userData);
            }
        }
    }



//
//@Test(dependsOnMethods = "ProductTest")
//public void finalblncTest() throws InterruptedException, IOException {
//    String csvFilePath = "TestDataSet/SubLedger/accounthead.csv";
//    String line;
//    List<Integer> accheadIndices = new ArrayList<>();
//    List<Integer> accbalIndices = new ArrayList<>(); // To store indices of 'accbal' columns
//
//    try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
//        List<String[]> lines = new ArrayList<>();
//        while ((line = br.readLine()) != null) {
//            lines.add(line.split(","));
//        }
//
//        // Identify headers and find indices of 'acchead' and 'accbal' columns
//        String[] headers = lines.get(0);
//        for (int j = 0; j < headers.length; j++) {
//            if (headers[j].startsWith("acchead")) {
//                accheadIndices.add(j);
//            }
//            if (headers[j].startsWith("accbal")) { // Check for 'accbal' columns
//                accbalIndices.add(j);
//            }
//        }
//
//        // Process each data row in the CSV
//        for (int i = 1; i < lines.size(); i++) {
//            String[] data = lines.get(i);
//            Map<String, String> userData = new HashMap<>();
//
//            // Load necessary data into userData
//            userData.put("fromdate", getValueAtIndex(data, 0));
//            userData.put("todate", getValueAtIndex(data, 1));
//
//            for (int index : accheadIndices) {
//                userData.put(headers[index], getValueAtIndex(data, index));
//            }
////
//            // Call checkblnc with the populated userData map
//            subledger.checkblnc(userData);
//
//            // Print and compare final balances for each 'acchead'
//            for (int index : accheadIndices) {
//                String accheadKey = headers[index];
//                String finalBalance = subledger.getBalanceByAccountHead(accheadKey);
//                System.out.println("Final Balance in " + accheadKey + " : " + finalBalance);
//
//                // Calculate the difference
//                String initialBalanceStr = initialBalances.get(accheadKey);
//                if (initialBalanceStr != null) {
//                    double initialBalance = Double.parseDouble(initialBalanceStr);
//                    double finalBalanceValue = Double.parseDouble(finalBalance);
//                    double difference = finalBalanceValue - initialBalance;
//                    System.out.printf("Difference in %s: %.2f%n", accheadKey, difference);
//                }
//            }
//
//            // Print values for each 'accbal' column
//            for (int index : accbalIndices) {
//                String accbalKey = headers[index];
//                String accbalValue = getValueAtIndex(data, index); // Get accbal value from the current row
//                System.out.println("Value in " + accbalKey + " : " + accbalValue);
//            }
//        }
//    }
//}
//
//private String getValueAtIndex(String[] data, int index) {
//    return data.length > index ? data[index] : null;
//}
//}
//    

@Test(dependsOnMethods = "ProductTest")
public void finalblncTest() throws InterruptedException, IOException {
    String csvFilePath = "TestDataSet/SubLedger/accounthead.csv";
    String line;
    List<Integer> accheadIndices = new ArrayList<>();
    List<Integer> accbalIndices = new ArrayList<>(); // To store indices of 'accbal' columns

    try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
        List<String[]> lines = new ArrayList<>();
        while ((line = br.readLine()) != null) {
            lines.add(line.split(","));
        }

        // Identify headers and find indices of 'acchead' and 'accbal' columns
        String[] headers = lines.get(0);
        for (int j = 0; j < headers.length; j++) {
            if (headers[j].startsWith("acchead")) {
                accheadIndices.add(j);
            }
            if (headers[j].startsWith("accbal")) { // Check for 'accbal' columns
                accbalIndices.add(j);
            }
        }

        // Process each data row in the CSV
        for (int i = 1; i < lines.size(); i++) {
            String[] data = lines.get(i);
            Map<String, String> userData = new HashMap<>();

            // Load necessary data into userData
            userData.put("fromdate", getValueAtIndex(data, 0));
            userData.put("todate", getValueAtIndex(data, 1));

            for (int index : accheadIndices) {
                userData.put(headers[index], getValueAtIndex(data, index));
            }

            // Call checkblnc with the populated userData map
            subledger.checkblnc(userData);

            // Initialize variables to hold the differences for acchead1 and acchead2
            Double differenceAcchead1 = null;
            Double differenceAcchead2 = null;

            // Print and compare final balances for each 'acchead'
            for (int index : accheadIndices) {
                String accheadKey = headers[index];
                String finalBalance = subledger.getBalanceByAccountHead(accheadKey);
                System.out.println("Final Balance in " + accheadKey + " : " + finalBalance);

                // Calculate the difference
                String initialBalanceStr = initialBalances.get(accheadKey);
                if (initialBalanceStr != null) {
                    double initialBalance = Double.parseDouble(initialBalanceStr);
                    double finalBalanceValue = Double.parseDouble(finalBalance);
                    double difference = finalBalanceValue - initialBalance;
                    System.out.printf("Difference in %s: %.2f%n", accheadKey, difference);

                    // Store the differences for specific account heads
                    if (accheadKey.equals("acchead1")) {
                        differenceAcchead1 = difference;
                    } else if (accheadKey.equals("acchead2")) {
                        differenceAcchead2 = difference;
                    }
                }
            }

            // Compare differences with corresponding accbal values
            for (int j = 0; j < accbalIndices.size(); j++) {
                String accbalKey = headers[accbalIndices.get(j)];
                String accbalValue = getValueAtIndex(data, accbalIndices.get(j)); // Get accbal value from the current row

                // Compare only accbal1 with differenceAcchead1 and accbal2 with differenceAcchead2
                if (j == 0 && differenceAcchead1 != null) { // For accbal1
                    if (differenceAcchead1.equals(Double.parseDouble(accbalValue))) {
                        System.out.printf("Test Passed for acchead1: Difference %.2f matches Value in %s: %s%n", differenceAcchead1, accbalKey, accbalValue);
                    } else {
                        System.out.printf("Test Failed for acchead1: Difference %.2f does not match Value in %s: %s%n", differenceAcchead1, accbalKey, accbalValue);
                        Assert.fail("Test Failed for acchead1: Difference does not match Value.");
                    }
                } else if (j == 1 && differenceAcchead2 != null) { // For accbal2
                    if (differenceAcchead2.equals(Double.parseDouble(accbalValue))) {
                        System.out.printf("Test Passed for acchead2: Difference %.2f matches Value in %s: %s%n", differenceAcchead2, accbalKey, accbalValue);
                    } else {
                        System.out.printf("Test Failed for acchead2: Difference %.2f does not match Value in %s: %s%n", differenceAcchead2, accbalKey, accbalValue);
                        Assert.fail("Test Failed for acchead2: Difference does not match Value.");
                    }
                }
            }

            // Print values for each 'accbal' column
            for (int index : accbalIndices) {
                String accbalKey = headers[index];
                String accbalValue = getValueAtIndex(data, index); // Get accbal value from the current row
                System.out.println("Value in " + accbalKey + " : " + accbalValue);
            }
        }
    }
}

private String getValueAtIndex(String[] data, int index) {
    return data.length > index ? data[index] : null;
}
}