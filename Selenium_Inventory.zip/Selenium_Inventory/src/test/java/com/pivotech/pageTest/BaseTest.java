package com.pivotech.pageTest;

//import com.pivotech.page.CreateProductPage;
import com.pivotech.AccountPage.Bank;
import com.pivotech.AccountPage.CashManagement;
import com.pivotech.AccountPage.OtherBill;
import com.pivotech.SalesPage.PointofSales;
import com.pivotech.ProductPage.AddProduct;
import com.pivotech.page.AheadPage;
import com.pivotech.page.CreateProductpage;
import com.pivotech.SalesPage.CreditNote;
import com.pivotech.SalesPage.Customer;
import com.pivotech.PurchasePage.DebitNote;
import com.pivotech.SalesPage.DeliveryNote;
import com.pivotech.PurchasePage.GoodReceived;
import com.pivotech.page.LoginPage;
import com.pivotech.page.ProductDetails;
import com.pivotech.PurchasePage.PurchaseBill;
import com.pivotech.PurchasePage.PurchaseOrder;
import com.pivotech.SalesPage.SalesOrder;
import com.pivotech.page.SubLedger;
import com.pivotech.PurchasePage.Supplier;
import com.pivotech.page.UserPage;
import com.pivotech.page.VoucherPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

/**
 *
 * @author samyog
 */
public class BaseTest {
    protected static WebDriver driver;
    public LoginPage loginpage;
    public UserPage userpage;
    public CreateProductpage createproduct;
    public AddProduct addproduct; 
   
    public Supplier supplier;
    public PurchaseOrder purchaseorder;
    public GoodReceived Grn;
    public PurchaseBill Bill;
    public DebitNote debitnote;
    
    public Customer customer;
    public SalesOrder salesorder;
    public PointofSales pos;
    public DeliveryNote deliverynote;
    public CreditNote creditnote;
    
    public Bank bank;
    public CashManagement cashmanagement;
    public OtherBill otherbill;
     
    public ProductDetails productdet;
    public VoucherPage voucherpg;
    public AheadPage aheadpg;
    public SubLedger subledger;
   // public CreateProductPage createproductpage;
    
    public WebDriver getDriver(){
        return driver;
    }
    
    @BeforeSuite
    public void setupProxy(){
        
    }
    
    @BeforeClass
    public static void setUp(){
        ResourceBundle bundle= ResourceBundle.getBundle("bundle");
        ChromeOptions options= new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        
        options.setAcceptInsecureCerts(true);
        
        String Headless = bundle.getString("Headless");
        if (Headless.equals("FALSE")) {
            options.addArguments("--remote-allow-origins=*");
        } else if (Headless.equals("TRUE")){
        options.addArguments("--headless=new");
    }
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
    }
    
    @After
    public void cleanUp(){
        driver.manage().deleteAllCookies();
        
    }
    
    @BeforeMethod
    public void methodLevelSetup() {
        loginpage = new LoginPage(driver);
        userpage=new UserPage(driver);
         createproduct=new CreateProductpage(driver);
           addproduct = new AddProduct(driver); 

           supplier = new Supplier(driver);
           purchaseorder = new PurchaseOrder(driver);
           Grn =new GoodReceived(driver);
           Bill = new PurchaseBill(driver);
           debitnote = new DebitNote(driver);
           
           customer =new Customer(driver);
           salesorder =new SalesOrder(driver);
           pos = new PointofSales(driver);
           deliverynote = new DeliveryNote(driver);
           creditnote = new CreditNote(driver);
           
           bank = new Bank(driver);
           cashmanagement = new CashManagement(driver);
           otherbill = new OtherBill(driver);
           
           productdet = new ProductDetails(driver);
           voucherpg = new VoucherPage(driver);
           aheadpg = new AheadPage(driver);
           subledger = new SubLedger(driver);
    }
    
    @AfterClass
    public void teardown()  {
        if (driver != null) {
        driver.quit();
    }
                   

    }
    
       public void navigateToSalesInvoice() {
        String originalWindow = driver.getWindowHandle(); // Store the original window handle

        // Check if the current URL is the 'blob' URL
        String currentUrl = driver.getCurrentUrl();
        if (currentUrl.contains("blob:")) {
            System.out.println("Detected blob URL, skipping and redirecting to Sales Invoice page...");
            // Navigate to the Sales Invoice page
            
            waitForPageToLoad();

            // Close any additional tabs/windows that might have been opened
            for (String windowHandle : driver.getWindowHandles()) {
                if (!windowHandle.equals(originalWindow)) {
                    driver.switchTo().window(windowHandle).close(); // Close the other window
                }
            }
            driver.switchTo().window(originalWindow); // Switch back to the original window
        } else {
            System.out.println("Proceeding with current flow...");
        }
    }
     
    
    public void waitForPageToLoad() {
        new WebDriverWait(driver, 10).until(webDriver ->
                ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }
    
    
    
    
    
    
    public static void openUrl(String url) {
        String baseName = "bundle";
        ResourceBundle exampleBundle = ResourceBundle.getBundle(baseName);
        String targetHost = exampleBundle.getString("targetHost");
        String targetPort = exampleBundle.getString("targetPort");
        String app = exampleBundle.getString("app");
        String protocal = exampleBundle.getString("protocal");
        String baseUrl = protocal + "://" + targetHost + targetPort + "/" + app;

        driver.get(baseUrl + url);
    }
}

