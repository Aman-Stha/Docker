package com.pivotech.pageTest;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.pivotech.utils.extentreports.ExtentManager;
import com.pivotech.utils.extentreports.ExtentTestManager;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 *
 * @author samyog
 */
public class ResetPassTest extends BaseTest{
    private ExtentTest extentTest;
    @BeforeClass
    public void beforeClass(){
        ExtentManager.createExtentReports();
    }
    
    @AfterClass
    public void afterClass(){
        ExtentManager.extentReports.flush();
    }
    
    @Test(priority = 0, testName = "Reset Password Test Start", description = "Lets reset password")
    public void Resetpass (Method method) throws InterruptedException, IOException {
        openUrl("/Login");
        
        //Read csv file
        List<String[]> csvData = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("TestDataSet/ResetPassword/ResetPass.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");
                csvData.add(userData);
                System.out.println("Read from CSV: " + userData[1] + ", " + userData[2] + ", " + userData[3] + ", " + userData[4]);
            }
        } catch (Exception e) {
            // Handle exception
        }
        
        // Start the Loop
        for(int i=1; i< csvData.size(); i++){
            String[] userData = csvData.get(i);
            
            String username = userData[1];
            String dob = userData[2];
            String newpass = userData[3];
            String confirmpass = userData[4];
            String expected_result1 = userData[10];
            String caseid = userData[0];
            String testcase = userData[6];
            String expected_result2 = userData[7];
            String expected_result3 = userData[9];
            
            ExtentTest extentTest = ExtentTestManager.startTest(method.getName(), testcase, caseid);
            
            try {
                loginpage.ResetPassword(username, newpass, confirmpass, dob)
                        .Resetmsgcheck(expected_result1,expected_result2,expected_result3)
                        .Clearinputs();
                extentTest.log(Status.PASS, "Test Passed");
            }catch (AssertionError e) {
                // Test Assertion Failed
                extentTest.log(Status.FAIL, "Test Failed: " + e.getMessage());
            } catch (Exception e) {
                // Other exceptions
                extentTest.log(Status.FAIL, "Test Failed due to Exception: " + e.getMessage());
            }
            
            
            
            
        }
    }
    
}
