/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.pageTest;

import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class AfterLoginTest extends BaseTest {
  
    @Test
    public void letstest (Method method) throws InterruptedException, IOException {
        openUrl("/Login");
        
        // Read csv file
        List<String[]> csvData = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("TestDataSet/Login/onlylogin.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");
                csvData.add(userData);
                System.out.println("Read from CSV: " + userData[0] + ", " + userData[1]);
            }
        } catch (Exception e) {
            // Handle exception
        }
        
        // Start the Loop
        for (int i = 1; i < csvData.size(); i++) {
            String[] userData = csvData.get(i);

            String username = userData[0];
            String password = userData[1];
            
            
                loginpage.OnlyLogin(username, password);
               Thread.sleep(3000);  
             
        }
        
        
        
    }
}

