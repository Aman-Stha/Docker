/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.pageTest;

import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.Assert; // Make sure this is from TestNG
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */

public class StockCheckGrn extends BaseTest {
    
private String stockBeforeGrn; // Store stock value before GRN
    private String grnQuantity; // Store GRN quantity
    
    @Test
    public void Login() throws InterruptedException, IOException {
        openUrl("/Login");
        loginpage.OnlyLogin("asus", "sigma@123");
    }
    
    @Test(dependsOnMethods = "Login")
    public void stockvalue() throws InterruptedException, IOException {
        // Get stock value before adding GRN
        stockBeforeGrn = productdet.stock("Baggy Pants");
        
    }
    
    
      @Test(dependsOnMethods = "stockvalue")
  public void ProductTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Add_product/addproduct.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                addproduct.namedetails(userData).pricedetails(userData).adddetails(userData);

               
            }
            
        }
        
    }
//    
//    
    @Test(dependsOnMethods = "ProductTest")
    public void GRNTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/grn.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                
                // Call addGrn and store the returned quantity
                grnQuantity = Grn.addGrn(userData);
            }
        }
    }

    @Test(dependsOnMethods = "GRNTest")
    public void validateStockAfterGrn() throws InterruptedException {
        // Get the stock value after adding GRN
        String stockAfterGrn = productdet.stock("Baggy Pants");
        
        // Remove any non-numeric characters and convert to double
        double actualStockAfterGrn = Double.parseDouble(stockAfterGrn.replaceAll("[^0-9.]", ""));

        // Calculate expected stock value after GRN
        double expectedStockValue = Double.parseDouble(stockBeforeGrn.replaceAll("[^0-9.]", "")) + 
                                    Double.parseDouble(grnQuantity.replaceAll("[^0-9.]", ""));
        System.out.println("Actual stock value after GRN: " + actualStockAfterGrn);
    System.out.println("Expected stock value after GRN: " + expectedStockValue);
    
        // Compare with actual stock value after GRN
        Assert.assertEquals(actualStockAfterGrn, expectedStockValue, 
            "The stock value after GRN does not match the expected value.");
    }
    
    private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
}
