package com.pivotech.pageTest;

import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class FullPurchasefield extends BaseTest{
 
    @Test
    public void Login () throws InterruptedException, IOException {
        openUrl("/Login");
   
               loginpage.OnlyLogin("asus","sigma@123");
    }
    
    @Test(dependsOnMethods = "Login")
    public void ProductTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Add_product/addproduct.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                addproduct.namedetails(userData).pricedetails(userData).adddetails(userData);

               
            }
            
        }
        
    }

    
    @Test(dependsOnMethods = "ProductTest")
    public void SupplierTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/supplier.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
//      
                supplier.pgSupplier(userData).addSupplier(userData);

               
            }
        }
    }

    
     @Test(dependsOnMethods = "SupplierTest")
    public void PurchaseorderTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/pOrder.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
     
                purchaseorder.addPurchase(userData);

               
            }
        }
    }
    
    
    @Test(dependsOnMethods = "PurchaseorderTest")
    public void GRNTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/grn.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
     
                Grn.addGrn (userData);

               
            }
        }
    }
  
       @Test(dependsOnMethods = "GRNTest")
    public void BillTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/pbill.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
     
                Bill.addbill(userData);

               
            }
        }
    }
    
    @Test(dependsOnMethods = "BillTest")
    public void ReturnTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/debitnote.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
     
                debitnote.addDebit(userData);

               
            }
        }
    }
    
 private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
    
    
}
    
