/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.pageTest;

import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class AheadTest extends BaseTest{
        private double actualEquity;
        private double actualCategory;
        private double iopening;
        private double icategory;
        private double fopening;
        private double fcategory;
        private double expected_eqty;
        private double expected_cat;

        
        private DecimalFormat df = new DecimalFormat("#.00");

    @Test
    public void Login() throws InterruptedException, IOException {
        openUrl("/Login");
        loginpage.OnlyLogin("asus", "sigma@123");
    }
    
    
    @Test(dependsOnMethods = "Login")
   
    public void initialblncTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/SubLedger/accounthead.csv";
        String line = "";
         int accheadCount = 0;  // Variable to store the count of 'acchead' columns

    try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
        List<String[]> lines = new ArrayList<>();
        while ((line = br.readLine()) != null) {
            lines.add(line.split(","));
        }
        
        // Get the headers and count columns starting with 'acchead'
        String[] headers = lines.get(0);
        for (String header : headers) {
            if (header.startsWith("acchead")) {
                accheadCount++;
            }
        }
        
        System.out.println("Maximum count of 'acchead' columns: " + accheadCount);

        for (int i = 1; i < lines.size(); i++) {
            String[] data = lines.get(i);
            Map<String, String> userData = new HashMap<>();
            for (int j = 0; j < headers.length; j++) {
                userData.put(headers[j], getValueAtIndex(data, j));
            }
            
            
            
            //same 
                aheadpg.checkblnc(userData);
                
             String initial_openingEquity = aheadpg.getOpeningEquity();
             String initial_categoryAssetHead = aheadpg.getCategoryAssetHead();
             
          iopening = Double.parseDouble(initial_openingEquity);
          icategory = Double.parseDouble(initial_categoryAssetHead);
             

        
        System.out.println("Initial Opening Equity: " + df.format(iopening));
        System.out.println("Initial Category Asset Head: " + df.format(icategory));

               
            }
            
        }
        
    }
    
    
    
     @Test(dependsOnMethods = "initialblncTest")
    public void ProductTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Add_product/addproduct.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
              
                addproduct.namedetails(userData)
                          .pricedetails(userData)
                          .adddetails(userData);
            }
        }
    }
    
    
       @Test(dependsOnMethods = "ProductTest")
   
    public void finalblncTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/SubLedger/accounthead.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                aheadpg.checkblnc(userData);
                    String Expected_equity = userData.get("Expected_eqty");
                    expected_eqty = Double.parseDouble(Expected_equity);
                    String Expected_cat = userData.get("Expected_cat");
                    expected_cat = Double.parseDouble(Expected_cat);
           // System.out.println("result: " +expected_res);

                String final_openingEquity = aheadpg.getOpeningEquity();
             String final_categoryAssetHead = aheadpg.getCategoryAssetHead();
             
             
             fopening = Double.parseDouble(final_openingEquity);
             fcategory = Double.parseDouble(final_categoryAssetHead);
             actualEquity = fopening-iopening;
             actualCategory = fcategory - icategory ;
        
        System.out.println("Final Opening Equity: " +df.format (fopening));
        System.out.println("Final Category Asset Head: " + df.format(fcategory));

               
            }
            
            
            
        }
        
    }
      @Test(dependsOnMethods = "finalblncTest")
    
    public void validatebalnc() throws InterruptedException, IOException {
        if(expected_eqty == actualEquity || expected_cat == actualCategory){
                    System.out.println("Pass" );

        }
        else{
        System.out.println("Fail" );

        }
        
    }
    
    
     private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
}
