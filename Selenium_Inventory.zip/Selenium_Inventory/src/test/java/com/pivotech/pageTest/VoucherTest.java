/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.pageTest;

import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class VoucherTest extends BaseTest {
    
    
          private static final String CSV_FILE_PATH = "TestDataSet/Add_product/addproduct.csv";

    @Test
    public void Login() throws InterruptedException, IOException {
        openUrl("/Login");
        loginpage.OnlyLogin("asus", "sigma@123");
    }
    
    @Test(dependsOnMethods = "Login")
    public void ProductTest() throws InterruptedException, IOException {
    Map<String, String> userData = readFromCSV(CSV_FILE_PATH);
        if (userData != null) {
            addproduct.namedetails(userData)
                      .pricedetails(userData)
                      .adddetails(userData);
        }
    }

    
    @Test(dependsOnMethods = "ProductTest")
    public void checkvoucher() throws InterruptedException, IOException {
    voucherpg.stockvoucher();
    Map<String, String> productData = readFromCSV(CSV_FILE_PATH);
    String pname = productData.get("pname"); // Assuming "ProductName" is a CSV header
    String pcode = productData.get("pcode");
    String openingQ = productData.get("openingQ");
    String openingR = productData.get("openingR");
 
// Converting String to int or double for numeric calculations
int openingQInt = Integer.parseInt(openingQ);
int openingRInt = Integer.parseInt(openingR);

// Perform multiplication
int totalAmount = openingQInt * openingRInt;

// Print the detailed output
System.out.println("Total amt for accounthead: " + openingQInt + " * " + openingRInt + " = " + totalAmount);

  



    String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    String expectedMessage = "Being product opening stock added on date: " + today + " for product: " + pname + " [" + pcode + "]";
                             

    // Retrieve the actual message from VoucherPage
    String actualMessage = voucherpg.getStockValue();

    // Normalize both messages by removing extra spaces
    String normalizedExpected = expectedMessage.replaceAll("\\s+", " ").trim();
    String normalizedActual = actualMessage.replaceAll("\\s+", " ").trim();

    // Compare the message and print result
    if (normalizedActual.equals(normalizedExpected)) {
        System.out.println("Message is correct: " + actualMessage);
        voucherpg.ratecheck();
        
     String openingEquity = voucherpg.getOpeningEquity();
        String categoryAssetHead = voucherpg.getCategoryAssetHead();

        // Debugging output to check retrieved values
        System.out.println("Opening Equity: " + openingEquity);
        System.out.println("Category Asset Head: " + categoryAssetHead);

        // Check if openingEquity or categoryAssetHead is null or empty before parsing
        if (openingEquity != null && !openingEquity.isEmpty()) {
            int openingEquityInt = Integer.parseInt(openingEquity);
            if (openingEquityInt == totalAmount) {
                System.out.println("Opening equity matches account_head balance: " + openingEquityInt);
            } else {
                System.out.println("Opening equity does not match total amount. Expected: " + totalAmount + ", Found: " + openingEquityInt);
            }
        } else {
            System.out.println("Opening Equity is null or empty.");
        }

        if (categoryAssetHead != null && !categoryAssetHead.isEmpty()) {
            int categoryAssetHeadInt = Integer.parseInt(categoryAssetHead);
            if (categoryAssetHeadInt == totalAmount) {
                System.out.println("Category Asset Head matches account_head balance: " + categoryAssetHeadInt);
            } else {
                System.out.println("Category Asset Head does not match total amount. Expected: " + totalAmount + ", Found: " + categoryAssetHeadInt);
            }
        } else {
            System.out.println("Category Asset Head is null or empty.");
        }

    }
  
        
     else {
        System.out.println("Message is incorrect. Expected: " + expectedMessage + " but found: " + actualMessage);
    }
}
        
//        String expectedMessage = "Being product opening stock added on date: " + today + " for product:"+ pname +"["+pcode+"]";;
//       String actualMessage = voucherpg.getStockValue();
//         if (actualMessage.equals(expectedMessage)) {
//            System.out.println("Message is correct: " + actualMessage);
//        } else {
//            System.out.println("Message is incorrect. Expected: " + expectedMessage + " but found: " + actualMessage);
//        }

      
    
    private Map<String, String> readFromCSV(String filePath) {
    Map<String, String> data = new HashMap<>();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line = br.readLine(); // Read header
        String[] headers = line.split(",");

        // Read the first line of data (assuming single row for this example)
    if ((line = br.readLine()) != null) {
        String[] values = line.split(",");
    for (int i = 0; i < headers.length; i++) {
        data.put(headers[i].trim(), getValueAtIndex(values, i));
            }
        }
        } catch (IOException e) {
        }
        return data;
    }
     private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
}
        
    
   

