/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.AccountTest;

import com.pivotech.pageTest.BaseTest;
import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class OtherbillTest extends BaseTest{
 
    @Test
    public void Login () throws InterruptedException, IOException {
        openUrl("/Login");
   
               loginpage.OnlyLogin("asus","sigma@123");
    }
    
    @Test(dependsOnMethods = "Login")
    public void OtherbillTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Account/otherbill.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                otherbill.addbill(userData);

               
            }
            
        }
        
    }

    
     private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
    
}

