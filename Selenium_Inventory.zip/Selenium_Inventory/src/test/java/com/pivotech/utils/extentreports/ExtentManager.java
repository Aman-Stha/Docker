package com.pivotech.utils.extentreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentManager {

    public static final ExtentReports extentReports = new ExtentReports();

    public synchronized static ExtentReports createExtentReports() {
        // Get the current timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        // Create the ExtentSparkReporter with a timestamp in the filename
        ExtentSparkReporter reporter = new ExtentSparkReporter("./extent-reports/extent-report-" + timestamp + ".html");
        reporter.config().setReportName("HRM Report");

        // Attach the reporter to the ExtentReports
        extentReports.attachReporter(reporter);

        // You can set custom system info if needed
        // extentReports.setSystemInfo("Tester", "Laxmi Menyangbo");
        return extentReports;
    }
}
