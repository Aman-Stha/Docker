package com.pivotech.utils.extentreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import java.util.HashMap;
import java.util.Map;

/**
 * extentTestMap holds the information of thread ids and ExtentTest instances.
 * ExtentReports instance created by calling createExtentReports() method from
 * ExtentManager. At startTest() method, an instance of ExtentTest created and
 * put into extentTestMap with the given case id. At getTest() method, return
 * ExtentTest instance in extentTestMap by using the given case id.
 */
public class ExtentTestManager {

    static Map<String, ExtentTest> extentTestMap = new HashMap<>();
    static ExtentReports extent = ExtentManager.createExtentReports();
    static String testCaseId;

    public static synchronized ExtentTest getTest() {
        return extentTestMap.get(testCaseId);
    }

    public static synchronized ExtentTest startTest(String testName, String desc, String caseId) {
        ExtentTest test = extent.createTest(testName, desc);
        // test.assignCategory("loan");
        //  test.assignAuthor("AAA");
        testCaseId = caseId;
        test.info("Case ID: " + caseId);
        extentTestMap.put(caseId, test);

        return test;
    }
}
