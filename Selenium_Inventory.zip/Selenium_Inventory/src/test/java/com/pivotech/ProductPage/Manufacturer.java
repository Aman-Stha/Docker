/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.ProductPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class Manufacturer extends PageObject {
    
    public Manufacturer(WebDriver driver) {
        super(driver);
    }
        
    By clickProduct = By.xpath("//a[@id='pnl_Product']");
    By manufacturer = By.xpath("//span[normalize-space()='Manufacture']");
    By add = By.xpath("//button[@aria-label='Add']");
    By name = By.xpath("//input[@class='p-inputtext p-component w-full']");
    By save = By.xpath("//button[@aria-label='Save']");
        
    public Manufacturer addmanu(Map<String, String> userData) throws InterruptedException {
    click(clickProduct);
    click(manufacturer);
    click(add);
    writeText(name, userData.get("name"));      
    click(save);
           Thread.sleep(1000);

    return this;
    }
    
}
