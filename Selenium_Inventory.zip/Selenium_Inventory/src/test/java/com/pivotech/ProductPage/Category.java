/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.ProductPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class Category extends PageObject {
    
    public Category(WebDriver driver) {
        super(driver);
    }
        
    By clickProduct = By.xpath("//a[@id='pnl_Product']");
    By category = By.xpath("//span[normalize-space()='Category']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By name = By.xpath("//input[@aria-describedby='nameHelp']");
    By code = By.xpath("//input[@aria-describedby='codeHelp']");
    By description = By.xpath("//input[@aria-describedby='descriptionHelp']");
    By stockout = By.xpath("//span[@aria-label='Select stock out method.']");
    By stockrate = By.xpath("//span[@aria-label='Select stock out rate method.']");
    By pcategory = By.xpath("//span[@aria-label='Select parent category.']");
    By search = By.xpath("//input[@role='searchbox']");
    By save = By.xpath("//button[@aria-label='Save Category']");
        
    public Category addcategory(Map<String, String> userData) throws InterruptedException {
    click(clickProduct);
    click(category);
    click(add);
    writeText(name, userData.get("name"));
    writeText(code, userData.get("code"));
    writeText(description, userData.get("description"));
    selectDropdownOptionByAriaLabel(stockout, userData.get("stockout"));
    selectDropdownOptionByAriaLabel(stockrate, userData.get("stockrate"));
    click(pcategory);
    selectFromDropdown(search, userData.get("search"));       
    click(save);
           Thread.sleep(1000);

    return this;
    }
    
}
