/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.ProductPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class Attribute extends PageObject {
    
    public Attribute(WebDriver driver) {
        super(driver);
    }

    By clickProduct = By.xpath("//a[@id='pnl_Product']");
    By attribute = By.xpath("//a[@id='subpnl_Attribute']");
    By add = By.xpath("//button[@aria-label='Add']");
    By name = By.xpath("//input[@aria-describedby='nameHelp']");
    By code = By.xpath("//input[@aria-describedby='codeHelp']");
    By save = By.xpath("//button[@aria-label='Save']");

    By attributeop = By.xpath("//span[normalize-space()='Attribute Option']");
    By sltattribute = By.xpath("//input[@placeholder='Select attribute']");
        
    public Attribute addattribute(Map<String, String> userData) throws InterruptedException {
    click(clickProduct);
    click(attribute);
    click(add);
    writeText(name, userData.get("name"));  
    writeText(code, userData.get("code"));      
    click(save);
    Thread.sleep(1000);
    return this;
    }
    
    public Attribute attoption(Map<String, String> userData) throws InterruptedException {
    click(attributeop);
    click(add);
    writeText(name, userData.get("name"));  
    selectFromDropdown(sltattribute, userData.get("sltattribute")); 
    writeText(code, userData.get("code"));     
    click(save);
    Thread.sleep(1000);
    return this;
    }
}
