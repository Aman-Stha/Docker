///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.pivotech.ProductPage;
//
//import com.pivotech.helper.PageObject;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//
///**
// *
// * @author amrita
// */
//public class UnitGroup extends PageObject {
//    
//    public UnitGroup(WebDriver driver) {
//    super(driver);
//    }
//    
//        By clickProduct = By.xpath("//a[@id='pnl_Product']");
//        By addetails = By.xpath("//a[@id='pnl_Additional_Details']");
//        By unitgrp = By.xpath("//span[normalize-space()='Unit Group']");
//        By add = By.xpath("//button[@aria-label='Add']");
//        By gname = By.xpath("//input[@class='p-inputtext p-component mr-1 w-full']");
//        By unitbtn = By.xpath("//button[@id='pv_id_91_accordionheader_0']");
//        
//        
//        
//        
//        
//}
