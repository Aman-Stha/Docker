/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.helper;

/**
 *
 * @author samyog
 */
public class ErrorMessageException extends Exception{
    public ErrorMessageException() {
    }

    public ErrorMessageException(String message) {
        super(message);
    }
    
}
