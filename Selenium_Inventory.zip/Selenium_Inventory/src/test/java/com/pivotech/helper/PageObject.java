package com.pivotech.helper;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author samyog
 */
public class PageObject {
    public WebDriver driver;
    public WebDriverWait wait;
    public FluentWait fluentWait;
    
    //Constructor
    public PageObject(WebDriver driver){
        this.driver= driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10).getSeconds());
        fluentWait = new FluentWait(driver).withTimeout(10, TimeUnit.SECONDS)
                .pollingEvery(Duration.ofSeconds(1l)).ignoring(NoSuchElementException.class);
        
    }
    
    // Click Method
    public void click(By by){
        waitVisibility(by).click();
    }
    
     //Wait
    public WebElement waitVisibility(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }
    
    //Write Text
    public void writeText(By by, String text) {
        waitVisibility(by).sendKeys(text == null || text.isEmpty() ? new StringBuilder("") : text);
    }

    //Read Text
    public String readText(By by) {
        return waitVisibility(by).getText();
    }
    
    public WebElement waitPresence(By by) {
        //  return wait.until(ExpectedConditions.presenceOfElementLocated(by));
        WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver driver) {
                return driver.findElement(by);
            }
        });
        return foo;

    }
    
    public void selectDropdownOptionByAriaLabel(By dropdownLocator, String optionLabel) {
    click(dropdownLocator);
    WebDriverWait wait = new WebDriverWait(driver, 5);
    for (int attempt = 0; attempt < 3; attempt++) {
     try {
         
        WebElement option = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@aria-label='" + optionLabel + "']")));
        option.click();
            break;
        } catch (StaleElementReferenceException e) {
            System.out.println("StaleElementReferenceException occurred, retrying...");
        }
    }
   }   
    

   public void selectFromDropdown(By dropdownLocator, String value) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        dropdown.sendKeys(value);
        Thread.sleep(2000);
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
   }
    
   
     public void selectFromDropdownn(By dropdownLocator) throws InterruptedException {
        WebElement dropdown = driver.findElement(dropdownLocator);
        dropdown.click();
        //dropdown.sendKeys(value);
        Thread.sleep(2000);
        
        List<WebElement> options = driver.findElements(By.xpath("//li[@role=\"option\"]"));
        if (!options.isEmpty()) {
            options.get(0).click();
        }else {
            System.out.println("No options found in the dropdown.");
        }
    }
    public WebElement waitElementToBeClickable(By by) {
        return wait.until(ExpectedConditions.elementToBeClickable(by));
    }

    public void writeDate(By by, String date) {
        SimpleDateFormat localDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        waitVisibility(by).sendKeys(localDateFormat.format(date).toString());
    }

    public void waitForElementPresence(By by, int timeoutInSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
    }
    public void clearText(By element) {
        driver.findElement(element).clear();
    }  
    
}
