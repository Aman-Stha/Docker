/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.SalesPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class DeliveryNote extends PageObject
{
    
    public DeliveryNote(WebDriver driver) {
        super(driver);
    }
    
  //  By ret = By.xpath("//button[@title='Return']");
   // By yes =By.xpath("//span[normalize-space()='Yes']");
    By sales = By.xpath("//a[@id='pnl_Sales']");
    
    By delivery = By.xpath("//span[normalize-space()='Delivery Note']");
    By add = By.xpath("//span[normalize-space()='Add']");
    By vehicle = By.xpath("//input[@id='vehicleInfo']");
    By customer = By.xpath("//input[@placeholder='Select Customer']");
    By shipTo = By.xpath("//input[@id='shipTo']");  
    By product = By.xpath("//input[@id='dt_product']");
    By confirm = By.xpath("//button[@title='Confirm Delivery Note']");
    By save = By.xpath("//button[@aria-label='Save']");
  
    By view = By.xpath("(//span[@data-pc-section='icon'])[10]");
    By salesInvoice = By.xpath("//button[@aria-label='Convert To Sales Invoice']");
    By confirmBtn = By.xpath("//span[normalize-space()='Confirm Sale']");
    By saveBtn = By.xpath("//span[normalize-space()='Save']");

    
    
    public DeliveryNote addDeliveryNote (Map <String, String> userData) throws InterruptedException{
       Thread.sleep(2000);
       
       // click(ret);
       // Thread.sleep(1000);
      // click(yes);
        click(sales);
        click(delivery);
        click(add);
        writeText(vehicle, userData.get("vehicle"));
        selectFromDropdown(customer, userData.get("customer"));
        writeText(shipTo, userData.get("shipTo"));
        selectFromDropdown(product, userData.get("product"));
        Thread.sleep(1000);
        click(confirm);
        click(save);
        Thread.sleep(2000);
        click(view);
        click(salesInvoice);
        click(confirmBtn);
        click(saveBtn);
        return this;
    }
    
}

