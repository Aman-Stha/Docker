/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.SalesPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class Customer extends PageObject{
    By sales = By.xpath("//a[@id='pnl_Sales']");
    By customer = By.xpath("//a[@id='subpnl_Customer']");
    
    By add = By.xpath("//button[@aria-label='Add']");
    By name = By.xpath("//input[@placeholder='Enter Name']");
    By address = By.xpath("//input[@placeholder='Enter Address']");
    By email = By.xpath("//input[@placeholder='Enter Email']");
    By phone = By.xpath("//input[@placeholder='Enter Phone Number']");
    By pan = By.xpath("//input[@placeholder='Enter Pan Number']");
    By creamount = By.xpath("//*[@id=\"inp_credit_amount\"]/input");
    By crelimit = By.xpath("//*[@id=\"inp_credit_limit\"]/input");
    By category = By.xpath("//input[@placeholder='Select Customer Category']");
    By tou = By.xpath("//div[@class='p-dialog-header']");
    By tradetype= By.xpath("//input[@id='product']");
    By save = By.xpath("//button[@aria-label='Save Customer']");
    
    By search = By.xpath("//input[@id='inp_name_search']");
    By slctcustomer = By.xpath("(//td[@role='cell'])[4]");
    By payment = By.xpath("//button[@aria-label='Payments']");
    By recvamt = By.xpath("//input[@placeholder='Enter Received Amount']");
    By paymode = By.xpath("//div[@id='inp_payment_mode']//div[@class='p-select-dropdown']");
    By remarks = By.xpath("//input[@id='inp_remarks']");
    By receivebtn = By.xpath("//button[@id='btn_paid_receive_amount']");
    
    By paid = By.xpath("//span[@class='p-togglebutton-label'][normalize-space()='Paid Amount']");
    By paidamt = By.xpath("//input[@placeholder='Enter Paid Amount']");
    By paidbtn = By.xpath("//button[@id='btn_paid_receive_amount']");
    
    public Customer(WebDriver driver) {
        super(driver);
    }
    
    public Customer pgCustomer (Map<String, String> userData) throws InterruptedException {  
        click(sales);
        click(customer);
        return this;
    }
        
    public Customer addCustomer (Map<String, String> userData) throws InterruptedException {  
        Thread.sleep(1000);
        click(add);
        writeText(name, userData.get("name"));
        writeText(address, userData.get("address"));
         writeText(email, userData.get("email"));
        writeText(phone, userData.get("phone"));
        writeText(pan, userData.get("pan"));
        click(tou);
        clearInputFields();
        writeText(creamount,userData.get("creamount"));
        writeText(crelimit, userData.get("crelimit"));
        selectFromDropdownn(category);
        selectFromDropdownn(tradetype);
        click(save);
        return this;
    } 
    
    public Customer receiveCustomer (Map<String, String> userData) throws InterruptedException {
    
        writeText(search, userData.get("search"));
        driver.findElement(search).sendKeys(Keys.ENTER);  // Correct
        Thread.sleep(1000);
        click(slctcustomer);
        click(payment);
        writeText(recvamt, userData.get("recvamt"));
        selectDropdownOptionByAriaLabel(paymode, userData.get("paymode"));
        writeText(remarks, userData.get("remarks"));
        Thread.sleep(1000);
        click(receivebtn);
        Thread.sleep(10000);
        return this;
    }
    
    public Customer payCustomer (Map<String, String> userData) throws InterruptedException {
//        writeText(search, userData.get("search"));
//        driver.findElement(search).sendKeys(Keys.ENTER);  // Correct
//        Thread.sleep(1000);
        click(slctcustomer);
        click(payment);
        click(paid);
        writeText(paidamt, userData.get("paidamt"));
        selectDropdownOptionByAriaLabel(paymode, userData.get("paymode"));
        writeText(remarks, userData.get("remarks"));
        Thread.sleep(1000);
        click(paidbtn);
        Thread.sleep(10000);
        return this;
    }
    
    
    
      public Customer clearInputFields() {
        clearText(creamount);
        clearText(crelimit);
        return this;
    }

   
}
