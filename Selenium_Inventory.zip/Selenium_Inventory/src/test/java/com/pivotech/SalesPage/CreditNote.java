/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.SalesPage;

import com.pivotech.helper.PageObject;
import static com.pivotech.pageTest.BaseTest.openUrl;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class CreditNote extends PageObject {
 // By menu = By.xpath("//span[@class='p-button-icon pi pi-bars']");
    By sales = By.xpath("//a[@id='pnl_Sales']");
    By credit = By.xpath("//span[normalize-space()='Credit Note | Sales Return']");
    By add = By.xpath("//button[@aria-label='Add']");
    By withref = By.xpath("//span[contains(text(),'With Sales Reference Number')]");
    By customer = By.xpath("//input[@placeholder='Select Customer']");
    By refno = By.xpath("//input[@id='salesReferenceNo']");
    By product = By.xpath("//input[@id='dt_product']");
    By invoince = By.xpath("//input[@placeholder='Select Sales invoice']");
    By confirm = By.xpath("//button[@title='Confirm Credit Note']");
    By remarks = By.xpath("//input[@placeholder='Enter Remarks']");
    By save = By.xpath("//button[@aria-label='Save']");

    public CreditNote(WebDriver driver) {
        super(driver);
    }



public CreditNote addcreditNote(Map<String, String> userData) throws InterruptedException{
        openUrl("/sale/creditNote");
        click(sales);
        click(credit);
        click(add);
        selectFromDropdown(customer, userData.get("customer"));
        selectFromDropdownn(invoince);
        Thread.sleep(1000);
        click(confirm);
        Thread.sleep(1000);
         writeText(remarks, userData.get("remarks"));
        click(save);
        return this;
    }
  
public CreditNote directcreditNote(Map<String, String> userData) throws InterruptedException{
        openUrl("/sale/creditNote");
        click(sales);
        click(credit);
        click(add);
        click(withref);
        selectFromDropdown(customer, userData.get("customer"));
        writeText(refno, userData.get("refno"));
        selectFromDropdown(product, userData.get("product"));
        click(confirm);
        Thread.sleep(1000);
        writeText(remarks, userData.get("remarks"));
        click(save);
        return this;
    }
}
