/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.SalesPage;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class SalesOrder extends PageObject{
    By sales = By.xpath("//a[@id='pnl_Sales']");
    By salesorder = By.xpath("//a[@id='subpnl_Sales_Order']");
    By add = By.xpath("//button[@aria-label='Add']");
    By customer = By.xpath("//input[@placeholder='Select Customer']");
    By shipTo = By.xpath("//input[@id='shipTo']");  
    By product = By.xpath("//input[@id='dt_product']");
    By confirm = By.xpath("//button[@title='Confirm Purchase']");
    By save = By.xpath("//button[@aria-label='Save']");
    //For sales invoice
    By view = By.xpath("(//button[@type='button'])[17]");
    By salesInvoice = By.xpath("//button[@aria-label='Convert To Sales Invoice']");
    By confirmBtn = By.xpath("//span[normalize-space()='Confirm Sale']");
    By saveBtn = By.xpath("//span[normalize-space()='Save']");

    public SalesOrder(WebDriver driver) {
        super(driver);
    }
    
    public SalesOrder addsalesOrder (Map<String, String> userData) throws InterruptedException{
        click(sales);
        click(salesorder);
        click(add);
        writeText(shipTo, userData.get("ship"));
        Thread.sleep(1000);
        selectFromDropdown(customer, userData.get("customer"));
        Thread.sleep(1000);
        selectFromDropdown(product, userData.get("product"));
        Thread.sleep(1000);
        click(confirm);
        Thread.sleep(1000);

        click(save);
        Thread.sleep(2000);
        click(view);
        click(salesInvoice);
        click(confirmBtn);
        click(saveBtn);
        return this;
    }
    
}
