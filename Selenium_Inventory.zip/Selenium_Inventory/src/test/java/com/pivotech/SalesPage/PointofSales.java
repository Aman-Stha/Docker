package com.pivotech.SalesPage;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import com.pivotech.helper.PageObject;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author amrita
 */
public class PointofSales extends PageObject {

    By sales = By.xpath("//a[@id='pnl_Sales']");
    By pos = By.xpath("//span[normalize-space()='Point of Sale']");
    By customer = By.xpath("//input[@id='customer']");
    By product = By.xpath("//input[@id='product']");
//  By rate = By.xpath("//input[@value='160.00']");
//  By quantity = By.xpath("//input[@value='1.00']");
    By flatDis = By.xpath("//input[@id='flatDiscountAmount']");
    By remarks = By.xpath("//input[@id='remarks']");
    By confirm = By.xpath("//span[normalize-space()='Confirm Sale']");
    By save = By.xpath("//button[@title='[shift + S]']");
   // By toast = By.xpath("//div[@class='p-toast-message-content']");
    
    
    public PointofSales(WebDriver driver) {
        super(driver);
    }
    
    public PointofSales addsales(Map<String, String> userData) throws InterruptedException{
        // click(menu);  
        click(sales);
        click(pos);
        click(customer);
        clearInputFields();
        selectFromDropdown(customer, userData.get("customer"));
        selectFromDropdown(product, userData.get("product"));
        Thread.sleep(2000);
        writeText(flatDis, userData.get("flatD"));
        writeText(remarks, userData.get("remarks"));
        click(confirm);
        Thread.sleep(1000);
        click(save);
        return this;
    }
    
    public PointofSales clearInputFields() {
        clearText(customer);
       return this;
    }
 
    
}
