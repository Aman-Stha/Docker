/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pivotech.VoucherTest;

import com.pivotech.pageTest.BaseTest;
import static com.pivotech.pageTest.BaseTest.openUrl;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 *
 * @author amrita
 */
public class POGrnVoucher extends BaseTest {

   //   private String grnQuantity;
    private String initialstock; 
    private int act_stock; 
    
    private final Map<String, String> initialBalances = new HashMap<>(); 
    @Test
    public void Login() throws InterruptedException, IOException {
        openUrl("/Login");
        loginpage.OnlyLogin("asus", "sigma@123");
    }
    
    
    @Test(dependsOnMethods = "Login")
    public void stockvalue() throws InterruptedException, IOException {
        // Get stock value before adding GRN
        initialstock = productdet.stock("Baggy Pants");
         System.out.println("initiall stock  : " + initialstock);    
    }
    
    
    @Test(dependsOnMethods = "stockvalue")
       public void initialblncTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/SubLedger/grn.csv";
        String line;
        List<Integer> accheadIndices = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }

            // Identify headers and find indices of 'acchead' columns
            String[] headers = lines.get(0);
            for (int j = 0; j < headers.length; j++) {
                if (headers[j].startsWith("acchead")) {
                    accheadIndices.add(j);
                }
            }
            // Process each data row in the CSV
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                // Load necessary data into userData
                userData.put("fromdate", getValueAtIndex(data, 0));
                userData.put("todate", getValueAtIndex(data, 1));

                for (int index : accheadIndices) {
                    userData.put(headers[index], getValueAtIndex(data, index));
                }
                // Call checkblnc with the populated userData map
                subledger.checkblnc(userData);

                // Print and store initial balances for each 'acchead'
                for (int index : accheadIndices) {
                    String accheadKey = headers[index];
                    String balance = subledger.getBalanceByAccountHead(accheadKey);
                    System.out.println("Initial Balance in " + accheadKey + " : " + balance);
                    initialBalances.put(accheadKey, balance); // Store initial balance
                }
            }
        }
    }
    
    
    @Test(dependsOnMethods = "initialblncTest")
    public void PurchaseorderTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/pOrder.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                purchaseorder.addPurchase(userData);

            }
        }
    }
    
      @Test(dependsOnMethods = "PurchaseorderTest")
    public void GRNTest() throws InterruptedException, IOException {
        String csvFilePath = "TestDataSet/Purchase/grn.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }
                 String expected_stock = userData.get("actual_stock");
                act_stock = Integer.parseInt(expected_stock);
              System.out.println("Total Stock added: " + act_stock);
                // Call addGrn and store the returned quantity
               // grnQuantity = Grn.addGrn(userData);
                 Grn.addGrn(userData);
            }
        }
    }
    
    
    
    
     @Test(dependsOnMethods = "GRNTest")
    public void validateStock() throws InterruptedException {
       
        String finalstock = productdet.stock("Baggy Pants");
        int finalStock = Integer.parseInt(finalstock.replaceAll("[^0-9.]", ""));

        int initialStockInt = Integer.parseInt(initialstock.replaceAll("[^0-9]", ""));
      // System.out.println("initiall stock  : " + initialStockInt);
        int expectedStockValue = finalStock - initialStockInt;
        
        System.out.println("Final stock  : " + finalStock);
        System.out.println("Expected stock added: " + expectedStockValue);
        
        if (expectedStockValue == act_stock){
            System.out.println(" stock value is correct");
        }
        else{
                System.out.println("stock value is incorrect");
}
    }
    
    
     @Test(dependsOnMethods = "validateStock") 
    public void finalblncTest() throws IOException, InterruptedException {
    String csvFilePath = "TestDataSet/SubLedger/grn.csv";
    List<Integer> accheadIndices = new ArrayList<>();
    List<Integer> accbalIndices = new ArrayList<>();

    // Read CSV and initialize headers
    try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
        List<String[]> lines = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            lines.add(line.split(","));
        }
        
        String[] headers = lines.get(0); // Header row
        for (int j = 0; j < headers.length; j++) {
            if (headers[j].startsWith("acchead")) accheadIndices.add(j);
            if (headers[j].startsWith("accbal")) accbalIndices.add(j);
        }

        // Process data rows
        for (int i = 1; i < lines.size(); i++) {
            String[] data = lines.get(i);
            Map<String, String> userData = new HashMap<>();
            userData.put("fromdate", data[0]);
            userData.put("todate", data[1]);

            // Load acchead values
            for (int index : accheadIndices) {
                userData.put(headers[index], data[index]);
            }

            subledger.checkblnc(userData);

            // Store differences dynamically in a Map
            Map<String, Double> differencesMap = new HashMap<>();

            for (int index : accheadIndices) {
                String accheadKey = headers[index];
                String initialBalanceStr = initialBalances.get(accheadKey);
                
                if (initialBalanceStr != null) {
                    double initialBalance = Double.parseDouble(initialBalanceStr);
                    double finalBalance = Double.parseDouble(subledger.getBalanceByAccountHead(accheadKey));
                    double difference = finalBalance - initialBalance;

                    // Store difference by accheadKey
                    differencesMap.put(accheadKey, difference);
                }
            }

            // Compare each accbal with corresponding difference in differencesMap
            for (int j = 0; j < accbalIndices.size(); j++) {
                String accbalValue = data[accbalIndices.get(j)];
                String accheadKey = headers[accheadIndices.get(j)]; // Ensure correct acchead for accbal comparison

                Double difference = differencesMap.get(accheadKey);

                if (difference != null && difference.equals(Double.valueOf(accbalValue))) {
                    System.out.printf("Test Passed for %s: Difference %.2f matches accbal value %s%n", accheadKey, difference, accbalValue);
                } else {
                    System.out.printf("Test Failed for %s: Difference %.2f does not match accbal value %s%n", accheadKey, difference, accbalValue);
                    Assert.fail("Difference does not match accbal value.");
                }
            }
        }
    }
}

      
      
    private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
    
}
